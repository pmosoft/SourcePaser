package variable.numeric;

import java.lang.*;
import java.util.*;

public class numeric_t
{    
    public static void main(String[] args)throws Exception
    {

//        double d_1 = 3000000;
//        double d_2 = -7000000;
//        double d_3 = d_1/d_2;
//
//        d_2 = Math.abs(d_2);

        int i1 = 3;
        i1 = i1%2;
                   
        int i2 = 4;
        i2 = i2%2;  
                   
        System.out.println("i1 = " + i1);              
        System.out.println("i2 = " + i2);              

//        long   l_1 = 2;
        
//        l_1 = double.toLong(d_1);   
//        d_1 = long.toDouble(l_1);

//        d_1 = Math.floor(d_1);
//        System.out.println("d_2 = " + d_2);              

/*
        double[] d1 = new double[100];
        double d2 = 1.0;
        d1[0] = d2;

        long[] l1 = new long[10];
        l1[0] = 1;

        long l2 = 2600; 
        long l3 = 9; 
        long l4 = l2/l3;
        long l5 = l3/l2;

        int i2 = 2600; 
        int i3 = 9; 
        int i4 = i2/i3;
        int i5 = i3/i2;
       
        String s1 = Long.toString( l1[0] );

        System.out.println("d1[0] = " + d1[0]);         
        System.out.println("l1[0] = " + l1[0]);      
        System.out.println("s1    = " + s1);      

        System.out.println("l4 = " + l4);      
        System.out.println("l5 = " + l5);      

        System.out.println("i4 = " + i4);      
        System.out.println("i5 = " + i5);      

        double cc = 3;
        double dd = 4;        
        double ee = 8;        
        String ff = "";        
        String[] sa_aa = new String[10];

        ee = dd/cc;
        ff = Double.toString(ee);
       
        System.out.println("ee = " + ee); 
        System.out.println("ff = " + ff); 


        
        String sa_calcInt = "10";
        String sa_aftTaxInt = "5";
        String sa_preTaxAmt = Double.toString( Math.round( Double.parseDouble(sa_calcInt) - Double.parseDouble(sa_aftTaxInt) ) );
        sa_preTaxAmt = sa_preTaxAmt.substring(0,sa_preTaxAmt.indexOf("."));
        
        long l1 = 10;
        String s_aa = "";
        String s_bb = "10";
        String s_cc = "7";        
        s_aa = Long.toString(Long.parseLong(s_bb));
        System.out.println("sa_aa = " + sa_aa);          

        long l2 = 7;

        ff = Long.toString( l1/l2 );
        
        System.out.println("l1 = " + l1); 
        System.out.println("l2 = " + l1/l2); 

        System.out.println("ff = " + ff); 
*/
        
        
    }
}    
