package com.pmosoft.parsesrc.test;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import com.pmosoft.parsesrc.controller.ParseSrc;

public class ParseSrcTest {

	/**
	 * in case the pattern of table name is "(F|f)[a-zA-Z]{2}_[a-zA-Z_]+"	 *  
	 * (ex:FRA_CNTR_BASE,FRA_CNTR_DETAIL...)
	 * 
	 * src : SELECT CNTR_ID 
	 *         FROM AMLCORE.FRA_CNTR_BASE a,
	 *              AMLCORE.FRA_CNTR_DETAIL b,
	 *              AMLCORE.FRA_CNTR_DETAIL_HIS c; 
	 *  
	 * result : table name should be displayed 3
	 *          FRA_COMMENT within comments must not displayed   
	 */    
    @Test    
    public void TestExtTable01() { 

		ArrayList<String> tabList = new ArrayList<String>();
    	
		ParseSrc parseSrc = new ParseSrc();
		parseSrc.setSrc("SELECT CNTR_ID FROM AMLCORE.FRA_CNTR_BASE a,AMLCORE.FRA_CNTR_DETAIL b,AMLCORE.FRA_CNTR_DETAIL_HIS c; /* FRA_COMMENT */");
		parseSrc.setTabPattern("(F|f)[a-zA-Z]{2}_[a-zA-Z_]+");
		parseSrc.setTabList();
		tabList = parseSrc.getTabList();
		assertEquals(3,tabList.size());
    }	

	/**
	 * in case the pattern of table name is "(F|f)[a-zA-Z]{2}_[a-zA-Z_]+"	 *  
	 * (ex:FRA_CNTR_BASE,FRA_CNTR_DETAIL...)
	 * 
	 * src : SELECT CNTR_ID 
	 *         FROM AMLCORE.DRA_CNTR_BASE a,  <== x
	 *              AMLCORE.FRA_CNTR_DETAIL b,
	 *              AMLCORE.FRA_CNTR_DETAIL_HIS c; 
	 *  
	 * result : table name should be displayed 2
	 *          FRA_COMMENT within comments must not displayed   
	 */    
    @Test    
    public void TestExtTable02() { 

		ArrayList<String> tabList = new ArrayList<String>();
    	
		ParseSrc parseSrc = new ParseSrc();
		parseSrc.setSrc("SELECT CNTR_ID FROM AMLCORE.DRA_CNTR_BASE a,AMLCORE.FRA_CNTR_DETAIL b,AMLCORE.FRA_CNTR_DETAIL_HIS c; /* FRA_COMMENT */");
		parseSrc.setTabPattern("(F|f)[a-zA-Z]{2}_[a-zA-Z_]+");
		parseSrc.setTabList();
		tabList = parseSrc.getTabList();
		assertEquals(2,tabList.size());
    }	
    
    
}
