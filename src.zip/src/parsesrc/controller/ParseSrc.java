package com.pmosoft.parsesrc.controller;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ParseSrc {

	public static void main(String[] args) {
		ParseSrc parseSrc = new ParseSrc();
		parseSrc.setSrc("SELECT CNTR_ID FROM AMLCORE.FRA_CNTR_BASE a,AMLCORE.FRA_CNTR_DETAIL b,AMLCORE.FRA_CNTR_DETAIL_HIS c; /* aaaa */");
		parseSrc.setTabPattern("(F|f)[a-zA-Z]{2}_[a-zA-Z_]+");
		parseSrc.setTabList();
	}

	/****************************************************************
	 * Member variables
	 ****************************************************************/
	private String src;
	private String tabPattern;
	private ArrayList<String> tabList;

	/****************************************************************
	 * Constructor
	 ****************************************************************/
	public ParseSrc(){}

	/****************************************************************
	 * Operation
	 ****************************************************************/
	public String getSrc(){ return this.src;}
	public void setSrc(String src){ this.src = src;}

	public String getTabPattern(){ return this.tabPattern;}
	public void setTabPattern(String tabPattern){ this.tabPattern = tabPattern;}
	
	public ArrayList<String> getTabList(){ return this.tabList;}
	public String getTabString(){
		String tabList="";
		for(int i=0;i<this.tabList.size();i++){
			tabList += this.tabList.get(i)+ "\r\n";
		}			
		return tabList;
	}
	
	public void setTabList(){
		this.tabList = extractTabList(this.src, this.tabPattern);
	}
	
	/*
	 * Extract table list from source code using regular expression
	 * */	
	private ArrayList<String> extractTabList(String src, String tabPattern) {

	    //String tabPattern = "(F|f)[a-zA-Z]{2}_[a-zA-Z_]+";
		ArrayList<String> tabList = new ArrayList<String>();
		
		Pattern p; Matcher m;
		
		String lineComment1 = "--.*";
		//String lineComment2 = "//.*";
		String whitespace = "[\t\n]";
		String longComment = "/\\*([^*]|\\*+[^/*])*\\*+/";
	    
	    //------------------------------------------------------------------------------
	    //                               Execute Parsing
	    //------------------------------------------------------------------------------
	    try{
	    	System.out.println("src0="+src);
	    	
		    //---------------------
		    // Del lineComment
		    //---------------------
	    	p = Pattern.compile(lineComment1);
	    	m = p.matcher(src); src = m.replaceAll("");
	    	System.out.println("src1="+src);

		    //---------------------
		    // Del whitespace
		    //---------------------
	    	p = Pattern.compile(whitespace);
	    	m = p.matcher(src); src = m.replaceAll("");
	    	System.out.println("src2="+src);
	    	
		    //---------------------
		    // Del longComment
		    //---------------------
	    	p = Pattern.compile(longComment);
	    	m = p.matcher(src); src = m.replaceAll("");
	    	System.out.println("src3="+src);
	    	
		    //---------------------
		    // tabPattern
		    //---------------------
	    	p = Pattern.compile(tabPattern);
	    	m = p.matcher(src); 
	    	
	    	while(m.find()){
	    		//System.out.println("["+m.start()+"_"+m.group()+"]");
	    		System.out.println("["+m.group()+"]");
	    		tabList.add(m.group());
	    	}
	    	
	    } catch(Exception e) {
	    	System.out.println("e="+e.getMessage());
	    }
		return tabList;
	}
}
