package com.pmosoft.parsesrc.view;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Tree;

public class TestSwt {

	protected Shell shell;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			TestSwt window = new TestSwt();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(450, 300);
		shell.setText("SWT Application");
		
		Label lblNewLabel = new Label(shell, SWT.NONE);
		lblNewLabel.setBounds(43, 31, 89, 34);
		lblNewLabel.setText("New Label");
		
		Button btnNewButton = new Button(shell, SWT.NONE);
		btnNewButton.setBounds(155, 26, 77, 22);
		btnNewButton.setText("New Button");
		
		Tree tree = new Tree(shell, SWT.BORDER);
		tree.setBounds(48, 84, 84, 84);

	}
}
