package com.pmosoft.parsesrc.view;

import java.util.ArrayList;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import com.pmosoft.parsesrc.controller.ParseSrc;

public class ParsedTabListView {

	protected Shell shell;
	private Text txtSrc;
	private Text txtTabList;

	//txtSrc
	ParseSrc parseSrc;	
	
	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		
		System.out.println( "JRE Version :" + System.getProperty( "java.runtime.version" ) );
        System.out.println( "JVM Bit size: " + System.getProperty( "sun.arch.data.model" ) );
		
		try {
			ParsedTabListView window = new ParsedTabListView();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(778, 562);
		shell.setText("SWT Application");
		
		txtSrc = new Text(shell, SWT.BORDER | SWT.MULTI);
		txtSrc.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				
		        if (e.stateMask == SWT.CTRL && e.keyCode == 'a') {
		        	txtSrc.selectAll();
		            e.doit = false;
		        }				
			}
		});
		//txtSrc.setText("select");
		txtSrc.setBounds(10, 27, 663, 186);
		
		txtTabList = new Text(shell, SWT.BORDER | SWT.MULTI);
		txtTabList.setEditable(false);
		txtTabList.setBounds(21, 254, 663, 250);
		
		Button btnParsing = new Button(shell, SWT.NONE);
		btnParsing.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {

				parseSrc = new ParseSrc();
				//MessageDialog.openInformation(shell, "Info", txtSrc.getText());
				
				parseSrc.setSrc(txtSrc.getText());
				parseSrc.setTabPattern("(F|f)[a-zA-Z]{2}_[a-zA-Z_]+");
				parseSrc.setTabList();
				txtTabList.setText(parseSrc.getTabString());
				
			}
		});
		btnParsing.setBounds(20, 219, 77, 22);
		btnParsing.setText("Parse");

	}
}
