if  exists ( select 1 from sysobjects 
             where name ='sp_asemon'
             and type = 'P')
begin
  DROP procedure sp_asemon
end 
GO

create procedure sp_asemon
as
begin


select
       -- a.showYN
       --,a.SPID
        case when a.showYN='Y' then a.SPID              else '' end    as SPID
       ,case when a.showYN='Y' then a.ipaddr            else '' end    as ipaddr
       ,case when a.showYN='Y' then a.hostname          else '' end    as hostname
       ,case when a.showYN='Y' then a.user_name         else '' end    as user_name
       ,case when a.showYN='Y' then a.program_name      else '' end    as program_name
       ,case when a.showYN='Y' then a.DBName            else '' end    as DBName
       ,a.SQLText                                                      as SQLText
       ,case when a.showYN='Y' then a.loggedindatetime  else '' end    as loggedindatetime
       ,case when a.showYN='Y' then a.StartTime         else '' end    as StartTime
       ,case when a.showYN='Y' then a.CpuTime           else '' end    as CpuTime
       ,case when a.showYN='Y' then a.WaitTime          else '' end    as WaitTime
       ,case when a.showYN='Y' then a.PhysicalReads     else '' end    as PhysicalReads
       ,case when a.showYN='Y' then a.LogicalReads      else '' end    as LogicalReads
       ,case when a.showYN='Y' then a.MemUsageKB        else '' end    as MemUsageKB
       ,case when a.showYN='Y' then a.cmd               else '' end    as cmd
       ,case when a.showYN='Y' then a.status            else '' end    as status
       ,case when a.showYN='Y' then a.physical_io       else '' end    as physical_io
       ,case when a.showYN='Y' then a.blocked           else '' end    as blocked
       ,case when a.showYN='Y' then a.time_blocked      else '' end    as time_blocked
       ,case when a.showYN='Y' then a.tran_name         else '' end    as tran_name
       ,case when a.showYN='Y' then a.cpu               else '' end    as cpu
       ,case when a.showYN='Y' then a.memusage          else '' end    as memusage
from
(
select
        case when d.gubun=1 and b.SequenceInLine=d.min_SequenceInLine then 'Y'
             when d.gubun=2 and b.LineNumber=d.min_LineNumber         then 'Y'
             else 'N'
        end                                                            as showYN
       ,b.SequenceInLine                                               as SequenceInLine
       ,b.LineNumber                                                   as LineNumber
       ,d.gubun                                                        as gubun
       ,d.min_SequenceInLine                                           as min_SequenceInLine
       ,d.min_LineNumber                                               as min_LineNumber
       ,cast(a.SPID as varchar)                                        as SPID
       ,c.ipaddr                                                       as ipaddr
       ,c.hostname                                                     as hostname
       ,(select name from master..syslogins where suid=b.ServerUserID) as user_name
       ,case when hostname in ('hanamid1','hanamid2') then 'web'
             when hostname in ('haisapp1') then 'mines'
             else c.program_name
        end                                                            as program_name
       ,a.DBName                                                       as DBName
       ,b.BatchID                                                      as BatchID
       ,b.SQLText                                                      as SQLText
       ,convert(char(10),cast(c.loggedindatetime as datetime),102)||' '||convert(char(8),cast(c.loggedindatetime as datetime),108) as loggedindatetime
       ,convert(char(10),cast(a.StartTime as datetime),102)||' '||convert(char(8),cast(a.StartTime as datetime),108)               as StartTime
       ,cast(a.CpuTime          as varchar)                            as CpuTime
       ,cast(a.WaitTime         as varchar)                            as WaitTime
       ,cast(a.PhysicalReads    as varchar)                            as PhysicalReads
       ,cast(a.LogicalReads     as varchar)                            as LogicalReads
       ,cast(a.MemUsageKB       as varchar)                            as MemUsageKB
       ,b.SequenceInLine                                               as SequenceInLine
       ,c.cmd                                                          as cmd
       ,c.status                                                       as status
       ,cast(c.physical_io as varchar)                                 as physical_io
       ,cast(c.blocked     as varchar)                                 as blocked
       ,cast(c.time_blocked as varchar)                                as time_blocked
       ,c.tran_name                                                    as tran_name
       ,cast(c.cpu         as varchar)                                 as cpu
       ,cast(c.memusage    as varchar)                                 as memusage
--       ,b.*
from   master..monProcessStatement a,
       master..monProcessSQLText   b,
       master..sysprocesses c,
      (select   a.SPID
               ,min(a.SequenceInLine) as min_SequenceInLine
               ,max(a.SequenceInLine) as max_SequenceInLine
               ,min(a.LineNumber)     as min_LineNumber
               ,max(a.LineNumber)     as max_LineNumber
               ,case when min(a.SequenceInLine) <> max(a.SequenceInLine) then 1 else 2 end as gubun
        from   master..monProcessSQLText a
        group by a.SPID
        ) d
where  a.SPID = b.SPID
and    a.SPID = c.spid
and    a.SPID = d.SPID
) a
--order by a.SPID, case when a.gubun = 1 then a.SequenceInLine else a.LineNumber end

end
GO

sp_procxmode sp_asemon, ANYMODE 
GO
GRANT EXEC ON sp_asemon TO PUBLIC 
GO
