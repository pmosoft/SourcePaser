if  exists ( select 1 from sysobjects 
             where name ='SP_AUDIT_����_���'
             and type = 'P')
begin
  DROP procedure SP_AUDIT_����_���
end 
GO


/*
        @PROC_GUBUN :   10 ���ʳ��λ�� OR  �ݷ� �� ����
                        11 ���λ�� ��� �� ���� 
                        20 �ܺκμ���� OR  �ܺκμ� ��� ��� �� ����
		                21 �ܺκμ������� �ݷ� �� �ܺκμ� ���
*/
create proc SP_AUDIT_����_���   ( @PROC_GUBUN              CHAR   (   2)
                                  ,@DOC_CODE                CHAR   (   1)
                                  ,@DECIDE_GUBUN_CODE       CHAR   (   1)
                                  ,@TITLE                   CHAR   ( 100)
                                  ,@UPMU_GUBUN_CODE         CHAR   (   3)
                                  ,@BRNCH_NO                CHAR   (   4)
                                  ,@DECIDE_URL              VARCHAR(1000)
                                  ,@BRNCH_DECIDE_URL        VARCHAR(1000)
                                  ,@OPINION                 VARCHAR(1024)
                                  ,@PRE_DECIDE_NO           INT
                                  ,@UPMU_TABLE_NAME         CHAR   ( 100)
                                  ,@PKWHERE                 CHAR   ( 400)
                                  ,@FIRST_DECIDE_EMPNO      CHAR   (   7)
                                  ,@TRGT_BRNCH_NO           CHAR   (   4)
 )
as


            
            /* ���λ�� || �ݷ��� ���� */
            if @PROC_GUBUN = '10'
            begin
                  
                EXEC SP_AUDIT_����_����� @PROC_GUBUN
                                         ,@DOC_CODE
                                         ,@DECIDE_GUBUN_CODE
                                         ,@TITLE
                                         ,@UPMU_GUBUN_CODE
                                         ,@BRNCH_NO
                                         ,@DECIDE_URL
                                         ,@BRNCH_DECIDE_URL
                                         ,@OPINION
                                         ,@PRE_DECIDE_NO
                                         ,@UPMU_TABLE_NAME
                                         ,@PKWHERE
                                         ,@FIRST_DECIDE_EMPNO  
                                         ,@TRGT_BRNCH_NO
                     
            end
            /* ���λ�� ��� �� ���� */
            else if  @PROC_GUBUN = '11'  
            begin
  
                EXEC SP_AUDIT_����_����ҳ���� @PROC_GUBUN
                                               ,@DOC_CODE
                                               ,@DECIDE_GUBUN_CODE
                                               ,@TITLE
                                               ,@UPMU_GUBUN_CODE
                                               ,@BRNCH_NO
                                               ,@DECIDE_URL
                                               ,@BRNCH_DECIDE_URL
                                               ,@OPINION
                                               ,@PRE_DECIDE_NO
                                               ,@UPMU_TABLE_NAME
                                               ,@PKWHERE
                                               ,@FIRST_DECIDE_EMPNO  
                                               ,@TRGT_BRNCH_NO

            end

            /* �ܺκμ� ���ʻ�� OR �ܺκμ� ������ �� ����*/
            else if  @PROC_GUBUN = '20'  
            begin
  
                EXEC SP_AUDIT_����_�ܻ��       @PROC_GUBUN
                                               ,@DOC_CODE
                                               ,@DECIDE_GUBUN_CODE
                                               ,@TITLE
                                               ,@UPMU_GUBUN_CODE
                                               ,@BRNCH_NO
                                               ,@DECIDE_URL
                                               ,@BRNCH_DECIDE_URL
                                               ,@OPINION
                                               ,@PRE_DECIDE_NO
                                               ,@UPMU_TABLE_NAME
                                               ,@PKWHERE
                                               ,@FIRST_DECIDE_EMPNO  
                                               ,@TRGT_BRNCH_NO

            end

            /* �ܺκμ� �ݷ� �� �ܺκμ� ����*/
            else if  @PROC_GUBUN = '21'  
            begin
  
                EXEC SP_AUDIT_����_�ܹݷ��ܻ�� @PROC_GUBUN
                                               ,@DOC_CODE
                                               ,@DECIDE_GUBUN_CODE
                                               ,@TITLE
                                               ,@UPMU_GUBUN_CODE
                                               ,@BRNCH_NO
                                               ,@DECIDE_URL
                                               ,@BRNCH_DECIDE_URL
                                               ,@OPINION
                                               ,@PRE_DECIDE_NO
                                               ,@UPMU_TABLE_NAME
                                               ,@PKWHERE
                                               ,@FIRST_DECIDE_EMPNO  
                                               ,@TRGT_BRNCH_NO

            end
            

return

GO

sp_procxmode SP_AUDIT_����_���, ANYMODE 
GO
GRANT EXEC ON SP_AUDIT_����_��� TO PUBLIC 
GO
