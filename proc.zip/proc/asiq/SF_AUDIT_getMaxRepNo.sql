if  exists ( select 1 from sysobjects 
             where name ='SF_AUDIT_getMaxRepNo'
             and type = 'P')
begin
  DROP procedure SF_AUDIT_getMaxRepNo
end 
GO

create function ett_iq.SF_AUDIT_getMaxRepNo(in p_year char(4),in p_code char(1),in p_unit integer)
returns varchar(20)
begin
  declare v_MaxDocNo varchar(20);
  declare v_kind varchar(10);
  if p_year is null or p_year = '' or p_code is null or p_code = '' or p_unit is null then
    set v_MaxDocNo='';
    return(v_MaxDocNo)
  end if;
  select case p_code when '1' then '�೻' when '3' then '�γ�' when '5' then '���' else '' end into v_kind
  ;
  select(p_year || '-' || 
    v_kind || '-' || 
    IFNULL(REPEAT('0',(p_unit-LENGTH(TRIM(STR(MAX(������ȣ)))))) || TRIM(STR(MAX(������ȣ))),
    REPEAT('0',(p_unit-1)) || '1',
    REPEAT('0',(p_unit-LENGTH(TRIM(STR(MAX(������ȣ)))))) || TRIM(STR(MAX(������ȣ))))) into v_MaxDocNo
    from TB_IQF_����_������ȣä�� where
    ���س� = p_year and
    �����ڵ� = p_code;
  if v_MaxDocNo is null then
    set v_MaxDocNo=''
  end if;
  return(v_MaxDocNo)
end
GO

GRANT EXECUTE ON SF_AUDIT_getMaxRepNo TO web_iq 
GO
