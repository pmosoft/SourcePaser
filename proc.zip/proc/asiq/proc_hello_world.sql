if  exists ( select 1 from sysobjects 
             where name ='proc_hello_world'
             and type = 'P')
begin
  DROP procedure proc_hello_world
end 
GO

create PROCEDURE ett_iq."proc_hello_world" (inout myarg integer)
BEGIN
	SELECT 'Hello World!'
END
GO

GRANT EXECUTE ON proc_hello_world TO web_iq 
GO
