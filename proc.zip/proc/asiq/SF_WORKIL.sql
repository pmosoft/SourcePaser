if  exists ( select 1 from sysobjects 
             where name ='SF_WORKIL'
             and type = 'P')
begin
  DROP procedure SF_WORKIL
end 
GO

create function ett_iq.SF_WORKIL(in V_WORKIL char(8),in V_DAY_GB integer)
returns char(8)
begin
  declare V_YEAR char(4);
  declare V_YEARMONTH char(6);
  declare V_MONTH integer;
  declare V_DAY integer;
  declare V_RETVALUE char(1);
  declare V_SQL varchar(1000);
  declare V_WORKCODE varchar(20);
  set V_RETVALUE=2;
  while V_RETVALUE <> 1 loop
    select DATEFORMAT(DAYS("DATE"(V_WORKIL),V_DAY_GB),'YYYYMMDD') into V_WORKIL;
    set V_YEAR=SUBSTR(V_WORKIL,1,4);
    set V_YEARMONTH=SUBSTR(V_WORKIL,1,6);
    set V_MONTH=cast(SUBSTR(V_WORKIL,5,2) as integer);
    set V_DAY=cast(SUBSTR(V_WORKIL,7,2) as integer);
    set V_WORKCODE=RTRIM('���ڱ����ڵ�' || V_DAY);
    set V_SQL='SELECT ' || V_WORKCODE || ' INTO  V_RETVALUE  FROM  TB_IQF_����_���������⺻  WHERE ���ϰ�������������ڵ� = ' || '''01''' || ' AND �����ڵ� =  ' || '''KR''' || ' AND ���س�� = ''' || 
      V_YEARMONTH || '''';
    execute immediate V_SQL
  end loop;
  return(V_WORKIL)
end
/* ### DEFNCOPY: END OF DEFINITION */
GO

GRANT EXECUTE ON SF_WORKIL TO web_iq 
GO
