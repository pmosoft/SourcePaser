if  exists ( select 1 from sysobjects 
             where name ='SP_TEST01'
             and type = 'P')
begin
  DROP procedure SP_TEST01
end 
GO

CREATE PROCEDURE SP_TEST01 AS 
BEGIN

UPDATE DBHAISASE..��_IMSI
   SET A.KEY1  = 'B'
     , A.DATA1  = A.DATA1 + 1
  FROM DBHAISASE..��_IMSI A
 WHERE A.KEY1  = 'S'
 
END
GO

sp_procxmode SP_TEST01, ANYMODE 
GO
GRANT EXEC ON SP_TEST01 TO PUBLIC 
GO
