if  exists ( select 1 from sysobjects 
             where name ='sp_loadscript'
             and type = 'P')
begin
  DROP procedure sp_loadscript
end 
GO

create procedure ett_iq.sp_loadscript(in I_���̺��� varchar(100))
begin
  create table #temp1(
    column_id integer not null,
    column_name varchar(300) not null,
    );
  insert into #temp1
    select distinct
      b.column_id,
      (case when b.column_id = 1 then trim(b.column_name)
      --insert into #temp1 select (select max(column_id)+1 from #temp1) as column_id, 'DELIMITED BY ''|'' '           as column_name;
      else ',' || b.column_name
      end) || ' ''#|''' as column_name from SYS.SYSTABLE as a,
      SYS.SYSCOLUMN as b,
      SYS.SYSDOMAIN as c where
      b.table_id = a.table_id and
      c.domain_id = b.domain_id and
      a.table_name = I_���̺��� order by
      b.column_id asc;
  insert into #temp1 select 0 as column_id,'--sp_loadscript ' || I_���̺��� as column_name;
  insert into #temp1 select 0 as column_id,'--bcp ' || I_���̺��� || ' in  ''/bct/temp/ext_' || I_���̺��� || '_' || DATEFORMAT(NOW(*),'yyyymmdd') || '.dat'' -c -r ''#|@@\n'' -t ''#|'' -b10000 -m10 -Uett_ase -Pais111 -SDBPAIS1 -zus_english' as column_name;
  insert into #temp1 select 0 as column_id,'--bcp ' || I_���̺��� || ' out ''/bct/temp/ext_' || I_���̺��� || '_' || DATEFORMAT(NOW(*),'yyyymmdd') || '.dat'' -c -r ''#|@@\n'' -t ''#|'' -Uett_ase -Pais111 -SDBPAIS1 -zus_english' as column_name;
  insert into #temp1 select 0 as column_id,'--sp_loadscript2  ' || I_���̺��� as column_name;
  insert into #temp1 select 0 as column_id,'--bcp ' || I_���̺��� || ' in  ''/bct/temp/ext_' || I_���̺��� || '_' || DATEFORMAT(NOW(*),'yyyymmdd') || '.dat'' -c -r ''|\n'' -t ''|'' -b10000 -m10 -Uett_ase -Pais111 -SDBPAIS1 -zus_english' as column_name;
  insert into #temp1 select 0 as column_id,'--bcp ' || I_���̺��� || ' out ''/bct/temp/ext_' || I_���̺��� || '_' || DATEFORMAT(NOW(*),'yyyymmdd') || '.dat'' -c -r ''|\n'' -t ''|'' -Uett_ase -Pais111 -SDBPAIS1 -zus_english' as column_name;
  insert into #temp1 select 0 as column_id,'' as column_name;
  insert into #temp1 select 0 as column_id,'LOAD TABLE ' || I_���̺��� || ' (' as column_name;
  insert into #temp1 select(select max(column_id)+1 from #temp1) as column_id,') FROM ''/bct/temp/' || I_���̺��� || '_' || convert(char(8),GETDATE(*),112) || '.dat''' as column_name;
  insert into #temp1 select(select max(column_id)+1 from #temp1) as column_id,'QUOTES  OFF' as column_name;
  insert into #temp1 select(select max(column_id)+1 from #temp1) as column_id,'ESCAPES OFF' as column_name;
  insert into #temp1 select(select max(column_id)+1 from #temp1) as column_id,'FORMAT  ASCII' as column_name;
  insert into #temp1 select(select max(column_id)+1 from #temp1) as column_id,'ROW     DELIMITED BY ''@@\n''' as column_name;
  insert into #temp1 select(select max(column_id)+1 from #temp1) as column_id,'WITH CHECKPOINT ON;' as column_name;
  select column_name from #temp1 order by column_id asc
end
GO

GRANT EXECUTE ON sp_loadscript TO web_iq 
GO
