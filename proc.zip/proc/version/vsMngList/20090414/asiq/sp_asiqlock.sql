if  exists ( select 1 from sysobjects 
             where name ='sp_asiqlock'
             and type = 'P')
begin
  DROP procedure sp_asiqlock
end 
GO

create procedure sp_asiqlock()
begin

  create table #iq_connTable
  (
      Number                unsigned bigint        null,
      IQconnID              unsigned bigint        null,
      numIQCursors          unsigned integer       null,
      IQthreads             unsigned integer       null,
      TxnID                 unsigned bigint        null,
      ConnOrCurCreateTime   datetime               null,
      CmdLine               varchar(4096)          null,
      CurrOrConn            char(4096)             null,
      IQGovernPriority      char(14)               null
  )
  ;

  execute immediate with quotes on 'iq utilities main into #iq_connTable command statistics 80000';

  select  a.IQconnID                                                      as IQconnID
         ,a.TxnID                                                         as TxnID
         ,a.Number                                                        as ConnHandle
         ,cast(a.ConnOrCurCreateTime as char(19))                         as ConnOrCurCreateTime
         ,cast(connection_property('LastReqTime',a.Number) as char(19))   as LastReqTime
         ,a.CmdLine                                                       as CmdLine
         ,case when connection_property('NodeAddress',a.Number) = ''
               then '111.16.4.84'
               else connection_property('NodeAddress',a.Number)
          end                                                             as NodeAddress
         ,a.numIQCursors                                                  as numIQCursors
         ,a.IQthreads                                                     as IQthreads
         ,connection_property('LastIdle',a.Number)                        as LastIdle



         ,a.CurrOrConn                                                    as CurrOrConn
         ,connection_property('ReqType',a.Number)                         as ReqType

  from   #iq_connTable a
  where  a.CmdLine not in ('NO COMMAND','sp_asiqlock')
  ;

end
GO

GRANT EXECUTE ON sp_asiqlock TO web_iq 
GO
