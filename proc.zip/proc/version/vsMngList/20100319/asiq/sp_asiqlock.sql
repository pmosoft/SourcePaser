if  exists ( select 1 from sysobjects 
             where name ='sp_asiqlock'
             and type = 'P')
begin
  DROP procedure sp_asiqlock
end 
GO

create procedure sp_asiqlock()
begin

  create table #iq_connTable
  (
      Number                unsigned bigint        null,
      IQconnID              unsigned bigint        null,
      numIQCursors          unsigned integer       null,
      IQthreads             unsigned integer       null,
      TxnID                 unsigned bigint        null,
      ConnOrCurCreateTime   datetime               null,
      CmdLine               varchar(4096)          null,
      CurrOrConn            char(4096)             null,
      IQGovernPriority      char(14)               null
  )
  ;

  execute immediate with quotes on 'iq utilities main into #iq_connTable command statistics 80000';

  select  a.IQconnID                                                                  as IQconnID
         ,a.Number                                                                    as ConnHandle
         ,substr(cast(a.ConnOrCurCreateTime as char(19)),12,8)                        as ���ʿ���ð�
         ,substr(cast(connection_property('LastReqTime',a.Number) as char(19)),12,8)  as ��û���۽ð�
         ,substr(dateformat(now(),'yyyy-mm-dd hh:nn:ss'),12,8)                                                as ����ð�
         ,datediff(second,��û���۽ð�,����ð�)                                      as ��û�ҿ�ð�_��
         ,a.IQthreads                                                                 as IQthreads
         ,a.CmdLine                                                                   as CmdLine
         ,case when connection_property('NodeAddress',a.Number) = ''
               then '111.16.4.83'
               else connection_property('NodeAddress',a.Number)
          end                                                                         as NodeAddress
         ,cast(connection_property('LastIdle',a.Number) as int)                       as LastIdle
         ,a.TxnID                                                                     as TxnID
--       ,a.numIQCursors                                                              as numIQCursors
--       ,a.CurrOrConn                                                                as CurrOrConn
--       ,connection_property('ReqType',a.Number)                                     as ReqType
  from   #iq_connTable a
  where  a.CmdLine not in ('NO COMMAND','sp_asiqlock')
  and    a.IQthreads > 0
  order by ��û�ҿ�ð�_�� desc,a.IQthreads desc,LastIdle desc
  ;


end
GO

GRANT EXECUTE ON sp_asiqlock TO web_iq 
GO
