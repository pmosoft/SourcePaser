if  exists ( select 1 from sysobjects 
             where name ='sp_maketablescript'
             and type = 'P')
begin
  DROP procedure sp_maketablescript
end 
GO

create procedure sp_maketablescript 
(
  IN I_���̺��� VARCHAR(100)
)
/*

-- sp_maketablescript 20090520

-- ������ �������� /bct/temp/syscolumn.dat ����� chmod 777 /bct/temp/syscolumn.dat�� �����Ѵ�

select a.table_id,a.column_id,a.pkey,a.domain_id,a.width,a.scale,a.nulls,a.column_name
from   sys.syscolumn a


*/

begin


    create table #temp1
    (
        table_name          varchar(100) null,
        column_id           int          null,
        tablescript         varchar(300) null,
    );

    create table #tablescript
    (
        table_name          varchar(100) null,
        column_id           int          null,
        column_name         char(40)     null,
        scale_name          char(20)     null,
        null_yn             char(8)      null,
        max_col             int          null
    );

    create table #syscolumn
    (
        table_id            int          null,
        column_id           int          null,
        pkey                char(1)      null,
        domain_id           int          null,
        width               int          null,
        scale               int          null,
        nulls               char(1)      null,
        column_name         char(40)     null,
    );

    load table #syscolumn (
     table_id
    ,column_id
    ,pkey
    ,domain_id
    ,width
    ,scale
    ,nulls
    ,column_name
    ) from '/bct/temp/syscolumn.dat'
    quotes  off
    escapes off
    format  ascii
    delimited by '|'
    row     delimited by 0x0a
    ;

    select a.table_id,a.table_name
    into   #systable
    from   sys.systable a
    --where  a.table_name = 'OT_IQF_����_�λ�'
    where  a.table_name like 'TB%'
    or     a.table_name like 'OT%'
    or     a.table_name like 'TM%'
    ;

    select a.domain_id,a.domain_name
    into   #sysdomain
    from   sys.sysdomain a
    where  a.domain_id in (select distinct domain_id from #syscolumn)
    ;

    --select a.table_id,a.column_id,a.approx_unique_count
    --into   #sysiqcolumn
    --from   sys.sysiqcolumn a,
    --       #syscolumn b
    --where  a.table_id  = b.table_id
    --  and  a.column_id = b.column_id
    --;

    insert into #tablescript
    select  a.table_name                                            as table_name
           ,0                                                       as column_id
           ,'CREATE TABLE '||a.table_name||' ('                     as column_name
           ,''                                                      as scale_name
           ,''                                                      as null_yn
           ,0                                                       as max_col
    from   #systable a
    ;

    insert into #tablescript
    select  a.table_name                                            as table_name
           ,b.column_id                                             as column_id
           ,upper(b.column_name)                                    as column_name
           ,case when c.domain_name = 'integer'
                 then 'INT'
                 else upper(c.domain_name)||'('||b.width||case when b.scale = 0 then ''
                                                               else ','||b.scale end||')'
            end                                                     as scale_name
           ,case when b.nulls = 'N' then 'NOT NULL' else 'NULL' end as null_yn
           ,0                                                       as max_col
    from   #systable    a,
           #syscolumn   b,
           #sysdomain   c
    where  a.table_id  = b.table_id
      and  b.domain_id = c.domain_id
    ;

    update #tablescript
    set    a.max_col = b.max_col
    from   #tablescript a,
          (select  a.table_name
                  ,max(a.column_id) as max_col
           from   #tablescript a
           group by a.table_name) b
    where  a.table_name = b.table_name
    ;

    insert into #temp1
    select  table_name
           ,column_id
           ,column_name||scale_name||trim(null_yn)
            ||case when column_id=max_col then ',' else ',' end as tablescript
    from   #tablescript
    order by table_name,column_id
    ;

    select number(*) cnt,a.table_name,b.column_name
    into   #temp2
    from   #systable  a,
           #syscolumn b
    where  a.table_id = b.table_id
      and  b.pkey = 'Y'
    order by b.table_id,b.column_id;

    insert into #temp1
    select
     a.table_name
    ,(select max(column_id)+1 from #temp1 where table_name = a.table_name) as column_id
    ,'PRIMARY KEY('||
      max(case when a.cnt =  1 then trim(a.column_name)||(case when b.max_cnt <>  1 then ',' else ')' end) else null end)
    ||max(case when a.cnt =  2 then trim(a.column_name)||(case when b.max_cnt <>  2 then ',' else ')' end) else null end)
    ||max(case when a.cnt =  3 then trim(a.column_name)||(case when b.max_cnt <>  3 then ',' else ')' end) else null end)
    ||max(case when a.cnt =  4 then trim(a.column_name)||(case when b.max_cnt <>  4 then ',' else ')' end) else null end)
    ||max(case when a.cnt =  5 then trim(a.column_name)||(case when b.max_cnt <>  5 then ',' else ')' end) else null end)
    ||max(case when a.cnt =  6 then trim(a.column_name)||(case when b.max_cnt <>  6 then ',' else ')' end) else null end)
    ||max(case when a.cnt =  7 then trim(a.column_name)||(case when b.max_cnt <>  7 then ',' else ')' end) else null end)
    ||max(case when a.cnt =  8 then trim(a.column_name)||(case when b.max_cnt <>  8 then ',' else ')' end) else null end)
    ||max(case when a.cnt =  9 then trim(a.column_name)||(case when b.max_cnt <>  9 then ',' else ')' end) else null end)
    ||max(case when a.cnt = 10 then trim(a.column_name)||(case when b.max_cnt <> 10 then ',' else ')' end) else null end)
    as tablescript
    from   #temp2 a,
          (select  a.table_name
                  ,max(a.cnt)     as max_cnt
           from   #temp2 a
           group by a.table_name) b
    where a.table_name = b.table_name
    group by a.table_name
    ;

    insert into #temp1
    select  a.table_name
           ,max(a.column_id)+1 as column_id
           ,');' as tablescript
    from   #temp1 a
    group by a.table_name
    ;

    select a.*
    from   #temp1 a
    order by a.table_name,a.column_id

--    insert into #temp1
--    select (select max(column_id)+1 from #temp1) as column_id
--     ,'GRANT SELECT ON '||i_���̺���||' TO web_iq' as tablescript
--    ,'','',null
--    ;
--
--
--    select  trim(t.table_name)   as table_name
--           ,trim(c.column_name) as column_name
--           ,c.column_id         as column_id
--           ,trim(i.index_type)  as type
--           ,trim(i.index_name)  as index_name
--           ,"UNIQUE"
--           ,case when i.index_type <> 'FP'
--                 then 'CREATE '||i.index_type||' INDEX '||i.index_name||' ON '||t.table_name||' ('||c.column_name||')'
--                 else ''
--            end                 as index_script
--    into   #temp3
--    from   sys.systable t,
--           sys.syscolumn c,
--           sys.sysindex i,
--           sys.sysixcol ic
--    where  t.table_id   = c.table_id
--    and    c.table_id   = i.table_id
--    and    i.table_id   = ic.table_id
--    and    i.index_id   = ic.index_id
--    and    c.column_id  = ic.column_id
--    and    t.server_type = 'IQ'
--    and    t.table_type in( 'BASE','GBL TEMP')
--    and    t.table_name = i_���̺���
--    --and    t.table_name = 'OT_IQF_���_���ʺ�ȯ_CURRENT'
--    and    i.index_type <> 'SA'
--    order by c.column_id
--    ;
--
--    select  a.table_name
--           ,a.column_name
--           --,max(case when a.type = 'FP'  then a.index_name   else '' end) fp_index
--           ,max(case when a.type = 'LF'  then a.index_name   else '' end) as lf_index
--           ,max(case when a.type = 'HG'  then a.index_name   else '' end) as hg_index
--           ,max(case when a.type = 'HNG' then a.index_name   else '' end) as hng_index
--           ,max(case when a.type = 'LF'  then a.index_script else '' end) as lf_index_script
--           ,max(case when a.type = 'HG'  then a.index_script else '' end) as hg_index_script
--           ,max(case when a.type = 'HNG' then a.index_script else '' end) as hng_index_script
--    into   #temp4
--    from   #temp3 a
--    where ( a.type in ('LF','HNG') or (a.type =  'HG' and a.index_name not like 'ASIQ_IDX_%') )
--    group by a.table_name,a.column_name,a.column_id
--    order by a.column_id
--    ;
--
--    select  a.column_id                         as num
--           ,trim(a.tablescript     )            as tablescript
--           ,trim(a.column_name     )            as column_name
--           ,trim(a.scale_name      )            as scale
--           ,a.cardinality                       as ����
--           ,isnull(trim(b.lf_index        ),'') as lf_index
--           ,isnull(trim(b.hg_index        ),'') as hg_index
--           ,isnull(trim(b.hng_index       ),'') as hng_index
--           ,isnull(trim(b.lf_index_script ),'') as lf_index_script
--           ,isnull(trim(b.hg_index_script ),'') as hg_index_script
--           ,isnull(trim(b.hng_index_script),'') as hng_index_script
--    from   #temp1 a,
--           #temp4 b
--    where  a.column_name *= b.column_name
--    order by a.column_id
--    ;


end
GO

GRANT EXECUTE ON sp_maketablescript TO web_iq 
GO
