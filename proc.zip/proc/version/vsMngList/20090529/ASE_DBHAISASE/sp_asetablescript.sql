if  exists ( select 1 from sysobjects 
             where name ='sp_asetablescript'
             and type = 'P')
begin
  DROP procedure sp_asetablescript
end 
GO

create procedure sp_asetablescript
as
begin
--    sp_asetablescript

--    select top 10 * from sysobjects
--    where id = object_id('OT_SEF_���_��������')
--    553870109
--
--    sp_help 'OT_SEF_���_��������'
--
--    select top 1000 *
--
--    select top 10 * from systypes
--
--    select b.colid,b.name,c.name,b.length,b.prec,b.scale,b.type
--    from sysobjects a,
--             syscolumns b,
--             systypes c
--    where a.id = b.id
--    and a.id  = 553870109
--    and b.type = c.type
--    and c.name not in ('sysname', 'longsysname', 'nchar', 'nvarchar')
--

    select a.id,rtrim(a.name) as table_name
    into   #sysobjects
    from   sysobjects a
    --where  a.name in ('OT_SEF_���_��������')
    where  a.name like 'TB%'
    or     a.name like 'OT%'
    or     a.name like 'TM%'

    ----------------------------------------------
    -- drop table
    ----------------------------------------------
    create table #dropscript
    (
        dropscript         varchar(300) null
    )

    insert into #dropscript
    select 'if exists (select 1 from sysobjects where name ='''||table_name||''') drop table '||table_name as dropscript
    from #sysobjects

    ----------------------------------------------
    -- create table
    ----------------------------------------------
    create table #tablescript1
    (
        table_name          varchar(200) null,
        column_id           int          null,
        tablescript         varchar(300) null
    )

    create table #tablescript
    (
        table_name          varchar(200) null,
        column_id           int          null,
        column_name         char(100)    null,
        scale_name          char(20)     null,
        null_yn             char(8)      null
    )

    insert into #tablescript
    select  a.table_name                                            as table_name
           ,0                                                       as column_id
           ,'CREATE TABLE '||a.table_name||' ('                     as column_name
           ,''                                                      as scale_name
           ,''                                                      as null_yn
    from   #sysobjects a

    insert into #tablescript
    select  a.table_name                                            as table_name
           ,b.colid                                                 as column_id
           ,upper(b.name)                                           as column_name
           ,case when c.name = 'int'     then 'int'
                 when c.name = 'numeric' then 'numeric('||cast(b.prec as varchar)||','||cast(b.scale as varchar)||')'
                 else c.name||'('||cast(b.length as varchar)||')'
            end                                                     as scale_name
           ,case when b.status = 0 then 'not null' else 'null' end  as null_yn
    from   #sysobjects    a,
           syscolumns   b,
           systypes   c
    where  a.id = b.id
    and    b.type = c.type
    and    c.name not in ('sysname', 'longsysname', 'nchar', 'nvarchar')

    ----------------------------------------------
    -- create index
    ----------------------------------------------

--    create index ���ſ���_�ֹλ���ڵ�Ϲ�ȣ on dbo.TB_SEF_����_���ſ��� (�ֹλ���ڵ�Ϲ�ȣ)
--    go
--    create unique index ���ſ���_���¹�ȣ on dbo.TB_SEF_����_���ſ��� (���¹�ȣ)
--    go
-- sp_helpconstraint TB_SEF_����_���缱

--    select  a.name
--           ,case when a.status2 & 512 = 512 then 'clustered' else '' end as attr1
--           ,case when a.status  & 2   = 2   then 'unique'    else '' end as attr2
--           ,max(case when a.keycnt > 1 then index_col('TB_SEF_����_���缱',a.indid,1) end||','||
--                case when a.keycnt > 2 then index_col('TB_SEF_����_���缱',a.indid,2) end||','||
--                case when a.keycnt > 3 then index_col('TB_SEF_����_���缱',a.indid,3) end||','||
--                case when a.keycnt > 4 then index_col('TB_SEF_����_���缱',a.indid,4) end||','
--                ) as index_column
--    from  (select name,indid,keycnt,status,status2 from sysindexes
--           where id = object_id('TB_SEF_����_���缱')
--           and indid > 0) a
--    group by a.name

end
GO

sp_procxmode sp_asetablescript, ANYMODE 
GO
GRANT EXEC ON sp_asetablescript TO PUBLIC 
GO
