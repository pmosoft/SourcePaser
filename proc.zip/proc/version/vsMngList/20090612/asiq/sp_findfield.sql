if  exists ( select 1 from sysobjects 
             where name ='sp_findfield'
             and type = 'P')
begin
  DROP procedure sp_findfield
end 
GO

create PROCEDURE sp_findfield 
(
  IN I_�÷��� VARCHAR(100)
)
BEGIN


select a.table_name,b.column_name 
from   systable a,
       SYSCOLUMN b
where  a.table_id = b.table_id
and    b.column_name like '%'||I_�÷���||'%'
order by a.table_name
;


END
GO

GRANT EXECUTE ON sp_findfield TO web_iq 
GO
