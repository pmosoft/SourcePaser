if  exists ( select 1 from sysobjects 
             where name ='SP_SE1_MINE_MGR_1004'
             and type = 'P')
begin
  DROP procedure SP_SE1_MINE_MGR_1004
end 
GO

create proc SP_SE1_MINE_MGR_1004  (@BASEDATE      varchar(8))
as
declare @WORKDATE   varchar ( 8)
      , @HA         varchar ( 1)
      , @HB         varchar ( 1)
      , @HC         varchar ( 1)
      , @CA         varchar ( 1)
      , @CB         varchar ( 1)
      , @CC         varchar ( 1)         /* ������ ī��*/

begin

	if exists(SELECT TRANS_YMD 
	          FROM   MAIS_EAI_FILE_PTCL_ITF 
	          WHERE  TRANS_YMD = @BASEDATE
	            AND  STATUS    = 'Y')
	begin
		
        SELECT @WORKDATE=@BASEDATE
        
        SELECT  @HA = CASE MAX( CASE WHEN substring(FILE_NAME, patindex('%mines_%', FILE_NAME)+6, 2) ='ha' THEN TRANS_END_RECSEQ ELSE 0 END ) WHEN 999999999999999 THEN 'Y' ELSE 'N' END
        	  , @HB = CASE MAX( CASE WHEN substring(FILE_NAME, patindex('%mines_%', FILE_NAME)+6, 2) ='hb' THEN TRANS_END_RECSEQ ELSE 0 END ) WHEN 999999999999999 THEN 'Y' ELSE 'N' END
        	  , @HC = CASE MAX( CASE WHEN substring(FILE_NAME, patindex('%mines_%', FILE_NAME)+6, 2) ='hc' THEN TRANS_END_RECSEQ ELSE 0 END ) WHEN 999999999999999 THEN 'Y' ELSE 'N' END
        FROM    MAIS_EAI_FILE_PTCL_ITF 
        WHERE   TRANS_YMD = @WORKDATE 
          AND   substring(FILE_NAME, patindex('%mines_%', FILE_NAME)+6, 1) = 'h'
          AND   STATUS = 'Y'

        /*
        SELECT  @CA = CASE WHEN MAX( CASE WHEN substring(FILE_NAME, patindex("%mines_%", FILE_NAME)+6, 2) ='ca' THEN CARD_XFIGIBCD  ELSE '0000'     END ) = '9999'
                                AND
                                MIN( CASE WHEN substring(FILE_NAME, patindex("%mines_%", FILE_NAME)+6, 2) ='ca' THEN CARD_TRANS_YMD ELSE '99999999' END ) = @WORKDATE
                                THEN 'Y' 
                           ELSE 'N' 
                      END
              , @CB = CASE WHEN MAX( CASE WHEN substring(FILE_NAME, patindex("%mines_%", FILE_NAME)+6, 2) ='cb' THEN CARD_XFIGIBCD  ELSE '0000'     END ) = '9999'
                                AND
                                MIN( CASE WHEN substring(FILE_NAME, patindex("%mines_%", FILE_NAME)+6, 2) ='cb' THEN CARD_TRANS_YMD ELSE '99999999' END ) = @WORKDATE
                                THEN 'Y' 
                           ELSE 'N' 
                      END
        FROM    MAIS_EAI_FILE_PTCL_ITF
        WHERE   TRANS_YMD in (@WORKDATE, convert(char(8), dateadd(dd, 1, @WORKDATE), 112))
          AND   substring(FILE_NAME, patindex("%mines_%", FILE_NAME)+6, 1) = 'c'
          AND   STATUS                   in ('N')
	    */
	    
        SELECT  @CA = max(case when ä�α����ڵ�='CA' then �������ſ���
                               else 'N'
                          end)
              , @CB = max(case when ä�α����ڵ�='CB' then �������ſ���
                               else 'N'
                          end)
              , @CC = max(case when ä�α����ڵ�='CC' then �������ſ���
                               else 'N'
                          end)
        FROM    TB_SEF_����_�ſ�ī��α�����
        WHERE   �ŷ����� = @BASEDATE
	end
	else
	begin
	
        SELECT @WORKDATE = @BASEDATE
             , @HA       = 'N'
             , @HB       = 'N'
             , @HC       = 'N'
             
        SELECT  @CA = max(case when ä�α����ڵ�='CA' then �������ſ���
                               else 'N'
                          end)
              , @CB = max(case when ä�α����ڵ�='CB' then �������ſ���
                               else 'N'
                          end)
              , @CC = max(case when ä�α����ڵ�='CC' then �������ſ���
                               else 'N'
                          end)
        FROM    TB_SEF_����_�ſ�ī��α�����
        WHERE   �ŷ����� = @BASEDATE
        
	end


	SELECT @WORKDATE    as WORKDATE
	     , @HA          as HA
	     , @HB          as HB
	     , @HC          as HC
	     , @CA          as CA
	     , @CB          as CB
         , @CC          as CC  /* ������ ī��*/

end
GO

sp_procxmode SP_SE1_MINE_MGR_1004, ANYMODE 
GO
GRANT EXEC ON SP_SE1_MINE_MGR_1004 TO PUBLIC 
GO
