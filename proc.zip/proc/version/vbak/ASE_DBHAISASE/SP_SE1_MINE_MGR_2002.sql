if  exists ( select 1 from sysobjects 
             where name ='SP_SE1_MINE_MGR_2002'
             and type = 'P')
begin
  DROP procedure SP_SE1_MINE_MGR_2002
end 
GO

create procedure SP_SE1_MINE_MGR_2002 ( @P_�ŷ�����    CHAR    (8), @P_FILE    VARCHAR    (128))      
as
begin
	UPDATE MAIS_EAI_FILE_PTCL_ITF
	   SET TRANS_RETRY =  TRANS_RETRY + 1
	 WHERE TRANS_YMD = @P_�ŷ�����
	   AND FILE_NAME = @P_FILE

end
GO

sp_procxmode SP_SE1_MINE_MGR_2002, ANYMODE 
GO
GRANT EXEC ON SP_SE1_MINE_MGR_2002 TO PUBLIC 
GO
