if  exists ( select 1 from sysobjects 
             where name ='SP_IQM_MINE_MGR_1003'
             and type = 'P')
begin
  DROP procedure SP_IQM_MINE_MGR_1003
end 
GO


--select * from TB_SEF_����_EAI����




create procedure  SP_IQM_MINE_MGR_1003(@BASEDT CHAR(8), @PSTATUS CHAR(1) )
as

return

GO

sp_procxmode SP_IQM_MINE_MGR_1003, ANYMODE 
GO
GRANT EXEC ON SP_IQM_MINE_MGR_1003 TO PUBLIC 
GO
