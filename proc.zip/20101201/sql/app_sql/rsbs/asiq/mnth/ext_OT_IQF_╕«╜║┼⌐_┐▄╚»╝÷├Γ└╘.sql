/******************************************************************************
-------------------------------------------------------------------------------
  ���α׷���: ext_OT_IQF_����ũ_��ȯ������.sql
  �۾�����  : 
  ���ཀྵ��  : 
  �������  : 
  �����ֱ�  : 
  ��    ��  : 
-------------------------------------------------------------------------------
  INPUT ���̺��� 
-------------------------------------------------------------------------------
  OUTPUT ���̺��� 
-------------------------------------------------------------------------------
  INPUT ���ϸ�  
-------------------------------------------------------------------------------
  OUTPUT ���ϸ�  
  OF    : OT_IQF_����ũ_��ȯ������.dat
-------------------------------------------------------------------------------
  STROED PROCEDURE  
-------------------------------------------------------------------------------
  ��������    �����ڸ�   ��������
-------------------------------------------------------------------------------
  ���
-------------------------------------------------------------------------------
******************************************************************************/

set trimspool on
set term off 
SET echo off
set linesize 1000 
set head off
set pagesize 0
set feedback off
SPOOL /ett/ettdata/rcvdata/rsbs/OT_IQF_����ũ_��ȯ������.dat

whenever oserror  exit failure if an os error occurs
whenever sqlerror exit failure SQL.SQLCODE

SELECT
A.YYYYMM|| '|' ||
A.CD|| '|' ||
T.CNT|| '|' ||  --ATSIGHTLG���Ժ����ݹ������Ǽ�
B.CNT|| '|' ||  --��ȯ���޺��������ޱݰŷ��Ǽ�
C.CNT|| '|' ||  --���Ѻμ���ȯ�������Ժб��ѿ���
D.CNT|| '|' ||  --����ȯ�������ڸ��԰Ǽ�
E.CNT|| '|' ||  --������¡����ҰǼ�
F.CNT|| '|' ||  --���Դ�ݰ�����ҰǼ�
G.CNT|| '|' ||  --��߼۱���ҰǼ�
H.CNT|| '|' ||  --��ǥ����CASH�Ÿ���ҰǼ�
'20080601'|| '|'
FROM
(SELECT '200806' YYYYMM, CD
 FROM OCOM_HANABR
 WHERE OPEN_IL IS NOT NULL
   AND OPEN_IL < TO_DATE('20080701', 'YYYYMMDD')
   AND (CLOSE_IL IS NULL OR CLOSE_IL > TO_DATE('20080630', 'YYYYMMDD'))) A,   
(
SELECT 
      AAA.MNG_BR AS MNG_BR, 
      COUNT(*) AS CNT
FROM                   
    (SELECT BB.MNG_BR, 
            BB.REF_NO,
            BB.SEQ, 
            BB.SSEQ, 
            AA.CHK1
     FROM              
         (SELECT B.MNG_BR,
                 A.REF_NO, 
                 A.SEQ, 
                 A.SSEQ, 
                 'Y' CHK1   -- CHK1 :�������Ա� CHECK
          FROM AFEX_IPB_LGM@DBAFEX2 A, 
               AFEX_IPB_BASE@DBAFEX2 B, 
               AFEX_IPB_BOJ@DBAFEX2 C
          WHERE TO_CHAR(A.AC_IL,'YYYYMM') = '200806'      -- LG�߱���
          AND A.STS = '0'                                                           -- LG�� ����ִ�... 
          AND A.REF_NO = B.REF_NO     
          AND B.IP_CD = '01'                                                        -- Sight��
          AND A.REF_NO = C.REF_NO 
          AND A.SEQ = C.LGM_SEQ
          AND A.SSEQ = DECODE(C.LGM_SSEQ,0,1, C.LGM_SSEQ)
          AND C.IBJI_GB = '1'                                                       -- �������Ա�
          GROUP BY B.MNG_BR, 
                   A.REF_NO, 
                   A.SEQ, 
                   A.SSEQ) AA,
         (SELECT B.MNG_BR,
                 A.REF_NO, 
                 A.SEQ, 
                 A.SSEQ
          FROM AFEX_IPB_LGM@DBAFEX2 A, 
               AFEX_IPB_BASE@DBAFEX2 B
          WHERE TO_CHAR(A.AC_IL,'YYYYMM') = '200806' 
          AND A.STS = '0'
          AND A.REF_NO = B.REF_NO 
          AND B.IP_CD = '01'
          GROUP BY B.MNG_BR,
                   A.REF_NO, 
                   A.SEQ, 
                   A.SSEQ) BB
     WHERE BB.MNG_BR = AA.MNG_BR(+)
     AND BB.REF_NO = AA.REF_NO(+) 
     AND BB.SEQ = AA.SEQ(+)
     AND BB.SSEQ = AA.SSEQ(+)
     AND AA.CHK1 IS NULL ) AAA
GROUP BY AAA.MNG_BR
) T,   --ATSIGHTLG���Ժ����ݹ������Ǽ�
(
SELECT B.MNG_BR AS MNG_BR, 
       COUNT(*) AS CNT      
FROM OFEX_IPB_DJB A, OFEX_IPB_BASE B                       
WHERE TO_CHAR(A.AC_IL,'YYYYMM') = '200806'
AND A.STS <> '1'                                   
AND A.REF_NO = B.REF_NO                            
GROUP BY B.MNG_BR
) B,  --��ȯ���޺��������ޱݰŷ��Ǽ�
(
SELECT A.TR_BR AS TR_BR, 
       COUNT(*) AS CNT           
FROM AFEX_XPB_HIS@DBAFEX2 A, AFEX_XPB_BASE@DBAFEX2 B               
WHERE TO_CHAR(A.AC_IL,'YYYYMM') = '200806'
AND A.TR_CD = '31'                    -- �����Ա�/���ѿ��� 
AND A.STS = '0'                                    
AND A.BE_YMAN_IL IS NOT NULL  -- ���⿬�� ����     
AND A.REF_NO = B.REF_NO                            
AND B.TENOR_GB IN ('4')           -- D/A               
GROUP BY A.TR_BR
) C,  --���Ѻμ���ȯ�������Ժб��ѿ���
(
SELECT B.MNG_BR AS MNG_BR, 
       COUNT(*) AS CNT
FROM AFEX_XPB_LGM@DBAFEX2 A, AFEX_XPB_BASE@DBAFEX2 B                                   
WHERE TO_CHAR(A.GIS_IL,'YYYYMM') = '200806'                
AND A.STS = '0'                                      -- ��������                                      
AND A.REF_NO = B.REF_NO                                            
AND B.STS IN('0','9')                                -- ��������, ���ԿϷ�           
AND B.MNG_BR < '980'                                            
AND B.NEGO_GB = '1'                              -- ���԰�
AND A.HAJA_CD IN( '2','4')                        -- ��������, �����뺸           
GROUP BY B.MNG_BR
) D,  --����ȯ�������ڸ��԰Ǽ�
(
SELECT B.TRX_BR AS TRX_BR, 
       COUNT(*) AS CNT               
FROM OFEX_TRX_PL A, OFEX_TRX_BASE B                                 
WHERE TO_CHAR(A.ACT_IL,'YYYYMM') = '200806'                    
AND SUBSTR(A.IBJI_CD,2,1) = '2'                                     
AND TO_CHAR(B.TRX_IL,'YYYYMM') = '200806'                      
AND A.REF_NO = B.REF_NO                                             
AND A.HIS_NO = B.HIS_NO                                             
AND A.SEG_SEQ IN ( SELECT MIN(C.SEG_SEQ)                            
                   FROM OFEX_TRX_PL C                               
                   WHERE TO_CHAR(A.ACT_IL,'YYYYMM') = '200806' 
                   AND C.REF_NO = A.REF_NO                          
                   AND C.HIS_NO = A.HIS_NO                          
                   AND SUBSTR(C.IBJI_CD,2,1) = '2')                 
AND B.STS = '0'                                                     
GROUP BY B.TRX_BR
) E,  --������¡����ҰǼ�
(
SELECT A.TR_BR AS TR_BR, 
       COUNT(*) AS CNT
FROM  AFEX_IPB_HIS@DBAFEX2 A                                           
WHERE TO_CHAR(A.AC_IL,'YYYYMM') = '200806'                        
AND A.STS = '1'                                                        
AND A.TR_BR < '980'                                                    
AND A.TR_CD IN ('46')                                                  
GROUP BY A.TR_BR
) F,  --���Դ�ݰ�����ҰǼ�
(
SELECT B.MNG_BR, 
       COUNT(*) AS CNT
FROM AFEX_ROB_HIS@DBAFEX2 A, AFEX_ROB_BASE@DBAFEX2 B       
WHERE TO_CHAR(A.AC_IL,'YYYYMM') = '200806'  -- �Ⱓ(���ŷ�����) 
AND A.STS = '1'                                  -- ���             
AND B.MNG_BR < '980'                             -- ����             
AND B.RT_CD IN ('1','4','5')                     -- '1'D/D,'4'T/T,'5'KEB)
AND A.TR_CD IN ('18')
AND A.REF_NO = B.REF_NO
GROUP BY B.MNG_BR 
) G,  --��߼۱���ҰǼ�
(
SELECT AA.A1 AS BR, 
       COUNT(*) AS CNT
FROM                                                                              
     (SELECT AC_IL,
             TR_BR A1,  
             SUM(DECODE(SUBSTR(REF_NO,1,3), 'FCB',1,0)) N1,   -- ��ȭ��ǥ����  
             SUM(DECODE(SUBSTR(REF_NO,1,3), 'FCC',1,0)) N2,   -- ��ȭ��ǥ�߽�                        
             0 N3, 
	     0 N4                                                                                      
      FROM AFEX_CBB_HIS@DBAFEX2                                                                            
      WHERE TO_CHAR(AC_IL,'YYYYMM') = '200806'     -- �Ⱓ(���ŷ�����)                                
      AND STS = '1'                                                                -- ���                            
      AND TR_BR < '980'                                                            -- ����     
      AND TR_CD IN( '17','18')                                                     -- ��Ұŷ�                       
      GROUP BY AC_IL,TR_BR                                                                       
      UNION ALL                                                                             
      SELECT AC_IL,
             MNG_BR A1,  
             0 N1, 
	     0 N2,                                                        
             SUM(DECODE(SUBSTR(TR_CD,1,2), '31',1,0)) N3,       -- �ܱ���ȭ����                  
             SUM(DECODE(SUBSTR(TR_CD,1,2), '32',1,0)) N4        -- �ܱ���ȭ�ŵ�                                  
      FROM AFEX_RTB_BASE@DBAFEX2                                                                    
      WHERE TO_CHAR(AC_IL,'YYYYMM') = '200806'                                 
      AND STS = '1'                                                                     
      AND MNG_BR < '980'                                                                        
      GROUP BY AC_IL,MNG_BR) AA                                                                   
GROUP BY AA.A1
) H  --��ǥ����CASH�Ÿ���ҰǼ�
WHERE A.CD = T.MNG_BR(+)
  AND A.CD = B.MNG_BR(+)
  AND A.CD = C.TR_BR(+)
  AND A.CD = D.MNG_BR(+)
  AND A.CD = E.TRX_BR(+)
  AND A.CD = F.TR_BR(+)
  AND A.CD = G.MNG_BR(+)
  AND A.CD = H.BR(+) ;
exit;
SPOOL off