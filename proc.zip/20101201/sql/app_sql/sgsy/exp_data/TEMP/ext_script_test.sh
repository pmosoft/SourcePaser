dbisqlc -c dsn=HAISIQ_ETT -q ext_$1.sql
#cd /bct/temp
#ftp -n 111.15.19.43 21 << EOF
#user ais ais123
#cd /bct/temp
#get $1.dat
#bye
#EOF
#
#chmod 777 $1.dat
#dbisqlc -c dsn=HAISIQ_ETT -q /ett/app/pgm/sql/app_sql/sgsy/exp_data/load_$1.sql