dbisqlc -c dsn=HAISIQ_REAL -q ext_$1.sql
cd /bct/temp
ftp -n 111.16.4.83 21 << EOF
user ais ais11
cd /bct/temp
get $1.dat
bye
EOF

chmod 777 $1.dat
dbisqlc -c dsn=HAISIQ_ETT -q /ett/app/pgm/sql/app_sql/sgsy/exp_data/load_$1.sql