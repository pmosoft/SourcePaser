dbisqlc -c dsn=HAISIQ_ETT -q /ais_ett/app/pgm/sql/app_sql/sgsy/exp_data/ext_$1.sql

dbisqlc -c dsn=DBPAIS2 -q /ais_ett/app/pgm/sql/app_sql/sgsy/exp_data/load_$1.sql