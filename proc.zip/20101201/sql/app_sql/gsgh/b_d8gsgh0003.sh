#!/bin/sh
. /ais_ett/.aiscfg
. /ais_ett/.common_function

DATE=`date +%Y%m%d`
BASE_NAME=`basename $0`
BASE_CUT=`echo $BASE_NAME | sed -e s/.sh//g `
LOG_FILE=${gsgh_log}/${BASE_CUT}_${DATE}.log
LOG_ERR=${gsgh_err_log}/${BASE_CUT}_${DATE}.log
LOCAL_LOG=${gsgh_log}/${BASE_CUT}_sql_${DATE}.log
FILENAME="ins_OT_SEU_��ȹ_�繫�μ����"

echo "LOG_FILE ==> tail -f $LOG_FILE"
echo "ERR_FILE ==> tail -f $LOG_ERR"

echo "" > $LOG_FILE
echo "" > $LOG_ERR
startLog "Start ${FILENAME}" $LOG_FILE

#######################################
## ins_OT_SEU_��ȹ_�繫�μ����
#######################################
isql -U${aseid} -P${asepw} -S${asesv} -i "${app_gsgh}/${FILENAME}.sql" > $LOCAL_LOG
#isql -Uett_ase -Pais111 -SDBDSND1 -i "/ett/app/pgm/sql/app_sql/gsgh/ins_OT_SEU_��ȹ_�繫�μ����.sql
###/ett/app/pgm/sql/app_sql/gsgh/ins_OT_SEU_��ȹ_�繫�μ����.sql

cat $LOCAL_LOG >> $LOG_ERR
${bin_dir}/cmm_err_find.sh $LOCAL_LOG
Result=$?
assert $Result "${FILENAME}" $LOG_FILE $LOG_ERR "" $LINENO

