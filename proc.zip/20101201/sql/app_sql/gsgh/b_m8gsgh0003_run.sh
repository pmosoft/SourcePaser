#! /bin/sh
. /ais_ett/.aiscfg
. /ais_ett/.common_function

#----------------------------------------------------------------------------------------------#
# ins_OT_IQF_���_������ī�� Shell Script
# ���� �۾� Schedule �� ������.
#----------------------------------------------------------------------------------------------#
DATE=`date +%Y%m%d`

BASE_NAME=`basename $0`
BASE_CUT=`echo $BASE_NAME | sed -e s/.sh//g`

LOG_FILE=${gsgh_log}/${BASE_CUT}_${DATE}.log
LOG_ERR=${gsgh_err_log}/${BASE_CUT}_${DATE}.log

BASEDATE=`echo $1`
sed "s/@@@@@@@@/$BASEDATE/" ${app_gsgh}/OT_IQU_��ȹ_�濵��.sql > ${app_gsgh}/RUN_OT_IQU_��ȹ_�濵��.sql

EXE_SQL=${app_gsgh}/RUN_OT_IQU_��ȹ_�濵��.sql

echo $BASE_NAME " start dbisqlc -q ${EXE_SQL} " `date '+%Y-%m-%d %T'`
echo $BASE_NAME " start dbisqlc -q ${EXE_SQL} " `date '+%Y-%m-%d %T'` > ${LOG_FILE}

#${bin_dir}/cmm_chk_iqconnect.sh  #-- ASIQ Connection ���� üũ Loop

dbisqlc -c DSN=DBPAIS2 -q $EXE_SQL 2> ${LOCAL_LOG}

cat $LOCAL_LOG >> $LOG_ERR
${bin_dir}/cmm_err_find.sh $LOCAL_LOG
Result=$?
assert $Result "${FILENAME}" $LOG_FILE $LOG_ERR "" $LINENO

if [ $? -eq 0 ]
then
    echo $BASE_NAME "end  dbisqlc -q ${EXE_SQL} " `date '+%Y-%m-%d %T'`
    echo $BASE_NAME "end  dbisqlc -q ${EXE_SQL} " `date '+%Y-%m-%d %T'` >> ${LOG_FILE}
else
    cat  ${LOCAL_LOG}                                                         >> ${LOG_FILE}
    echo $BASE_NAME "error dbisqlc Log : ${LOG_FILE}  " `date '+%Y-%m-%d %T'`
    echo $BASE_NAME "error dbisqlc Log : ${LOG_FILE}  " `date '+%Y-%m-%d %T'` >> ${LOG_FILE}
    exit 1
fi

exit
