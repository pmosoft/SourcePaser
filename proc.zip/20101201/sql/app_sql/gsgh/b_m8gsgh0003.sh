#! /bin/sh
. /ais_ett/.aiscfg
. /ais_ett/.common_function
#----------------------------------------------------------------------------------------------#
# OT_IQU_��ȹ_�濵�� batch�۾�
# �� �۾� Schedule �� ������.
#----------------------------------------------------------------------------------------------#

DATE=`date +%Y%m%d`
BASE_NAME=`basename $0`
BASE_CUT=`echo $BASE_NAME | sed -e s/.sh//g `
LOG_FILE=${gsgh_log}/${BASE_CUT}_${DATE}.log
LOG_ERR=${gsgh_err_log}/${BASE_CUT}_${DATE}.log
LOCAL_LOG=${gsgh_log}/${BASE_CUT}_sql_${DATE}.log
FILENAME="OT_IQU_��ȹ_�濵��_Y09"

echo "LOG_FILE ==> tail -f $LOG_FILE"
echo "ERR_FILE ==> tail -f $LOG_ERR"

echo "" > $LOG_FILE
echo "" >> $LOG_ERR
startLog "Start ${FILENAME}" $LOG_FILE

dbisqlc -c dsn=DBPAIS2 -q "${app_gsgh}/${FILENAME}.sql" 2> $LOCAL_LOG

cat $LOCAL_LOG >> $LOG_ERR
${bin_dir}/cmm_err_find.sh $LOCAL_LOG
Result=$?
assert $Result "${FILENAME}" $LOG_FILE $LOG_ERR "" $LINENO

