#!/bin/sh
. /ais_ett/.aiscfg
. /ais_ett/.common_function

DATE=`date +%Y%m%d`
BASE_NAME=`basename $0`
BASE_CUT=`echo $BASE_NAME | sed -e s/.sh//g `
LOG_FILE=${gsgh_log}/${BASE_CUT}_${DATE}.log
LOG_ERR=${gsgh_err_log}/${BASE_CUT}_${DATE}.log
LOCAL_LOG=${gsgh_log}/${BASE_CUT}_sql_${DATE}.log
FILENAME1="unload_TM_SEF_�˻��ȹ_�ϻ󰨻�"
FILENAME2="TM_SEF_�˻��ȹ_�ϻ󰨻�"
FILENAME3="�˻��ȹ_�ϻ󰨻�_������"
SPOOL_FILE=${rcv_gsgh}/TM_SEF_�˻��ȹ_�ϻ󰨻�.dat

echo "LOG_FILE ==> tail -f $LOG_FILE"
echo "ERR_FILE ==> tail -f $LOG_ERR"
echo "SPOOL_FILE ==> tail -100 $SPOOL_FILE"

echo "" > $LOG_FILE
echo "" > $LOG_ERR
startLog "Start ${FILENAME1}" $LOG_FILE

########################################
### unload_TM_SEF_�˻��ȹ_�ϻ󰨻�
########################################
#sqlplus -S ${odsid}/${odspw}@DBODS1 @${app_gsgh}/${FILENAME1}
#Result=$?
#assert $Result "${FILENAME1}" $LOG_FILE $LOG_ERR $SPOOL_FILE $LINENO
#
########################################
### del_TM_SEF_�˻��ȹ_�ϻ󰨻�
########################################
#isql -U${aseid} -P${asepw} -S${asesv} -i "${app_gsgh}/del_${FILENAME2}.sql" > $LOCAL_LOG
#cat $LOCAL_LOG >> $LOG_ERR
#${bin_dir}/cmm_err_find.sh $LOCAL_LOG
#Result=$?
#assert $Result "${FILENAME2}" $LOG_FILE $LOG_ERR "" $LINENO
#
########################################
### bcp in TM_SEF_�˻��ȹ_�ϻ󰨻�
########################################
#bcp ${FILENAME2} in "${SPOOL_FILE}" -c -r'|\n' -t '|' -b10000 -m -U${aseid} -P${asepw} -S${asesv} >> $LOG_FILE
##bcp TM_SEF_�˻��ȹ_�ϻ󰨻� in "/ett/ettdata/rcvdata/gsgh/TM_SEF_�˻��ȹ_�ϻ󰨻�.dat" -c -r'|\n' -t '|' -b10000 -m -Uett_ase -Pais111 -SDBDSND1 >> $LOG_FILE
#Result=$?
#assert $Result "bcp ${FILENAME2}" $LOG_FILE $LOG_ERR "" $LINENO
#
########################################
### �˻��ȹ_�ϻ󰨻�_������
########################################
#isql -U${aseid} -P${asepw} -S${asesv} -i "${app_gsgh}/${FILENAME3}.sql > $LOCAL_LOG
##isql -Uett_ase -Pais111 -SDBDSND1 -i "/ais_ett/app/pgm/sql/app_sql/gsgh/�˻��ȹ_�ϻ󰨻�_������.sql"
#cat $LOCAL_LOG >> $LOG_ERR
#${bin_dir}/cmm_err_find.sh $LOCAL_LOG
#Result=$?
#assert $Result "${FILENAME3}" $LOG_FILE $LOG_ERR "" $LINENO

