set temporary option Temp_Extract_Name1 = '/ais_ett/ettdata/rcvdata/cmmn/ase/day/TB_IQF_����_�߷�����.dat';
set temporary option Temp_Extract_Column_Delimiter = '|';
set temporary option Temp_Extract_NULL_As_Zero = 'On';

select * from ett_iq.TB_IQF_����_�߷�����;

set temporary option Temp_Extract_NULL_As_Zero = 'Off';
set temporary option Temp_Extract_Column_Delimiter = ',';
set temporary option Temp_Extract_Name1 = '';
