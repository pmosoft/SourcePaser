set temporary option Temp_Extract_Name1 = '/ais_ett/ettdata/rcvdata/cmmn/ase/day/OT_IQF_����_�λ�.dat';
set temporary option Temp_Extract_Column_Delimiter = '|';
set temporary option Temp_Extract_NULL_As_Zero = 'On';

select * FROM OT_IQF_����_�λ�
;

set temporary option Temp_Extract_NULL_As_Zero = 'Off';
set temporary option Temp_Extract_Column_Delimiter = ',';
set temporary option Temp_Extract_Name1 = '';
