
set trimspool on
set term off 
SET echo off
set linesize 1000 
set head off
set pagesize 0
set feedback off
SPOOL /ett/ettdata/rcvdata/cmmn/asiq/day/TM_IQF_����_������.dat

whenever oserror  exit failure if an os error occurs
whenever sqlerror exit failure SQL.SQLCODE

SELECT
   DEPT_NO || '|' ||
   BLNG_DEPT_NM || '|' ||
   HGRK_DEPT_NO || '|' ||
   PRF_RANK || '|' ||
   BR_NO || '|' ||
   TEL_NO || '|' ||
   FAX_NO || '|' ||
   ZIP_NO || '|' ||
   WKOF_ZIP_ADR || '|' ||
   TO_CHAR(SYSDATE,'YYYYMMDD') || '|' ||
   TO_CHAR(SYSDATE,'HHMISS') || '|'    
FROM OCOM_JIJU_BRCD;
exit;
SPOOL off