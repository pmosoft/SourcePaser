/*

sp_mon_iqconn

select * from temp_iq_connTable

*/

if    exists ( select   1
               from     sysprocedure
               where    proc_name = 'sp_mon_iqconn' ) then
      drop procedure sp_mon_iqconn;
end if;

create procedure sp_mon_iqconn()
begin

create table #temp_iq_connTable
(
    Number                unsigned bigint        null,
    IQconnID              unsigned bigint        null,
    numIQCursors          unsigned integer       null,
    IQthreads             unsigned integer       null,
    TxnID                 unsigned bigint        null,
    ConnOrCurCreateTime   datetime               null,
    CmdLine               varchar(4096)          null,
    CurrOrConn            char(4096)             null,
    IQGovernPriority      char(14)               null
)
;

truncate table #temp_iq_connTable;

execute immediate with quotes on 'iq utilities main into #temp_iq_connTable command statistics 80000';

insert into temp_iq_connTable select getdate(),* from #temp_iq_connTable;

commit;

end