/*

ó������        : ���հ��� ASIQ �Ϻ���Ÿ����
���ཀྵ          : /ais_ett/app/pgm/bin/cmmn/asiq/day/b_d8cmmn_monitoring_8248.sh
������          : d8cmmn8248
������̺�      : sysobjects
                  systabstats
�������̺�      : TB_IQF_����_���հ����Ϻ���Ÿ

ó������ :

--------------------------------------------------------------------------
��������   ������ ��������
--------------------------------------------------------------------------
2008-04-02 �ǽ��� �ű�
--------------------------------------------------------------------------*/
/*

  DROP TABLE TB_IQF_����_���հ����Ϻ���Ÿ

  CREATE TABLE TB_IQF_����_���հ����Ϻ���Ÿ
  (
      ��������                CHAR(8)             NOT NULL,
      ����ð�                CHAR(10)            NULL,
      ���̺���                CHAR(100)           NOT NULL,
      �Ǽ�                    INT                 NULL,
      �÷���                  INT                 NULL,
      RecSize                 INT                 NULL,
      KBytes                  INT                 NULL,
      �����Ͻ�                CHAR(17)            NULL,
      �����Ͻ�                CHAR(17)            NULL,
      PRIMARY KEY(��������,���̺���)
  )


*/



begin

  declare v_tablename char(128);


  create table #spt_iqtablesize_size
  (
      Ownername varchar(128) null,
      Tablename varchar(128) null,
      Columns integer null,
      KBytes integer null,
      Pages integer null,
      CompressedPages integer null,
      NBlocks integer null,
  );

  create table #spt_iqtablesize_count
  (
      Tablename varchar(128) null,
      NRows integer null,
  );

  create table #sysiqtable
  (
      Tablename varchar(128) null,
      �����Ͻ�  CHAR(17) null,
      �����Ͻ�  CHAR(17) null,
  );

  insert into #sysiqtable
  select  a.table_name                                                                 as Tablename
         ,convert(char(10),b.create_time,102)||' '||convert(char(8),b.create_time,108) as �����Ͻ�
         ,convert(char(10),b.update_time,102)||' '||convert(char(8),b.update_time,108) as �����Ͻ�
  from   systable a,
         sysiqtable b
  where  a.table_id = b.table_id
  and    a.table_type = 'BASE'
  and    a.creator not in (0,1,3,4)
  --and    a.table_name like 'TM_IQU_��%'
  order by a.table_name
  ;

  select * into #sysiqtable2 from #sysiqtable;
  --TRUNCATE TABLE TEMP4 ;

  LB1:
  LOOP

      SELECT TOP 1 Tablename INTO v_tablename FROM #sysiqtable;

      --insert into TEMP4 VALUES (v_tablename,convert(char(10),now(*),102)||' '||convert(char(8),now(*),108),convert(char(10),now(*),102)||' '||convert(char(8),now(*),108));
      --commit;

      execute immediate 'IQ UTILITIES MAIN INTO #spt_iqtablesize_size TABLE SIZE ' || v_tablename;
      execute immediate 'INSERT INTO #spt_iqtablesize_count SELECT '''|| v_tablename || ''',count(*) FROM ' || v_tablename;

      DELETE FROM #sysiqtable where Tablename = v_tablename;

      IF NOT EXISTS (SELECT 1 FROM #sysiqtable)THEN
          LEAVE LB1 ;
      END IF;

  END LOOP LB1;

  delete from TB_IQF_����_���հ����Ϻ���Ÿ
  where �������� = convert(char(8),getdate(),112);

  insert into TB_IQF_����_���հ����Ϻ���Ÿ
  select  convert(char(8),getdate(),112)             as ��������
         ,convert(char(8),getdate(),108)             as ����ð�
         ,a.Tablename                                as ���̺���
         ,b.NRows                                    as �Ǽ�
         ,a.Columns                                  as �÷���
         ,tablewidth(a.Ownername||'.'||a.Tablename)  as "RecSize"
         ,a.KBytes                                   as "KBytes"
         ,c.�����Ͻ�                                 as �����Ͻ�
         ,c.�����Ͻ�                                 as �����Ͻ�
  from   #spt_iqtablesize_size  a,
         #spt_iqtablesize_count b,
         #sysiqtable2 c
  where  a.Tablename = b.Tablename
  and    a.Tablename = c.Tablename
  order by a.Tablename
  ;

end




--delete from TB_IQF_����_���հ����Ϻ���Ÿ
--where �������� = convert(char(8),getdate(),112)
--
--insert into TB_IQF_����_���հ����Ϻ���Ÿ
--select  convert(char(8),getdate(),112)             as ��������
--       ,convert(char(8),getdate(),108)             as ����ð�
--       ,a.table_name                               as ���̺���
--       ,0                                          as �Ǽ�
--       ,convert(char(10),b.create_time,102)||' '||convert(char(8),b.create_time,108) as �����Ͻ�
--       ,convert(char(10),b.update_time,102)||' '||convert(char(8),b.update_time,108) as �����Ͻ�
--from   systable a,
--       sysiqtable b
--where  a.table_id = b.table_id
--and    a.table_type = 'BASE'
--and    a.creator not in (0,1,3,4)
--order by a.table_name
--



--if  exists ( select 1 from sysobjects
--             where name ='sp_iq_tablesize'
--             and type = 'P')
--begin
--  DROP procedure sp_iq_tablesize
--end
--GO
--
-----------------------------------------------------------------
--
--create procedure sp_iq_tablesize(table_pattern char(128))
--
--begin
--
--declare table_name char(128);
--declare user_name char(128);
--declare end_of_cursor exception for sqlstate value '02000';
--
--//List of the table concerned by the procedure
--declare local temporary table spt_iqtablesize_tablelist(
--user_name char(128) null,
--table_name char(128) null,
--) in SYSTEM on commit preserve rows;
--
--//Cursor on the previous list
--declare magic_cursor dynamic scroll cursor for select user_name,table_name from spt_iqtablesize_tablelist;
--
--//Temporary table to store the number of blocks used by each table
--declare local temporary table spt_iqtablesize_size(
--Ownername varchar(128) null,
--Tablename varchar(128) null,
--Columns integer null,
--KBytes integer null,
--Pages integer null,
--CompressedPages integer null,
--NBlocks integer null,
--) in SYSTEM on commit preserve rows;
--
--//Temporary table to store the number of rows in each table
--declare local temporary table spt_iqtablesize_count(
--Ownername varchar(128) null,
--Tablename varchar(128) null,
--NRows integer null,
--) in SYSTEM on commit preserve rows;
--
--// Fill spt_iqtablesize_tablelist table
--execute immediate 'insert into spt_iqtablesize_tablelist SELECT user_name, table_name FROM sys.systable, sys.sysuserperm WHERE sys.systable.creator = sys.sysuserperm.user_id AND table_name LIKE ''' || table_pattern || ''''
--||' and exists (select 1 from sysiqtable where table_id = systable.table_id)';
--
--  IF @@Rowcount =0 THEN
--     select ' No table found -     usage : ap_tablesize ''table_pattern(p%)'' ' Error_message
--  ELSE
--
--open magic_cursor;
--
--magic_loop:
--loop
--   fetch next magic_cursor into user_name,table_name;
--   if sqlstate = end_of_cursor then leave magic_loop
--   end if;
--   execute immediate 'IQ UTILITIES MAIN INTO spt_iqtablesize_size TABLE SIZE ' || user_name || '.' || table_name;
--
--   execute immediate 'INSERT INTO spt_iqtablesize_count (Ownername, Tablename, NRows)
--                    SELECT ''' || user_name || ''',''' || table_name || ''',count(*) FROM ' || user_name || '.' || table_name
--
--end loop magic_loop;
--
--close magic_cursor;
--
--//Here are finally the results
--select
--    a.Ownername,
--    a.Tablename,
--    Columns,
--    tablewidth(a.Ownername||'.'||a.Tablename) as "RecSize",
--    NRows as "Rows",
--    KBytes,
--    Pages,
--    CompressedPages
--from spt_iqtablesize_size a inner join spt_iqtablesize_count b
--on (a.Ownername = b.Ownername and a.Tablename = b.Tablename)
--order by 1,2
--
--END IF;
--
--// Clean up the mess
--drop table spt_iqtablesize_size;
--drop table spt_iqtablesize_count;
--drop table spt_iqtablesize_tablelist
--
--end GO
--
--sp_procxmode sp_iq_tablesize, ANYMODE
--GO
--GRANT EXECUTE ON sp_iq_tablesize TO web_iq
--GO
--
-----------------------------------------------------------------
--
--
--
--
--
--
--
-------------------------------------------------------------------
--
--create table #spt_iqtablesize_size
--(
--Ownername varchar(128) null,
--Tablename varchar(128) null,
--Columns integer null,
--KBytes integer null,
--Pages integer null,
--CompressedPages integer null,
--NBlocks integer null,
--)
--
--execute immediate 'IQ UTILITIES MAIN INTO #spt_iqtablesize_size TABLE SIZE TB_IQF_����_�ϳ�������ȭ����';
