
SET SERVEROUTPUT ON SIZE 4000;

DECLARE
    V_TRSC_DT          CHAR(8);
    V_�Ǽ�             INT;
BEGIN

    ------------------------------------
    -- 1. �ŷ��Ǽ�
    ------------------------------------

    BEGIN
        SELECT /*+ FIRST_ROWS */
               TRSC_DT
        INTO   V_TRSC_DT
        FROM   IGAM_CTR_TEMP
        WHERE  TRSC_DT = to_char(sysdate,'yyyymmdd')
        AND    ROWNUM = 1
        ;
        --EXCEPTION����
        --    WHEN OTHERS THEN����
        --    DBMS_OUTPUT.PUT_LINE(SQLERRM);
        --    DBMS_OUTPUT.PUT_LINE('IGAM_CTR_TEMP ������ ������');
        --    RETURN;��
    END;



END;
/
quit;

--
--    BEGIN
--        SELECT /*+ FIRST_ROWS */
--               TRSC_DT
--        INTO   V_TRSC_DT
--        FROM   IGAM_CTR_TRAN
--        WHERE  TRSC_DT = to_char(sysdate,'yyyymmdd')
--        AND    ROWNUM = 1
--        ;
--        EXCEPTION����
--            WHEN OTHERS THEN����
--            DBMS_OUTPUT.PUT_LINE(SQLERRM);
--            DBMS_OUTPUT.PUT_LINE('IGAM_CTR_TRAN ������ ������');
--            RETURN;��
--    END;
--
--
--    -------------------------------
--    -- 2. �ŷ��ݾ�
--    -------------------------------
--
--    BEGIN
--        SELECT /*+ FIRST_ROWS */
--               TRSC_DT
--        INTO   V_TRSC_DT
--        FROM   IGAM_CTR_TRAN
--        WHERE  TRSC_DT = to_char(sysdate,'yyyymmdd')
--        AND    TRSC_AMT = 0
--        AND    ROWNUM = 1
--        ;
--        EXCEPTION����
--            WHEN OTHERS THEN����
--            DBMS_OUTPUT.PUT_LINE(SQLERRM);
--            DBMS_OUTPUT.PUT_LINE('IGAM_CTR_TRAN �ŷ��ݾ� 0 ����');
--            RETURN;��
--    END;
--
--
--    -------------------------------
--    -- 3. TEMP,TRAN �ݾ׺�
--    -------------------------------
--
----    SELECT JOB_DV_CD,COUNT(*)
----    FROM IGAM_CTR_SECR
----    WHERE TRSC_DT = '20070320'
----    GROUP BY JOB_DV_CD
----    ;
--
----    SELECT *
----    FROM   IGAM_CTR_TEMP
----    WHERE  TRSC_DT = to_char(sysdate,'yyyymmdd')
----    AND    TRSC_AMT = 0
----    ;
----    SELECT *
----    FROM   IGAM_CTR_TRAN
----    WHERE  TRSC_DT = to_char(sysdate,'yyyymmdd')
----    AND    TRSC_AMT = 0
----    ;
----
----    SELECT A.TRSC_DT,A.LOG_BR_NO,A.LOG_NO,A.BIZ_DV_CD,A.TRSC_AMT
----    FROM  (SELECT  A.TRSC_DT       AS TRSC_DT
----                  ,A.LOG_BR_NO     AS LOG_BR_NO
----                  ,A.LOG_NO        AS LOG_NO
----                  ,A.BIZ_DV_CD     AS BIZ_DV_CD
----                  ,SUM(A.TRSC_AMT) AS TRSC_AMT
----           FROM   IGAM_CTR_TEMP A
----           WHERE  TRSC_DT = to_char(sysdate,'yyyymmdd')
----           GROUP BY A.TRSC_DT,A.LOG_BR_NO,A.LOG_NO,A.BIZ_DV_CD) A,
----          (SELECT  A.TRSC_DT
----                  ,A.LOG_BR_NO
----                  ,A.LOG_NO
----                  ,A.BIZ_DV_CD
----                  ,A.JOB_SEQ_NO
----                  ,SUM(A.TRSC_AMT) AS TRSC_AMT
----           FROM   IGAM_CTR_TRAN A
----           WHERE  TRSC_DT = to_char(sysdate,'yyyymmdd')
----           AND    A.JOB_SEQ_NO = 1
----           AND    A.EXCN_YN <> '3'
----           GROUP BY A.TRSC_DT,A.LOG_BR_NO,A.LOG_NO,A.BIZ_DV_CD,A.JOB_SEQ_NO) B
----    WHERE  A.TRSC_DT    = B.TRSC_DT
----    AND    A.LOG_BR_NO  = B.LOG_BR_NO
----    AND    A.LOG_NO     = B.LOG_NO
----    AND    A.BIZ_DV_CD  = B.BIZ_DV_CD
----    AND    A.TRSC_AMT  <> B.TRSC_AMT
----    ;
----
----    -------------------------------
----    -- 3. �ڱ�ռ�ǥ
----    -------------------------------
--
---------------------------------------------------------------------------------
----                              �ʼ��׸� üũ
---------------------------------------------------------------------------------
--
------------------------------------
---- ������ȣ NULL üũ
------------------------------------
--SELECT COUNT(*) FROM IGAM_CTR_TRAN
--WHERE TRSC_DT BETWEEN '20070302' AND '20070307'
--AND   DOC_NO IS NULL
--;
--
------------------------------------
---- ��ǥ������ȣ NULL üũ
------------------------------------
--SELECT COUNT(*) FROM IGAM_CTR_TRAN
--WHERE TRSC_DT BETWEEN '20070302' AND '20070307'
--AND   RPS_DOC_NO IS NULL
--;
--
------------------------------------
---- �Ϸù�ȣ 0 üũ
------------------------------------
--SELECT COUNT(*) FROM IGAM_CTR_TRAN
--WHERE TRSC_DT BETWEEN '20070302' AND '20070307'
--AND   SEQ__NO = '0'
--;
--
---------------------------------------------------------------------------------
----                              �����׸� üũ
---------------------------------------------------------------------------------
--
------------------------------------
---- TOTL_NCNT�� �Ǽ��� üũ
------------------------------------
--
--SELECT  A.*
--FROM   (SELECT  TRSC_DT
--               ,ACNM_NO
--               ,TOTL_NCNT
--        FROM   IGAM_CTR_TRAN
--        WHERE  TRSC_DT between '20070302' and '20070307'
--        AND    JOB_SEQ_NO = '1'
--        GROUP BY TRSC_DT,ACNM_NO,TOTL_NCNT) A,
--       (SELECT  TRSC_DT
--               ,ACNM_NO
--               ,COUNT(*) AS TOTL_NCNT
--        FROM   IGAM_CTR_TRAN
--        WHERE  TRSC_DT between '20070302' and '20070307'
--        AND    JOB_SEQ_NO = '1'
--        GROUP BY TRSC_DT,ACNM_NO) B
--WHERE  A.TRSC_DT = B.TRSC_DT
--AND    A.ACNM_NO = B.ACNM_NO
--AND    A.TOTL_NCNT <> B.TOTL_NCNT
--;
--
-----------------------------------------
---- ��ǥ������ȣ�� 1�̻� TOTL_NCNT ����
-----------------------------------------
--SELECT  ACNM_NO
--       ,SEQ_NO
--       ,SECR_SEQ_NO
--       ,TOTL_NCNT
--       ,DOC_NO
--       ,RPS_DOC_NO
--       ,CPLT_DV_CD
--FROM   IGAM_CTR_TRAN
--WHERE  TRSC_DT BETWEEN '20070302' AND '20070307'
--AND    RPS_DOC_NO IN
--      (SELECT RPS_DOC_NO
--       FROM  (SELECT RPS_DOC_NO,TOTL_NCNT
--              FROM  IGAM_CTR_TRAN
--              WHERE TRSC_DT BETWEEN '20070302' AND '20070307'
--              AND   DOC_NO IS NOT NULL
--              GROUP BY RPS_DOC_NO,TOTL_NCNT)
--       GROUP BY RPS_DOC_NO
--       HAVING COUNT(*) > 1)
--ORDER BY ACNM_NO,SEQ_NO,TOTL_NCNT
--;
--
-----------------------------------------
---- �ݾ��� 5õ�������� ���翩��
-----------------------------------------
--SELECT  TRSC_DT
--       ,ACNM_NO
--       ,SUM(TRSC_AMT)
--FROM   IGAM_CTR_TRAN
--WHERE  TRSC_DT BETWEEN '20070302' AND '20070307'
--AND    JOB_SEQ_NO = '1'
--GROUP BY TRSC_DT,ACNM_NO
--HAVING SUM(TRSC_AMT) < 50000000
--;
--
--
--
--
