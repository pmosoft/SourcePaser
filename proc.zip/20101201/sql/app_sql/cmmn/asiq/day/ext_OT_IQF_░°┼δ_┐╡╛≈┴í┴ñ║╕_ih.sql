set temporary option Temp_Extract_Name1 = '/bct/temp/ext_TB_IQF_����_����������_99991231.dat';
set temporary option Temp_Extract_Column_Delimiter = '#|';
set temporary option Temp_Extract_Row_Delimiter = '@@\n';
set temporary option Temp_Extract_NULL_As_Zero = 'on';
 
SELECT                                                                                             
 case when length(trim(����ȣ))=3 then '0'||trim(����ȣ) else trim(����ȣ) end                                                                      
,trim(����)                                                                                                                                         
,trim(������)                                                                                                                                     
,trim(������������)                                                                                                                                 
,trim(��������������)                                                                                                                             
,trim(�������ڵ�)                                                                                                                                   
,trim(��������)                                                                                                                                     
,trim(��������)                                                                                                                                     
,trim(�������ڵ�)                                                                                                                                   
,case when length(trim(��������ȣ))=3 then '0'||trim(��������ȣ) else trim(��������ȣ) end                                                          
,case when length(trim(������ȣ))=3 then '0'||trim(������ȣ) else trim(������ȣ) end                                                                
,trim(��������ڵ�)                                                                                                                                 
,trim(���������ڵ�)                                                                                                                                 
,trim(���������ڵ�)                                                                                                                                 
,��ȯ����ڰݿ���                                                                                                                                   
,PB������޿���                                                                                                                                     
,RM������                                                                                                                                           
,��ȣ����                                                                                                                                           
,�����븮������                                                                                                                                     
,trim(������ȯ���ڵ�)                                                                                                                               
,trim(����ڼ�����)                                                                                                                                 
,trim(����ھ���)                                                                                                                                   
,trim(������Ϸù�ȣ)                                                                                                                               
,trim(�õ��ڵ�)                                                                                                                                     
,trim(�õ���)                                                                                                                                       
,trim(��ȭ��ȣ)                                                                                                                                     
,trim(�ѽ���ȣ)                                                                                                                                     
,trim(��������ȣ)                                                                                                                                   
,trim(������ȣ)                                                                                                                                     
,trim(�ּ�)                                                                                                                                         
,trim(�����ּ�)                                                                                                                                     
,trim(���ֺ��Ӽ��ڵ�)                                                                                                                               
,trim(��ǥ������������ȣ)                                                                                                                           
,trim(��ǥ�������)                                                                                                                                 
,trim(��ù�)                                                                                                                                       
,trim(�����ù�)                                                                                                                                   
,trim(��������������ȣ)                                                                                                                             
,trim(������������)                                                                                                                                 
,trim(���α׷�)                                                                                                                                     
,trim(����׷�)                                                                                                                                     
,trim(�������׷�)                                                                                                                                 
,''                                                                                                                                                 
,''                                                                                                                                                 
,''                                                                                                                                                 
,''                                                                                                                                                 
,''                                                                                                                                                 
,''                                                                                                                                                 
,''                                                                                                                                                 
FROM TB_IQF_����_����������                                                                                                                         
;                                                                                                                                                   
set temporary option Temp_Extract_Name1 = '';                                                                                                       
                                                                                                                                                    
                                                                                                                                                    
                                                                                                                                                    
                                                                                                                                                    
                                                                                                                                                    
                                                                                             
                                                                                             