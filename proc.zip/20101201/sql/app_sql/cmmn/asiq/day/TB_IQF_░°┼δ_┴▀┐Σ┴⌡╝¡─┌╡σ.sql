
set trimspool on
set term off 
SET echo off
set linesize 1000 
set head off
set pagesize 0
set feedback off
SPOOL /ett/ettdata/rcvdata/cmmn/asiq/day/TB_IQF_����_�߿������ڵ�.dat

whenever oserror  exit failure if an os error occurs
whenever sqlerror exit failure SQL.SQLCODE

select
   CD || '|' ||
   SNM || '|' ||
   FNM || '|' ||
   GB || '|' ||
   TO_CHAR(SYSDATE,'YYYYMMDD') || '|' ||
   TO_CHAR(SYSDATE,'HHMISS') || '|'    
from OCOM_VIP;
exit;
SPOOL off

