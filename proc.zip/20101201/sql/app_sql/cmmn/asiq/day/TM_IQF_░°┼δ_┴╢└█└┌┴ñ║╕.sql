set trimspool on
set term off 
SET echo off
set linesize 1000 
set head off
set pagesize 0
set feedback off
SPOOL /ett/insa/TM_IQF_����_����������.dat

whenever oserror  exit failure if an os error occurs
whenever sqlerror exit failure SQL.SQLCODE

select
	OPER_NO|| '|' ||
	ID_NO|| '|' ||
	SOSOK_CD|| '|' ||
	JIKGUB|| '|' ||
	STATE1|| '|' ||
	STATE2|| '|' ||
	STATE3|| '|' ||
	STATE4|| '|' ||
	STATE5|| '|' ||
	STATE6|| '|' ||
	STATE7|| '|' ||
	STATE8|| '|' ||
	TEL_NO|| '|' ||
	TR_GB|| '|' ||
	TO_CHAR(DNG_IL, 'YYYYMMDD')|| '|' ||
	TO_CHAR(SYSDATE, 'YYYYMMDD')|| '|'
from OCOM_OPE@DBODS1
where OPER_NO != '       ';
exit;
SPOOL off  
