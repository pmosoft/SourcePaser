### /ett/app/pgm/bin/cmmn/asiq/day/b_d8cmmn8265.sh �� �̰�

###DATE=`date +%Y%m%d`
###
###### ������ ����
###mkdir -p /ett/app/pgm/backup/$DATE/bin
###mkdir -p /ett/app/pgm/backup/$DATE/sql
###mkdir -p /ett/app/pgm/backup/$DATE/sql/insa
###
###### ��ġ���ཀྵ ���
###cp -R /ett/insa/ /ett/app/pgm/backup/$DATE/sql
###
###### ��ġ���ཀྵ ���
###cp -R /ett/app/pgm/bin/bogo/ /ett/app/pgm/backup/$DATE/bin
###cp -R /ett/app/pgm/bin/bsgs/ /ett/app/pgm/backup/$DATE/bin
###cp -R /ett/app/pgm/bin/cmmn/ /ett/app/pgm/backup/$DATE/bin
###cp -R /ett/app/pgm/bin/ijgs/ /ett/app/pgm/backup/$DATE/bin
###cp -R /ett/app/pgm/bin/jbgs/ /ett/app/pgm/backup/$DATE/bin
###cp -R /ett/app/pgm/bin/jjgs/ /ett/app/pgm/backup/$DATE/bin
###cp -R /ett/app/pgm/bin/rsbs/ /ett/app/pgm/backup/$DATE/bin
###cp -R /ett/app/pgm/bin/sgsy/ /ett/app/pgm/backup/$DATE/bin
###cp -R /ett/app/pgm/bin/ssgs/ /ett/app/pgm/backup/$DATE/bin
###
###### ��ġ sql ���
###cp -R /ett/app/pgm/sql/app_sql/ /ett/app/pgm/backup/$DATE/sql
###cp -R /ett/app/pgm/sql/ddl/     /ett/app/pgm/backup/$DATE/sql
###cp -R /ett/app/pgm/sql/lod_sql/ /ett/app/pgm/backup/$DATE/sql
###cp -R /ett/app/pgm/sql/func/    /ett/app/pgm/backup/$DATE/sql
###cp -R /ett/app/pgm/sql/proc/    /ett/app/pgm/backup/$DATE/sql
###
###### Htran ���� ���
###cp    /ett/app/pgm/bin/*.sh    /ett/app/pgm/backup/$DATE/bin/
###cp    /ett/app/pgm/bin/*.sql   /ett/app/pgm/backup/$DATE/bin/
###cp    /ett/app/pgm/bin/*.java  /ett/app/pgm/backup/$DATE/bin/
###cp    /ett/app/pgm/bin/*.class /ett/app/pgm/backup/$DATE/bin/
###
###### Stran ���� ���
###mkdir -p /ett/app/pgm/backup/$DATE/bin/STran/ext
###mkdir -p /ett/app/pgm/backup/$DATE/bin/STran/ins
###mkdir -p /ett/app/pgm/backup/$DATE/bin/STran/sql
###mkdir -p /ett/app/pgm/backup/$DATE/bin/STran/view
###
###cp    /ett/app/pgm/bin/STran/*.*  /ett/app/pgm/backup/$DATE/bin/STran/
###cp -R /ett/app/pgm/bin/STran/ext  /ett/app/pgm/backup/$DATE/bin/STran/ext
###cp -R /ett/app/pgm/bin/STran/ins  /ett/app/pgm/backup/$DATE/bin/STran/ins
###cp -R /ett/app/pgm/bin/STran/sql  /ett/app/pgm/backup/$DATE/bin/STran/sql
###cp -R /ett/app/pgm/bin/STran/view /ett/app/pgm/backup/$DATE/bin/STran/view
###
###### Mtran ���� ���
###mkdir -p /ett/app/pgm/backup/$DATE/bin/Sup/creattable
###mkdir -p /ett/app/pgm/backup/$DATE/bin/Sup/lod_sql
###mkdir -p /ett/app/pgm/backup/$DATE/bin/Sup/proc_dir
###mkdir -p /ett/app/pgm/backup/$DATE/bin/Sup/tmp_dir
###mkdir -p /ett/app/pgm/backup/$DATE/bin/Sup/view
###
###cp    /ett/app/pgm/bin/Sup/*.sh       /ett/app/pgm/backup/$DATE/bin/Sup/
###cp -R /ett/app/pgm/bin/Sup/creattable /ett/app/pgm/backup/$DATE/bin/Sup/creattable
###cp -R /ett/app/pgm/bin/Sup/lod_sql    /ett/app/pgm/backup/$DATE/bin/Sup/lod_sql
###cp -R /ett/app/pgm/bin/Sup/proc_dir   /ett/app/pgm/backup/$DATE/bin/Sup/proc_dir
###cp -R /ett/app/pgm/bin/Sup/tmp_dir    /ett/app/pgm/backup/$DATE/bin/Sup/tmp_dir
###cp -R /ett/app/pgm/bin/Sup/view       /ett/app/pgm/backup/$DATE/bin/Sup/view
###
###
####################################################
#### ���� ����. ���� ó��
####################################################
###find /ett/app/log/ -name "*.log" -mtime +15 -exec rm -f {} \;
###
###find /ett/app/pgm/backup/ -mtime +15 -exec rm -rf {} \;
###
###find /ett/ettdata/rcvdata/cmmn/kondor/ -mtime +15 -exec rm -f {} \;
###find /ett/ettdata/rcvdata/cmmn/losscut/ -mtime +15 -exec rm -f {} \;
###find /ett/ettdata/rcvdata/cmmn/summit/ -mtime +15 -exec rm -f {} \;
###
###
###### set today = `date +%Y%m%d`
###### set srcOpr=${srcDir}/work
###### set srcBak=${vrsDir}/vsm_work
###### mkdir -p ${srcOpr}/${today}/${filnm} >& /dev/null
###### rmdir ${srcOpr}/${filnm} >& /dev/null
###### /bin/cp -R ${batDir}/${filnm} ${srcOpr}/${filnm}
###
###### find /ett/app/pgm/sql/ -name *.dat -print
###### find /ett/app/pgm/sql/ -name *.sh  -print


