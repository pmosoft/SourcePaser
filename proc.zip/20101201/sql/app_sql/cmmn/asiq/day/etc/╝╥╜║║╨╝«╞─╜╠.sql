/*

---------------------
-- ���̺� ����
---------------------
DROP TABLE TEMP_PARSING
DROP TABLE TEMP_PARSING1
DROP TABLE TEMP_PARSING2
DROP TABLE TEMP_PARSING5

DROP TABLE TEMP_PARSING�ּ�1
DROP TABLE TEMP_PARSING�ּ�2
DROP TABLE TEMP_PARSING�ּ�3

CREATE TABLE TEMP_PARSING (COL1 CHAR(2000),IQ_TABLE CHAR(100))
CREATE TABLE TEMP_PARSING1(��ȣ INT,COL1 CHAR(2000),IQ_TABLE CHAR(100))
CREATE TABLE TEMP_PARSING2(��ȣ INT,COL1 CHAR(2000),IQ_TABLE CHAR(100))
CREATE TABLE TEMP_PARSING5
(
    IQ_TABLE  CHAR(100)   ,
    DW_TABLE  CHAR(100)   ,
    DW_ALIAS  CHAR(100)   ,
    ����      INT         ,
    DW_FIELD  CHAR(1000)  ,
    TABLE1    CHAR(100)   ,
    TABLE2    CHAR(100)   ,
    FIELD1    CHAR(1000)  ,
    FIELD1_01 CHAR(1000)  ,
    FIELD1_02 CHAR(1000)  ,
    FIELD1_03 CHAR(1000)  ,
    FIELD1_04 CHAR(1000)  , 
    FIELD1_05 CHAR(1000)  ,
    FIELD1_06 CHAR(1000)  ,
    FIELD1_07 CHAR(1000)  ,
    FIELD1_08 CHAR(1000)  ,
    FIELD1_09 CHAR(1000)  ,
    FIELD1_10 CHAR(1000)  ,
    FIELD1_11 CHAR(1000)  ,
    FIELD1_12 CHAR(1000)  ,
    FIELD1_13 CHAR(1000)  ,    
    FIELD1_99 CHAR(1000)  
)

CREATE TABLE TEMP_PARSING�ּ�1 ( ���� INT,��ȣ INT,COL1 CHAR(2000),IQ_TABLE CHAR(100))
CREATE TABLE TEMP_PARSING�ּ�2 ( ���� INT,��ȣ INT,COL1 CHAR(2000),IQ_TABLE CHAR(100))
CREATE TABLE TEMP_PARSING�ּ�3 (IQ_TABLE CHAR(100),����1 INT,����1 INT,����1 INT,����2 INT,����2 INT,����2 INT,����3 INT,����3 INT,����3 INT)


*/

BEGIN


    ----------------------------------
    -- ASIQ���̺��� ���� �� ��ȣ ä��
    ----------------------------------
    SELECT NUMBER(*)       AS ��ȣ
           ,A.COL1         AS COL1
           ,B.IQ_TABLE_02  AS IQ_TABLE
    INTO   #TEMP_PARSING1
    FROM   TEMP_PARSING A,
          (SELECT  A.IQ_TABLE
                  ,CAST(REPLACE(A.IQ_TABLE ,'.sql','') AS CHAR(100)) AS IQ_TABLE_01
                  ,CAST(REPLACE(IQ_TABLE_01,'ext_','') AS CHAR(100)) AS IQ_TABLE_02
           FROM   TEMP_PARSING A
           GROUP BY A.IQ_TABLE) B
    WHERE  A.IQ_TABLE = B.IQ_TABLE
    AND   (B.IQ_TABLE_02 LIKE 'TB%' OR B.IQ_TABLE_02 LIKE 'OT%' OR B.IQ_TABLE_02 LIKE 'TM%')
    ;

    DELETE FROM TEMP_PARSING1 WHERE IQ_TABLE = (SELECT DISTINCT IQ_TABLE FROM #TEMP_PARSING1);
    INSERT INTO TEMP_PARSING1 SELECT * FROM #TEMP_PARSING1;


    -----------------------------
    -- �ּ��κ� ����
    -----------------------------
    SELECT  NUMBER(*)   AS ����
           ,A.��ȣ      AS ��ȣ
           ,A.COL1      AS COL1
           ,A.IQ_TABLE  AS IQ_TABLE
    INTO   #TEMP_PARSING�ּ�1
    FROM   #TEMP_PARSING1 A
    WHERE  A.COL1 LIKE '%/*%'
    ;
    DELETE FROM TEMP_PARSING�ּ�1 WHERE IQ_TABLE = (SELECT DISTINCT IQ_TABLE FROM #TEMP_PARSING1);
    INSERT INTO TEMP_PARSING�ּ�1 SELECT * FROM #TEMP_PARSING�ּ�1;

    SELECT  NUMBER(*)    AS ����
           ,A.��ȣ       AS ��ȣ
           ,A.COL1       AS COL1
           ,A.IQ_TABLE   AS IQ_TABLE
    INTO   #TEMP_PARSING�ּ�2
    FROM   #TEMP_PARSING1 A
    WHERE  A.COL1 LIKE '%*/%'
    ;
    DELETE FROM TEMP_PARSING�ּ�2 WHERE IQ_TABLE = (SELECT DISTINCT IQ_TABLE FROM #TEMP_PARSING1);
    INSERT INTO TEMP_PARSING�ּ�2 SELECT * FROM #TEMP_PARSING�ּ�2;

    SELECT  A.IQ_TABLE
           ,MAX(CASE WHEN A.����=1 THEN A.���� ELSE 0 END) AS ����1
           ,MAX(CASE WHEN A.����=1 THEN A.��ȣ ELSE 0 END) AS ����1
           ,MAX(CASE WHEN A.����=1 THEN B.��ȣ ELSE 0 END) AS ����1
           ,MAX(CASE WHEN A.����=2 THEN A.���� ELSE 0 END) AS ����2
           ,MAX(CASE WHEN A.����=2 THEN A.��ȣ ELSE 0 END) AS ����2
           ,MAX(CASE WHEN A.����=2 THEN B.��ȣ ELSE 0 END) AS ����2
           ,MAX(CASE WHEN A.����=3 THEN A.���� ELSE 0 END) AS ����3
           ,MAX(CASE WHEN A.����=3 THEN A.��ȣ ELSE 0 END) AS ����3
           ,MAX(CASE WHEN A.����=3 THEN B.��ȣ ELSE 0 END) AS ����3
    INTO   #TEMP_PARSING�ּ�3
    FROM   #TEMP_PARSING�ּ�1 A,
           #TEMP_PARSING�ּ�2 B
    WHERE  A.IQ_TABLE   = B.IQ_TABLE
    AND    A.���� = B.����
    AND    A.��ȣ <> B.��ȣ
    GROUP BY A.IQ_TABLE
    ;

    DELETE FROM TEMP_PARSING�ּ�3 WHERE IQ_TABLE = (SELECT DISTINCT IQ_TABLE FROM #TEMP_PARSING1);
    INSERT INTO TEMP_PARSING�ּ�3 SELECT * FROM #TEMP_PARSING�ּ�3;

    SELECT  NUMBER(*) ��ȣ
           ,A.COL1
           ,A.IQ_TABLE
    INTO   #TEMP_PARSING2
    FROM   #TEMP_PARSING1 A
    WHERE  A.��ȣ NOT IN (
           SELECT A.��ȣ
           FROM   #TEMP_PARSING1 A,
                  #TEMP_PARSING�ּ�3 B
           WHERE  A.��ȣ BETWEEN B.����1 AND B.����1
           OR     A.��ȣ BETWEEN B.����2 AND B.����2
           OR     A.��ȣ BETWEEN B.����3 AND B.����3
           )
    ;

    DELETE FROM TEMP_PARSING2 WHERE IQ_TABLE = (SELECT DISTINCT IQ_TABLE FROM #TEMP_PARSING1);
    INSERT INTO TEMP_PARSING2 SELECT * FROM #TEMP_PARSING2;


    ---------------------------------------
    -- FROM������ ���̺����� ����
    ---------------------------------------
    SELECT  A.COL1
           ,A.IQ_TABLE
           ,CAST(TRIM(REPLACE(UPPER(A.COL1),'FROM','')) AS CHAR(100)) AS COL1_01
           ,LOCATE(COL1_01,' ')                                       AS COL1_LOC
           ,CASE WHEN COL1_LOC = 0 THEN COL1_01
                 ELSE CAST(SUBSTR(COL1_01,1,COL1_LOC-1) AS CHAR(100))
            END                                                       AS TABLE1
           ,CAST(REPLACE(TABLE1,';','') AS CHAR(100))                 AS TABLE2
           ,CASE WHEN COL1_LOC = 0 THEN ''
                 ELSE CAST(SUBSTR(COL1_01,COL1_LOC+1,1) AS CHAR(100)) 
            END                                                       AS ALIAS1
    INTO   #TEMP_PARSING3
    FROM   #TEMP_PARSING2 A
    WHERE  UPPER(A.COL1) LIKE 'FROM%'
    ;
    
    ---------------------------------------
    -- Į������ ����
    ---------------------------------------
    SELECT  NUMBER(*)                                           AS ����
           ,A.COL1                                              AS COL1
           ,A.IQ_TABLE                                          AS IQ_TABLE
           ,CAST(TRIM(REPLACE(REPLACE(UPPER(A.COL1),'SELECT',''),' ','')) 
                                                                AS CHAR(100))     AS COL1_01
           ,LOCATE(COL1_01,'||')                                AS COL1_LOC
           ,CAST(SUBSTR(COL1_01,1,COL1_LOC-1) AS CHAR(100))     AS FIELD1
    INTO   #TEMP_PARSING4
    FROM   #TEMP_PARSING2 A
    WHERE  A.COL1 LIKE '%||%'
    ;

    ---------------------------------------
    -- ������� ����
    ---------------------------------------
    SELECT DISTINCT 
           A.IQ_TABLE                                                                                               AS IQ_TABLE
          ,A.TABLE2                                                                                                 AS DW_TABLE
          ,A.ALIAS1                                                                                                 AS DW_ALIAS
          ,B.����                                                                                                   AS ����
          ,FIELD1_99                                                                                                AS DW_FIELD
          ,A.TABLE1                                                                                                 AS TABLE1
          ,A.TABLE2                                                                                                 AS TABLE2
          ,B.FIELD1                                                                                                 AS FIELD1
          ,CAST(REPLACE(B.FIELD1,'''','') AS CHAR(100))                                                             AS FIELD1_01
          ,CAST(REPLACE(REPLACE(REPLACE(FIELD1_01,CHAR(13),'//'),CHAR(10),'//'),CHAR(09),'') AS CHAR(100))          AS FIELD1_02
          ,CAST(REPLACE(UPPER(FIELD1_02),'TO_CHAR(','')             AS CHAR(100))                                   AS FIELD1_03
          ,CAST(REPLACE(UPPER(FIELD1_03),',YYYYMMDD)','')       AS CHAR(100))                                       AS FIELD1_04
          ,CAST(REPLACE(UPPER(FIELD1_04),',HHMISS)','')         AS CHAR(100))                                       AS FIELD1_05
          ,CAST(REPLACE(UPPER(FIELD1_05),',YYYYMMDDHHMISS)','') AS CHAR(100))                                       AS FIELD1_06
          ,CAST(REPLACE(UPPER(FIELD1_06),'REPLACE(REPLACE(REPLACE(REPLACE(','') AS CHAR(100))                       AS FIELD1_07
          ,CAST(REPLACE(UPPER(FIELD1_07),',CHR(13),//),CHR(10),//),^|,//),|,//)','') AS CHAR(100))                  AS FIELD1_08
          ,CAST(REPLACE(UPPER(FIELD1_08),',CHR(13),//),CHR(10),//),^|,//),|,//)','') AS CHAR(100))                  AS FIELD1_09
          ,CAST(REPLACE(UPPER(FIELD1_09),',CHR(30),//),CHR(30),//),^|,//),|,//)','') AS CHAR(100))                  AS FIELD1_10
          ,CAST(REPLACE(UPPER(FIELD1_10),',CHR(6),//),CHR(6),//),^|,//),|,//)','') AS CHAR(100))                    AS FIELD1_11
          ,CAST(REPLACE(UPPER(FIELD1_11),'NVL(','') AS CHAR(100))                                                   AS FIELD1_12
          ,CAST(REPLACE(UPPER(FIELD1_12),',)','') AS CHAR(100))                                                     AS FIELD1_13
          ,CAST(REPLACE(UPPER(FIELD1_13),',0)','') AS CHAR(100))                                                    AS FIELD1_99
    INTO  #TEMP_PARSING5
    FROM  #TEMP_PARSING3 A,#TEMP_PARSING4 B
    ;
    
--          ,CASE WHEN B.FIELD1 = '''''' THEN '' ELSE B.FIELD1 END                                                    AS FIELD1_01
--          ,CAST(REPLACE(REPLACE(REPLACE(FIELD1_01,CHAR(13),'//'),CHAR(10),'//'),CHAR(09),'') AS CHAR(100))          AS FIELD1_02
--          ,CAST(REPLACE(FIELD1_02,'TO_CHAR(','')             AS CHAR(100))                                          AS FIELD1_03
--          ,CAST(REPLACE(FIELD1_03,',''YYYYMMDD'')','')       AS CHAR(100))                                          AS FIELD1_04
--          ,CAST(REPLACE(FIELD1_04,',''HHMISS'')','')         AS CHAR(100))                                          AS FIELD1_05
--          ,CAST(REPLACE(FIELD1_05,',''YYYYMMDDHHMISS'')','') AS CHAR(100))                                          AS FIELD1_06
--          ,CAST(REPLACE(FIELD1_06,'REPLACE(REPLACE(REPLACE(REPLACE(','') AS CHAR(100))                              AS FIELD1_07
--          ,CAST(REPLACE(FIELD1_07,',CHR(13),''//''),CHR(10),''//''),''^|'',''//''),''|'',''//'')','') AS CHAR(100)) AS FIELD1_08
--          ,CAST(REPLACE(FIELD1_08,',CHR(13),''//''),CHR(10),''//''),''^|'',''//''),''|'',''//'')','') AS CHAR(100)) AS FIELD1_09
--          ,CAST(REPLACE(FIELD1_09,',NVL(','') AS CHAR(100))                                                         AS FIELD1_10
--          ,CAST(REPLACE(FIELD1_10,','''')','') AS CHAR(100))                                                        AS FIELD1_11
--          ,CAST(REPLACE(FIELD1_11,',0)','') AS CHAR(100))                                                           AS FIELD1_12
--          ,CAST(REPLACE(FIELD1_12,'''','') AS CHAR(100))                                                            AS FIELD1_99
    
    
    
    DELETE FROM TEMP_PARSING5 WHERE IQ_TABLE = (SELECT DISTINCT IQ_TABLE FROM #TEMP_PARSING1);
    INSERT INTO TEMP_PARSING5 SELECT * FROM #TEMP_PARSING5;
/*

    DROP TABLE TEMP_PARSING6

    SELECT TRIM(A.IQ_TABLE) AS IQ_TABLE
          ,TRIM(A.DW_TABLE) AS DW_TABLE
          ,A.����           AS ����
          ,TRIM(A.DW_FIELD) AS DW_FIELD
    INTO   TEMP_PARSING6
    FROM   TEMP_PARSING5 A
    WHERE  IQ_TABLE IN 
           (SELECT A.IQ_TABLE
            FROM  (SELECT IQ_TABLE,TABLE1
                   FROM TEMP_PARSING5
                   WHERE TABLE1 <> ''
                   AND   TABLE1 NOT LIKE '%SELECT%'
                   GROUP BY IQ_TABLE,TABLE1
                   ) A
            GROUP BY IQ_TABLE
            HAVING COUNT(*) = 1)
    ORDER BY IQ_TABLE,����
    
*/        
END                                                                                                                                              