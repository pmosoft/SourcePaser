/*

---------------------
-- ���̺� ����
---------------------
DROP TABLE TEMP_PARSING
DROP TABLE TEMP_PARSING1
DROP TABLE TEMP_PARSING2
DROP TABLE TEMP_PARSING3
DROP TABLE TEMP_PARSING4
DROP TABLE TEMP_PARSING5

DROP TABLE TEMP_PARSING�ּ�1
DROP TABLE TEMP_PARSING�ּ�2
DROP TABLE TEMP_PARSING�ּ�3

CREATE TABLE TEMP_PARSING (COL1 CHAR(2000),TN CHAR(100))
CREATE TABLE TEMP_PARSING1(��ȣ INT,COL1 CHAR(2000),TN CHAR(100))
CREATE TABLE TEMP_PARSING2(��ȣ INT,COL1 CHAR(2000),TN CHAR(100))
CREATE TABLE TEMP_PARSING3(COL1 CHAR(2000),TN CHAR(100),COL1_01 CHAR(2000),COL1_LOC INT,
                           TABLE1 CHAR(100),TABLE2 CHAR(100),ALIAS1 CHAR(100))
CREATE TABLE TEMP_PARSING4(���� INT,COL1 CHAR(2000),TN CHAR(100),COL1_01 CHAR(2000),COL1_LOC INT,FIELD1 CHAR(1000))
CREATE TABLE TEMP_PARSING5
( TN CHAR(100),TABLE1 CHAR(100),ALIAS1 CHAR(100),���� INT,
  FIELD1 CHAR(1000),FIELD1_01 CHAR(1000),FIELD1_02 CHAR(1000),
  FIELD1_03 CHAR(1000),FIELD1_04 CHAR(1000)
)

CREATE TABLE TEMP_PARSING�ּ�1 ( ���� INT,��ȣ INT,COL1 CHAR(2000),TN CHAR(100))
CREATE TABLE TEMP_PARSING�ּ�2 ( ���� INT,��ȣ INT,COL1 CHAR(2000),TN CHAR(100))
CREATE TABLE TEMP_PARSING�ּ�3 (TN CHAR(100),����1 INT,����1 INT,����1 INT,����2 INT,����2 INT,����2 INT,����3 INT,����3 INT,����3 INT)


*/

BEGIN


    ----------------------------------
    -- ASIQ���̺��� ���� �� ��ȣ ä��
    ----------------------------------
    SELECT NUMBER(*) AS ��ȣ
           ,A.COL1   AS COL1
           ,B.TN_02  AS TN
    INTO   #TEMP_PARSING1
    FROM   TEMP_PARSING A,
          (SELECT  A.TN
                  ,CAST(REPLACE(A.TN ,'.sql','') AS VARCHAR(1000)) AS TN_01
                  ,CAST(REPLACE(TN_01,'ext_','') AS VARCHAR(1000)) AS TN_02
           FROM   TEMP_PARSING A
           GROUP BY A.TN) B
    WHERE  A.TN = B.TN
    AND   (B.TN_02 LIKE 'TB%' OR B.TN_02 LIKE 'OT%' OR B.TN_02 LIKE 'TM%')
    ;

    DELETE FROM TEMP_PARSING1 WHERE TN = (SELECT DISTINCT TN FROM #TEMP_PARSING1);
    INSERT INTO TEMP_PARSING1 SELECT * FROM #TEMP_PARSING1;


    -----------------------------
    -- �ּ��κ� ����
    -----------------------------
    SELECT  NUMBER(*) AS ����
           ,A.��ȣ    AS ��ȣ
           ,A.COL1    AS COL1
           ,A.TN      AS TN
    INTO   #TEMP_PARSING�ּ�1
    FROM   #TEMP_PARSING1 A
    WHERE  A.COL1 LIKE '%/*%'
    ;
    DELETE FROM TEMP_PARSING�ּ�1 WHERE TN = (SELECT DISTINCT TN FROM #TEMP_PARSING1);
    INSERT INTO TEMP_PARSING�ּ�1 SELECT * FROM #TEMP_PARSING�ּ�1;

    SELECT  NUMBER(*) AS ����
           ,A.��ȣ    AS ��ȣ
           ,A.COL1    AS COL1
           ,A.TN      AS TN
    INTO   #TEMP_PARSING�ּ�2
    FROM   #TEMP_PARSING1 A
    WHERE  A.COL1 LIKE '%*/%'
    ;
    DELETE FROM TEMP_PARSING�ּ�2 WHERE TN = (SELECT DISTINCT TN FROM #TEMP_PARSING1);
    INSERT INTO TEMP_PARSING�ּ�2 SELECT * FROM #TEMP_PARSING�ּ�2;

    SELECT  A.TN
           ,MAX(CASE WHEN A.����=1 THEN A.���� ELSE 0 END) AS ����1
           ,MAX(CASE WHEN A.����=1 THEN A.��ȣ ELSE 0 END) AS ����1
           ,MAX(CASE WHEN A.����=1 THEN B.��ȣ ELSE 0 END) AS ����1
           ,MAX(CASE WHEN A.����=2 THEN A.���� ELSE 0 END) AS ����2
           ,MAX(CASE WHEN A.����=2 THEN A.��ȣ ELSE 0 END) AS ����2
           ,MAX(CASE WHEN A.����=2 THEN B.��ȣ ELSE 0 END) AS ����2
           ,MAX(CASE WHEN A.����=3 THEN A.���� ELSE 0 END) AS ����3
           ,MAX(CASE WHEN A.����=3 THEN A.��ȣ ELSE 0 END) AS ����3
           ,MAX(CASE WHEN A.����=3 THEN B.��ȣ ELSE 0 END) AS ����3
    INTO   #TEMP_PARSING�ּ�3
    FROM   #TEMP_PARSING�ּ�1 A,
           #TEMP_PARSING�ּ�2 B
    WHERE  A.TN   = B.TN
    AND    A.���� = B.����
    AND    A.��ȣ <> B.��ȣ
    GROUP BY A.TN
    ;

    DELETE FROM TEMP_PARSING�ּ�3 WHERE TN = (SELECT DISTINCT TN FROM #TEMP_PARSING1);
    INSERT INTO TEMP_PARSING�ּ�3 SELECT * FROM #TEMP_PARSING�ּ�3;

    SELECT  NUMBER(*) ��ȣ
           ,A.COL1
           ,A.TN
    INTO   #TEMP_PARSING2
    FROM   #TEMP_PARSING1 A
    WHERE  A.��ȣ NOT IN (
           SELECT A.��ȣ
           FROM   #TEMP_PARSING1 A,
                  #TEMP_PARSING�ּ�3 B
           WHERE  A.��ȣ BETWEEN B.����1 AND B.����1
           OR     A.��ȣ BETWEEN B.����2 AND B.����2
           OR     A.��ȣ BETWEEN B.����3 AND B.����3
           )
    ;

    DELETE FROM TEMP_PARSING2 WHERE TN = (SELECT DISTINCT TN FROM #TEMP_PARSING1);
    INSERT INTO TEMP_PARSING2 SELECT * FROM #TEMP_PARSING2;


    ---------------------------------------
    -- FROM������ ���̺����� ����
    ---------------------------------------
    SELECT  A.COL1
           ,A.TN
           ,CAST(TRIM(REPLACE(UPPER(A.COL1),'FROM','')) AS VARCHAR(1000)) AS COL1_01
           ,LOCATE(COL1_01,' ')                                           AS COL1_LOC
           ,CASE WHEN COL1_LOC = 0 THEN COL1_01
                 ELSE CAST(SUBSTR(COL1_01,1,COL1_LOC-1) AS VARCHAR(1000))
            END                                                           AS TABLE1
           ,CAST(REPLACE(TABLE1,';','') AS VARCHAR(1000))                 AS TABLE2
           ,CASE WHEN COL1_LOC = 0 THEN ''
                 ELSE CAST(SUBSTR(COL1_01,COL1_LOC+1,1) AS VARCHAR(1000)) 
            END                                                           AS ALIAS1
    INTO   #TEMP_PARSING3
    FROM   #TEMP_PARSING2 A
    WHERE  UPPER(A.COL1) LIKE 'FROM%'
    ;
    DELETE FROM TEMP_PARSING3 WHERE TN = (SELECT DISTINCT TN FROM #TEMP_PARSING1);
    INSERT INTO TEMP_PARSING3 SELECT * FROM #TEMP_PARSING3;
    
    ---------------------------------------
    -- Į������ ����
    ---------------------------------------
    SELECT  NUMBER(*)                                           AS ����
           ,A.COL1                                              AS COL1
           ,A.TN                                                AS TN
           ,CAST(TRIM(REPLACE(A.COL1,' ','')) AS VARCHAR(1000)) AS COL1_01
           ,LOCATE(COL1_01,'||')                                AS COL1_LOC
           ,CAST(SUBSTR(COL1_01,1,COL1_LOC-1) AS VARCHAR(1000)) AS FIELD1
    INTO   #TEMP_PARSING4
    FROM   #TEMP_PARSING2 A
    WHERE  A.COL1 LIKE '%||%'
    ;
    DELETE FROM TEMP_PARSING4 WHERE TN = (SELECT DISTINCT TN FROM #TEMP_PARSING1);
    INSERT INTO TEMP_PARSING4 SELECT * FROM #TEMP_PARSING4;
    

    ---------------------------------------
    -- ������� ����
    ---------------------------------------
    SELECT A.TN                                        AS TN    
          ,A.TABLE2                                    AS TABLE1
          ,A.ALIAS1                                    AS ALIAS1
          ,B.����                                      AS ����  
          ,B.FIELD1                                    AS FIELD1
          ,CAST(REPLACE(B.FIELD1,ALIAS1||'.',A.TABLE1||'.')  AS VARCHAR(1000)) AS FIELD1_01
          ,CAST(REPLACE(FIELD1_01,'TO_CHAR(','')             AS VARCHAR(1000)) AS FIELD1_02
          ,CAST(REPLACE(FIELD1_02,',''YYYYMMDD'')','')       AS VARCHAR(1000)) AS FIELD1_03
          ,CAST(REPLACE(FIELD1_03,',''HHMISS'')','')         AS VARCHAR(1000)) AS FIELD1_04
    INTO  #TEMP_PARSING5
    FROM  #TEMP_PARSING3 A,#TEMP_PARSING4 B
    ;
    DELETE FROM TEMP_PARSING5 WHERE TN = (SELECT DISTINCT TN FROM #TEMP_PARSING1);
    INSERT INTO TEMP_PARSING5 SELECT * FROM #TEMP_PARSING5;
        

END                                                                                                                                              