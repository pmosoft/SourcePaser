#################################################
# ���� ����. ���� ó��
#################################################
find /ett/app/log/ -name "*.log" -mtime +15 -exec rm -f {} \;
find /ett/app/pgm/backup/ -mtime +15 -exec rm -rf {} \;
find /ett/ettdata/rcvdata/cmmn/kondor/ -mtime +15 -exec rm -f {} \;
find /ett/ettdata/rcvdata/cmmn/losscut/ -mtime +15 -exec rm -f {} \;
find /ett/ettdata/rcvdata/cmmn/summit/ -mtime +15 -exec rm -f {} \;

