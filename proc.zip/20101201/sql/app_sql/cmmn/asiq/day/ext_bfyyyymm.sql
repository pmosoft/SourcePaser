set temporary option Temp_Extract_Name1 = '/bct/temp/ext_bfyyyymm.out';                                                               
set temporary option Temp_Extract_Column_Delimiter = '#|';                                                                            
set temporary option Temp_Extract_Row_Delimiter = '@@\n';                                                                             
set temporary option Temp_Extract_NULL_As_Zero = 'on';                                                                                
set temporary option TIMESTAMP_FORMAT = 'YYYYMMDD HH:NN:SS';                                                                          
                                                                                                                                      
SELECT  substr(DATEFORMAT(�������������� ,'yyyymmdd'),1,6) FROM TB_IQF_����_������ WHERE �������� = DATEFORMAT(GETDATE() ,'yyyymmdd');
                                                                                                                                      
set temporary option Temp_Extract_Name1 = '';           