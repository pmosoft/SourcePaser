
set trimspool on
set term off 
SET echo off
set linesize 1000 
set head off
set pagesize 0
set feedback off
SPOOL /ett/ettdata/rcvdata/cmmn/asiq/day/TB_IQF_����_���缱����.dat

whenever oserror  exit failure if an os error occurs
whenever sqlerror exit failure SQL.SQLCODE

SELECT
  DATA_KND || '|' ||
  NO || '|' ||
  ST || '|' ||
  PROC_ST || '|' ||
  CONL_EMP || '|' ||
  CONL_BRNO || '|' ||
  CONL_DT || '|' ||
  LST_APPRV_DT || '|' ||
  LAST_GRD || '|' ||
  REVIEW_YN || '|' ||
  LEVEL_CODE || '|' ||
  JUNGYUL_GRD || '|' ||
  TO_CHAR(JUNGYUL_SNG_IL,'YYYYMMDD') || '|' ||
  TO_CHAR(FST_SNG_IL,'YYYYMMDD') || '|' ||
  TO_CHAR(SYSDATE,'YYYYMMDD') || '|' ||
  TO_CHAR(SYSDATE,'HHMISS') || '|' 
FROM ICGS_PRGSS ;
exit;
SPOOL off

