#!/bin/sh
. /users/ais/.aiscfg
. /users/ais/.common_function

DATE=`date +%Y%m%d`
BASE_NAME=`basename $0`
BASE_CUT=`echo $BASE_NAME | sed -e s/.sh//g `
LOG_FILE=${cmmn_asiq_log}/${BASE_CUT}_${DATE}.log
LOG_ERR=${cmmn_asiq_err_log}/${BASE_CUT}_${DATE}.log
LOCAL_LOG=${cmmn_asiq_log}/${BASE_CUT}_sql_${DATE}.log
FILENAME="imsi_ora_ext"
SPOOL_FILE="/bct/temp/imsi_ora_ext.dat"

echo "LOG_FILE ==> tail -f $LOG_FILE"
echo "ERR_FILE ==> tail -f $LOG_ERR"
echo "SPOOL_FILE ==> tail -100 $SPOOL_FILE"

echo "" > $LOG_FILE
echo "" >> $LOG_ERR
startLog "Start ${FILENAME}" $LOG_FILE

#############################
## sqlplus
#############################
###sqlplus -S ${odsid}/${odspw}@DBODS1 @${app_cmmn_asiq_day}/${FILENAME}
sqlplus igam/tuxigam@dbods1 @/ett/ais_ett/app/pgm/sql/app_sql/cmmn/asiq/day/imsi_ora_ext.sql
###sqlplus devibal/balbal@dbbcv1 @/ett/ais_ett/app/pgm/sql/app_sql/cmmn/asiq/day/imsi_ora_ext.sql
###sqlplus devibal/balbal@dbbcv1 @/ett/app/pgm/sql/app_sql/ijgs/asiq/day/OT_IQF_�Ӱ�_�ڷ�����������ŷ�_����2.sql
Result=$?
assert $Result "${FILENAME}" $LOG_FILE $LOG_ERR $SPOOL_FILE $LINENO

