 set temporary option Temp_Extract_Name1 = '/bct/temp/ext_TB_IQF_����_�����ڱݿ뵵��_99999999.dat';
 set temporary option Temp_Extract_Column_Delimiter = '#|';                                        
 set temporary option Temp_Extract_Row_Delimiter = '@@\n';                                         
 set temporary option Temp_Extract_NULL_As_Zero = 'on';                                            
                                                                                                   
 SELECT                                                                                            
 trim(�ڱݿ뵵�ڵ�)                                                                                
 ,trim(�ڱݿ뵵��)                                                                                 
 ,trim(����ȸ�����⿩��)                                                                           
 ,trim(�����������)                                                                               
 ,trim(�������Žð�)                                                                               
 ,trim(�������ڵ�)                                                                                 
 FROM TB_IQF_����_�����ڱݿ뵵��                                                                   
 ;                                                                                                 
 set temporary option Temp_Extract_Name1 = '';                                                     