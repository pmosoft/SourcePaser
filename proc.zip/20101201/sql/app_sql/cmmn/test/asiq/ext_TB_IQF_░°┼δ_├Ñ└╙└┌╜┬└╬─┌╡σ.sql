 set temporary option Temp_Extract_Name1 = '/bct/temp/ext_TB_IQF_����_å���ڽ����ڵ�_99999999.dat';
 set temporary option Temp_Extract_Column_Delimiter = '#|';                                        
 set temporary option Temp_Extract_Row_Delimiter = '@@\n';                                         
 set temporary option Temp_Extract_NULL_As_Zero = 'on';                                            
                                                                                                   
 SELECT                                                                                            
 trim(å���ڽ����ڵ�)                                                                              
 ,trim(å���ڽ����ڵ��)                                                                           
 ,trim(�����������)                                                                               
 ,trim(�������Žð�)                                                                               
 FROM TB_IQF_����_å���ڽ����ڵ�                                                                   
 ;                                                                                                 
 set temporary option Temp_Extract_Name1 = '';                                                     