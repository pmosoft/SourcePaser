
 --sp_extscript TB_IQF_����_�Ϸù�ȣ
 --sp_extscript2  TB_IQF_����_�Ϸù�ȣ

 set temporary option Temp_Extract_Name1 = '/bct/temp/ext_TB_IQF_����_�Ϸù�ȣ_99991231.dat';
 set temporary option Temp_Extract_Column_Delimiter = '#|';
 set temporary option Temp_Extract_Row_Delimiter = '@@\n';
 set temporary option Temp_Extract_NULL_As_Zero = 'on';

 SELECT
  �Ϸù�ȣ
 ,'batch'
 ,dateformat(now(),'yyyymmdd')
 ,dateformat(now(),'hhmmss')
 ,'batch'
 ,dateformat(now(),'yyyymmdd')
 ,dateformat(now(),'hhmmss')
 FROM TB_IQF_����_�Ϸù�ȣ
 ;
 set temporary option Temp_Extract_Name1 = '';

