 --sp_extscript TM_IQU_����_COPY_T
 --sp_extscript2  TM_IQU_����_COPY_T

 set temporary option Temp_Extract_Name1 = '/bct/temp/ext_TM_IQU_����_COPY_T_99991231.dat';
 set temporary option Temp_Extract_Column_Delimiter = '#|';
 set temporary option Temp_Extract_Row_Delimiter = '@@\n';
 set temporary option Temp_Extract_NULL_As_Zero = 'on';

 SELECT
  SEQ
 FROM TM_IQU_����_COPY_T
 ;
 set temporary option Temp_Extract_Name1 = '';

