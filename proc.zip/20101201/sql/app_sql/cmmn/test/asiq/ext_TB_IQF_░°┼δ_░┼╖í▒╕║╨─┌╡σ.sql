 set temporary option Temp_Extract_Name1 = '/bct/temp/ext_TB_IQF_����_�ŷ������ڵ�_99991231.dat';
 set temporary option Temp_Extract_Column_Delimiter = '#|';                                      
 set temporary option Temp_Extract_Row_Delimiter = '@@\n';                                       
 set temporary option Temp_Extract_NULL_As_Zero = 'on';                                          
                                                                                                 
 SELECT                                                                                          
 trim(���������ڵ�)                                                                              
 ,trim(�ŷ������ڵ�)                                                                             
 ,trim(�������и�)                                                                               
 ,trim(�ŷ����и�)                                                                               
 ,trim(ȭ���ȣ)                                                                                 
 ,trim(�ڵ�������)                                                                             
 ,trim(�ڵ��������)                                                                             
 FROM TB_IQF_����_�ŷ������ڵ�                                                                   
 ;                                                                                               
 set temporary option Temp_Extract_Name1 = '';                                                   