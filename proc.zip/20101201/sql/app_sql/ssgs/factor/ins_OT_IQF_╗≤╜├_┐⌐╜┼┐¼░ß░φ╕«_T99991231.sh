#!/bin/sh
. /users/ais/.aiscfg

FILENAME=ins_OT_IQF_���_���ſ������

cd ${app_ssgs_factor}

cat ${app_ssgs_factor}/${FILENAME}.sql | sed -e s/@@CONDITION/" IN ('6')"/g             | sed -e s/@@NUMBER/"1"/g  > ${app_ssgs_factor}/${FILENAME}1.sql
cat ${app_ssgs_factor}/${FILENAME}.sql | sed -e s/@@CONDITION/" IN ('5')"/g             | sed -e s/@@NUMBER/"2"/g  > ${app_ssgs_factor}/${FILENAME}2.sql
cat ${app_ssgs_factor}/${FILENAME}.sql | sed -e s/@@CONDITION/" IN ('7')"/g             | sed -e s/@@NUMBER/"3"/g  > ${app_ssgs_factor}/${FILENAME}3.sql
cat ${app_ssgs_factor}/${FILENAME}.sql | sed -e s/@@CONDITION/" NOT IN ('6','5','7')"/g | sed -e s/@@NUMBER/"4"/g  > ${app_ssgs_factor}/${FILENAME}4.sql

chmod 777 *${FILENAME}*

ll *${FILENAME}*

