if  exists ( select 1 from sysobjects 
             where name ='sp_tablescript'
             and type = 'P')
begin
  DROP procedure sp_tablescript
end 
GO

create procedure sp_tablescript
(
  @���̺��� VARCHAR(100)
)
as
begin
--    sp_tablescript OT_SEF_����_�������˴��

--    select top 10 * from sysobjects
--    where id = object_id('OT_SEF_���_��������')
--    553870109
--
--    sp_help 'OT_SEF_���_��������'
--
--    select top 1000 *
--
--    select top 10 * from systypes
--
--    select b.colid,b.name,c.name,b.length,b.prec,b.scale,b.type
--    from sysobjects a,
--             syscolumns b,
--             systypes c
--    where a.id = b.id
--    and a.id  = 553870109
--    and b.type = c.type
--    and c.name not in ('sysname', 'longsysname', 'nchar', 'nvarchar')
--

    --select a.id,'T9_'||rtrim(a.name) as table_name,rtrim(a.name) as table_name1
    select a.id,rtrim(a.name) as table_name,rtrim(a.name) as table_name1
    into   #sysobjects
    from   sysobjects a
    where  a.name = @���̺���
    and    a.type = 'U'

    ----------------------------------------------
    -- drop table
    ----------------------------------------------
    create table #dropscript
    (
        dropscript         varchar(300) null
    )

--    insert into #dropscript
--    select 'if exists (select 1 from sysobjects where name ='''||table_name||''') drop table '||table_name as dropscript
--    from #sysobjects
--
--    insert into #dropscript
--    select 'go' as dropscript
--    from #sysobjects


    ----------------------------------------------
    -- create index
    ----------------------------------------------
    select  b.table_name                                                        as table_name
           ,a.name                                                              as index_name
           ,max(a.status)                                                       as status
           ,max(a.status2)                                                      as status2
           ,max(a.keycnt)                                                       as keycnt
           ,max(case when a.status2 & 512 = 512 then 'clustered' else '' end)   as attr1
           ,max(case when a.status  & 2   = 2   then 'unique'    else '' end)   as attr2
           ,max(case when a.keycnt >  1 then index_col(b.table_name1,a.indid, 1) end||','||
                case when a.keycnt >  2 then index_col(b.table_name1,a.indid, 2) end||','||
                case when a.keycnt >  3 then index_col(b.table_name1,a.indid, 3) end||','||
                case when a.keycnt >  4 then index_col(b.table_name1,a.indid, 4) end||','||
                case when a.keycnt >  5 then index_col(b.table_name1,a.indid, 5) end||','||
                case when a.keycnt >  6 then index_col(b.table_name1,a.indid, 6) end||','||
                case when a.keycnt >  7 then index_col(b.table_name1,a.indid, 7) end||','||
                case when a.keycnt >  8 then index_col(b.table_name1,a.indid, 8) end||','||
                case when a.keycnt >  9 then index_col(b.table_name1,a.indid, 9) end||','||
                case when a.keycnt > 10 then index_col(b.table_name1,a.indid,10) end||','||
                case when a.keycnt > 11 then index_col(b.table_name1,a.indid,11) end||','||
                case when a.keycnt > 12 then index_col(b.table_name1,a.indid,12) end||','||
                case when a.keycnt > 13 then index_col(b.table_name1,a.indid,13) end||','||
                case when a.keycnt > 14 then index_col(b.table_name1,a.indid,14) end||','||
                case when a.keycnt > 15 then index_col(b.table_name1,a.indid,15) end||','||
                case when a.keycnt > 16 then index_col(b.table_name1,a.indid,16) end||','||
                case when a.keycnt > 17 then index_col(b.table_name1,a.indid,17) end||','||
                case when a.keycnt > 18 then index_col(b.table_name1,a.indid,18) end||','||
                case when a.keycnt > 19 then index_col(b.table_name1,a.indid,19) end||','||
                case when a.keycnt > 20 then index_col(b.table_name1,a.indid,20) end||','
                )                                                               as index_column
    into  #indexscript1
    from   sysindexes a,
          #sysobjects b
    where a.id = b.id
    and   a.indid > 0
    and   a.keycnt >= 2
    group by b.table_name,a.name

    select  a.table_name
           ,a.index_name
           ,a.status
           ,a.status2
           ,a.keycnt
           ,a.attr1
           ,a.attr2
           ,substring(a.index_column,1,len(a.index_column)-20+a.keycnt-2) as index_column
    into   #indexscript2
    from   #indexscript1 a

    select 'create '||attr1||' '||attr2||' index '||index_name||' on '||table_name||' ('||index_column||')' as indexscript
    into   #indexscript3
    from   #indexscript2
    order by table_name,index_name

    ----------------------------------------------
    -- create table
    ----------------------------------------------
    create table #tablescript
    (
        table_name          varchar(200) null,
        column_id           int          null,
        column_name         char(200)    null,
        scale_name          char(30)     null,
        null_yn             varchar(10)  null,
        max_col             int          null
    )

    create table #maxcol
    (
        table_name          varchar(200) null,
        max_col             int          null
    )


    insert into #tablescript
    select  a.table_name                                              as table_name
           ,0                                                         as column_id
           ,'CREATE TABLE '||a.table_name||' ('                       as column_name
           ,''                                                        as scale_name
           ,''                                                        as null_yn
           ,0                                                         as max_col
    from   #sysobjects a

    insert into #tablescript
    select  a.table_name                                              as table_name
           ,b.colid                                                   as column_id
           ,b.name                                                    as column_name
           ,case when c.name like 'int%'     then 'int'
                 when c.name like 'ubigint%' then 'int'
                 when c.name like 'bit%'     then 'bit'
                 when c.name like 'image%'   then 'image'
                 when c.name like 'datetim%' then 'datetime'
                 when c.name like 'text%'    then 'text'
                 when c.name like 'numeric%' then 'numeric('||cast(b.prec as varchar)||','||cast(b.scale as varchar)||')'
                 else c.name||'('||cast(b.length as varchar)||')'
            end
            || case when convert(bit, (b.status & 0x80)) = 1 then ' identity ' else '' end
                                                                      as scale_name
           ,case when b.status = 0 or convert(bit, (b.status & 0x80)) = 1 then 'not null,'
                 when c.name like 'bit%'                                  then ','
                 else 'null,' end  as null_yn
           ,0                                                         as max_col
    from   #sysobjects a,
           syscolumns  b,
           systypes    c
    where  a.id = b.id
    and    b.usertype = c.usertype
    and    c.name not in ('sysname', 'longsysname', 'nchar', 'nvarchar')
    order by a.table_name,b.colid

    -- select * from #tablescript order by table_name,column_id

    -- ä�� max_col
    truncate table #maxcol
    insert into #maxcol select  a.table_name,max(a.column_id) as max_col from #tablescript a group by a.table_name
    update #tablescript set a.max_col = b.max_col from #tablescript a, #maxcol b where a.table_name = b.table_name

    insert into #tablescript
    select  distinct
            a.table_name                                                       as table_name
           ,a.max_col+1                                                        as column_id
           ,'CONSTRAINT '||b.index_name||' PRIMARY KEY ('||b.index_column||')' as column_name
           ,''                                                                 as scale_name
           ,''                                                                 as null_yn
           ,a.max_col+1                                                        as max_col
    from   #tablescript a,
           #indexscript2 b
    where  a.table_name = b.table_name
    and    b.status & 2048 = 2048

    -- ä�� max_col
    truncate table #maxcol
    insert into #maxcol select  a.table_name,max(a.column_id) as max_col from #tablescript a group by a.table_name
    update #tablescript set a.max_col = b.max_col from #tablescript a, #maxcol b where a.table_name = b.table_name

    insert into #tablescript
    select  distinct
            a.table_name                                                       as table_name
           ,a.max_col+1                                                        as column_id
           ,')'                                                                as column_name
           ,''                                                                 as scale_name
           ,''                                                                 as null_yn
           ,a.max_col+1                                                        as max_col
    from   #tablescript a

    -- ä�� max_col
    truncate table #maxcol
    insert into #maxcol select  a.table_name,max(a.column_id) as max_col from #tablescript a group by a.table_name
    update #tablescript set a.max_col = b.max_col from #tablescript a, #maxcol b where a.table_name = b.table_name

    insert into #tablescript
    select  distinct
            a.table_name                                                       as table_name
           ,a.max_col+1                                                        as column_id
           ,'LOCK DATAROWS'                                                    as column_name
           ,''                                                                 as scale_name
           ,''                                                                 as null_yn
           ,a.max_col+1                                                        as max_col
    from   #tablescript a

    truncate table #maxcol
    insert into #maxcol select  a.table_name,max(a.column_id) as max_col from #tablescript a group by a.table_name
    update #tablescript set a.max_col = b.max_col from #tablescript a, #maxcol b where a.table_name = b.table_name

    insert into #tablescript
    select  distinct
            a.table_name                                                       as table_name
           ,a.max_col+1                                                        as column_id
           ,'go'                                                                as column_name
           ,''                                                                 as scale_name
           ,''                                                                 as null_yn
           ,a.max_col+1                                                        as max_col
    from   #tablescript a

    -- ä�� max_col
    truncate table #maxcol
    insert into #maxcol select  a.table_name,max(a.column_id) as max_col from #tablescript a group by a.table_name
    update #tablescript set a.max_col = b.max_col from #tablescript a, #maxcol b where a.table_name = b.table_name

    select  column_name||'    '||scale_name||'    '||null_yn as tablescript
    into   #tablescript1
    from   #tablescript
    order by table_name,column_id

    ----------------------------------------------
    -- ���
    ----------------------------------------------
    select dropscript  as script from #dropscript
    union all
    select tablescript as script from #tablescript1
    union all
    select indexscript as script from #indexscript3

end
GO

sp_procxmode sp_tablescript, ANYMODE 
GO
GRANT EXEC ON sp_tablescript TO PUBLIC 
GO
