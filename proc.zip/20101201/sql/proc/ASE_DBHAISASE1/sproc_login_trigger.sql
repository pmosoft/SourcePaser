if  exists ( select 1 from sysobjects 
             where name ='sproc_login_trigger'
             and type = 'P')
begin
  DROP procedure sproc_login_trigger
end 
GO

create proc sproc_login_trigger 
as 
begin 
        IF suser_name() = 'ett_ase1' 
        begin 
                set statement_cache off 
                set literal_autoparam off 
        end 
end 

GO

sp_procxmode sproc_login_trigger, ANYMODE 
GO
GRANT EXEC ON sproc_login_trigger TO PUBLIC 
GO
