if  exists ( select 1 from sysobjects 
             where name ='SP_SE1_MINE_MGR_2001'
             and type = 'P')
begin
  DROP procedure SP_SE1_MINE_MGR_2001
end 
GO


create procedure SP_SE1_MINE_MGR_2001 ( @P_�ŷ�����             CHAR    (  8)
                                      , @P_CONCURRENT_MOD_VAL   INT                 -- ����ä�� �����б� ����
                                      , @P_CONCURRENT_NO        INT                 -- ����ä�� �����б� ��ȣ(0,1,2...)
                                      , @P_FILE                 VARCHAR (128))      
as
begin
	
	------------------------------------------------------------------------
	-- �ſ�ī��� �ŷ��αװ� ���� �Ǵ� ���Ͽ� �ŷ��α� ������ �߻�������
	-- @P_�ŷ����� �̻��ΰǵ� ������ ��Ų��.
	------------------------------------------------------------------------
	if @P_FILE like '%mines_ca%' or
	   @P_FILE like '%mines_cb%'
    begin	   
    	SELECT  top 1 
    	        TRANS_YMD
    	      , FILE_NAME
    	      , EAI_TRANS_SEQ
    	      , TRANS_TYPE
    	      , TRANS_START_RECSEQ
    	      , TRANS_END_RECSEQ
    	      , TRANS_TOT_CNT
    	      , TRANS_FILESIZE
    	      , TRANS_ENDTIME
    	      , TRANS_FILECRE_TIME
    	      , STATUS 
    	      , TRANS_RETRY
        FROM    MAIS_EAI_FILE_PTCL_ITF
    	WHERE   TRANS_YMD in (@P_�ŷ�����, convert(char(8), dateadd(dd, 1, @P_�ŷ�����), 112))
    	  AND   STATUS     = 'N'
    	  AND   FILE_NAME LIKE @P_FILE||'%'
    	  AND   EAI_TRANS_SEQ % @P_CONCURRENT_MOD_VAL = @P_CONCURRENT_NO
       ORDER BY EAI_TRANS_SEQ ASC
    end
    else
    begin
    	SELECT  top 1 
    	        TRANS_YMD
    	      , FILE_NAME
    	      , EAI_TRANS_SEQ
    	      , TRANS_TYPE
    	      , TRANS_START_RECSEQ
    	      , TRANS_END_RECSEQ
    	      , TRANS_TOT_CNT
    	      , TRANS_FILESIZE
    	      , TRANS_ENDTIME
    	      , TRANS_FILECRE_TIME
    	      , STATUS 
    	      , TRANS_RETRY
        FROM    MAIS_EAI_FILE_PTCL_ITF
    	WHERE   TRANS_YMD  = @P_�ŷ�����
    	  AND   STATUS     = 'N'
    	  AND   FILE_NAME  LIKE @P_FILE||'%'
    	  AND   EAI_TRANS_SEQ % @P_CONCURRENT_MOD_VAL = @P_CONCURRENT_NO
       ORDER BY EAI_TRANS_SEQ ASC        
    end
end


GO

sp_procxmode SP_SE1_MINE_MGR_2001, ANYMODE 
GO
GRANT EXEC ON SP_SE1_MINE_MGR_2001 TO PUBLIC 
GO
