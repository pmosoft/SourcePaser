#!/bin/csh -f

if ( $#argv < 1 ) then
    echo "����: src_mngv.sh "
    echo "�뿹: src_mngv.sh "
    set jobfg = "�Ϲ�"
else
    set jobfg = $argv[1]
endif
set today=`date +%Y%m%d`
set wrkDir="/ais_ett/app/pgm/sql/proc"
set bakDir="/ais_ett/app/pgm/sql/proc/version/vbak"
set vsmDir="/ais_ett/app/pgm/sql/proc/version/vsMngList"

cd ${wrkDir}
foreach dirKind ( asiq ASE_DBHAISASE ASE_DBHAISASE1 )

    if ( ! -d ${bakDir}/${dirKind} ) then
        /bin/mkdir -p ${bakDir}/${dirKind} >& /dev/null
    endif

    foreach filnm ( `find ./${dirKind}/ -name "*.sql" -mtime -1 -print` )
        set prgid = `basename ${filnm}`
        set prgdr = `dirname ${filnm}`
        ## set prgpt = `echo "$prgdr" | cut -f7-15 -d'/'`
        if ( -f "${bakDir}/${filnm}" ) then
            ####################################################
            ## ����� �κ��� �ִ��� �Ǵ�
            ####################################################
            if ( `diff -w ${wrkDir}/${filnm} ${bakDir}/${filnm} | wc -l` > 0 ) then
                if ( ! -d ${vsmDir}/${today}/${dirKind} ) then
                    /bin/mkdir -p ${vsmDir}/${today}/${dirKind}
                endif
                /bin/cp ${bakDir}/${filnm} ${vsmDir}/${today}/${filnm}
                /bin/cp ${wrkDir}/${filnm} ${bakDir}/${filnm}
            endif
        else
            if ( ! -d ${vsmDir}/${today}/${dirKind} ) then
                /bin/mkdir -p ${vsmDir}/${today}/${dirKind}
            endif
            /bin/cp ${wrkDir}/${filnm} ${vsmDir}/${today}/${filnm}
            /bin/cp ${wrkDir}/${filnm} ${bakDir}/${filnm}
        endif
    end

end
