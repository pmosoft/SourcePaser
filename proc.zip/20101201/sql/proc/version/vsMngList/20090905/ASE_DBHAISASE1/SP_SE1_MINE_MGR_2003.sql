if  exists ( select 1 from sysobjects 
             where name ='SP_SE1_MINE_MGR_2003'
             and type = 'P')
begin
  DROP procedure SP_SE1_MINE_MGR_2003
end 
GO

create procedure SP_SE1_MINE_MGR_2003 ( @P_�ŷ�����    CHAR    (8), @P_FILE    VARCHAR    (128))      
as
begin
	UPDATE MAIS_EAI_FILE_PTCL_ITF
	   SET TRANS_TYPE = CASE TRANS_TYPE WHEN 'E' THEN 'R' ELSE TRANS_TYPE END
         , STATUS ='Y'
         , TRANS_DT = CONVERT(CHAR(8), GETDATE(), 112)                       --339 ġ������
         , TRANS_TM = substring(convert(char(8), getdate(), 108), 1,2) +
                     substring(convert(char(8), getdate(), 108), 4,2) +
                     substring(convert(char(8), getdate(), 108), 7,2)       --340 ó���ð�
	 WHERE FILE_NAME = @P_FILE
end
GO

sp_procxmode SP_SE1_MINE_MGR_2003, ANYMODE 
GO
GRANT EXEC ON SP_SE1_MINE_MGR_2003 TO PUBLIC 
GO
