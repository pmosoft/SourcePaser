if  exists ( select 1 from sysobjects 
             where name ='sp_tablescript'
             and type = 'P')
begin
  DROP procedure sp_tablescript
end 
GO

create procedure ett_iq.sp_tablescript(in I_���̺��� varchar(100))
begin
  create table #TEMP1(
    COLUMN_ID integer null,
    TABLESCRIPT varchar(300) null,
    COLUMN_NAME char(40) null,
    SCALE_NAME char(20) null,
    CARDINALITY integer null,
    );
  insert into #TEMP1 select 0 as COLUMN_ID,'CREATE TABLE ' || I_���̺��� || ' (','','',null;
  create table #TABLESCRIPT(
    COLUMN_ID integer not null,
    COLUMN_NAME char(40) not null,
    SCALE_NAME char(20) not null,
    NULL_YN char(8) not null,
    APPROX_UNIQUE_COUNT integer not null,
    CARDINALITY integer not null,
    MAX_COL integer not null,
    );
  insert into #TABLESCRIPT
    select B.COLUMN_ID as COLUMN_ID,
      UPPER(B.COLUMN_NAME) as COLUMN_NAME,
      case when C.DOMAIN_NAME = 'integer' then 'INT'
      else
        UPPER(C.DOMAIN_NAME) || '(' || B.WIDTH || case when B.SCALE = 0 then '' else ',' || 
          B.SCALE end || ')'
      end as SCALE_NAME,
      case when B.NULLS = 'N' then 'NOT NULL' else 'NULL' end as NULL_YN,
      D.APPROX_UNIQUE_COUNT as APPROX_UNIQUE_COUNT,
      D.CARDINALITY as CARDINALITY,
      0 as MAX_COL from
      SYS.SYSTABLE as A,
      SYS.SYSCOLUMN as B,
      SYS.SYSDOMAIN as C,
      SYS.SYSIQCOLUMN as D where
      B.TABLE_ID = A.TABLE_ID and
      C.DOMAIN_ID = B.DOMAIN_ID and
      B.TABLE_ID = D.TABLE_ID and
      B.COLUMN_ID = D.COLUMN_ID and
      A.TABLE_NAME = I_���̺���;
  --AND  A.TABLE_NAME = 'OT_IQF_���_���ʺ�ȯ_CURRENT'
  update #TABLESCRIPT as A set
    A.MAX_COL = B.MAX_COL from
    #TABLESCRIPT as A,(select MAX(COLUMN_ID) as MAX_COL from #TABLESCRIPT) as B;
  insert into #TEMP1
    select COLUMN_ID,
      COLUMN_NAME || SCALE_NAME || TRIM(NULL_YN) || 
      case when APPROX_UNIQUE_COUNT = 0 then '' else ' IQ UNIQUE(' || 
        APPROX_UNIQUE_COUNT || ')' end || 
      case when COLUMN_ID = MAX_COL then ',' else ',' end as TABLESCRIPT,
      COLUMN_NAME,
      SCALE_NAME,
      CARDINALITY from
      #TABLESCRIPT order by
      COLUMN_ID asc;
  select NUMBER(*) as CNT,B.COLUMN_NAME into
    #TEMP2 from
    SYS.SYSTABLE as A,
    SYS.SYSCOLUMN as B where
    A.TABLE_ID = B.TABLE_ID and
    A.TABLE_NAME = I_���̺��� and
    B.PKEY = 'Y' order by
    B.COLUMN_ID asc;
  insert into #TEMP1
    select(select MAX(COLUMN_ID)+1 from #TEMP1) as COLUMN_ID,'PRIMARY KEY(' || 
      MAX(case when CNT = 1 then TRIM(COLUMN_NAME) || (case when B.MAX_CNT <> 1 then ',' else ')' end) else null end) || 
      MAX(case when CNT = 2 then TRIM(COLUMN_NAME) || (case when B.MAX_CNT <> 2 then ',' else ')' end) else null end) || 
      MAX(case when CNT = 3 then TRIM(COLUMN_NAME) || (case when B.MAX_CNT <> 3 then ',' else ')' end) else null end) || 
      MAX(case when CNT = 4 then TRIM(COLUMN_NAME) || (case when B.MAX_CNT <> 4 then ',' else ')' end) else null end) || 
      MAX(case when CNT = 5 then TRIM(COLUMN_NAME) || (case when B.MAX_CNT <> 5 then ',' else ')' end) else null end) || 
      MAX(case when CNT = 6 then TRIM(COLUMN_NAME) || (case when B.MAX_CNT <> 6 then ',' else ')' end) else null end) || 
      MAX(case when CNT = 7 then TRIM(COLUMN_NAME) || (case when B.MAX_CNT <> 7 then ',' else ')' end) else null end) || 
      MAX(case when CNT = 8 then TRIM(COLUMN_NAME) || (case when B.MAX_CNT <> 8 then ',' else ')' end) else null end) || 
      MAX(case when CNT = 9 then TRIM(COLUMN_NAME) || (case when B.MAX_CNT <> 9 then ',' else ')' end) else null end) || 
      MAX(case when CNT = 10 then TRIM(COLUMN_NAME) || (case when B.MAX_CNT <> 10 then ',' else ')' end) else null end) as TABLESCRIPT,'','',
      null from
      #TEMP2 as A,
      (select MAX(CNT) as MAX_CNT from #TEMP2) as B;
  insert into #TEMP1
    select(select MAX(COLUMN_ID)+1 from #TEMP1) as COLUMN_ID,')' as TABLESCRIPT,'','',
      null;
  insert into #TEMP1
    select(select MAX(COLUMN_ID)+1 from #TEMP1) as COLUMN_ID,'GRANT SELECT ON ' || 
      I_���̺��� || ' TO web_iq' as TABLESCRIPT,'','',
      null;
  select TRIM(T.TABLE_NAME) as TABLE_NAME,
    TRIM(C.COLUMN_NAME) as COLUMN_NAME,
    C.COLUMN_ID as COLUMN_ID,
    TRIM(I.INDEX_TYPE) as TYPE,
    TRIM(I.INDEX_NAME) as INDEX_NAME,
    "UNIQUE",
    case when I.INDEX_TYPE <> 'FP' then 'CREATE ' || 
      I.INDEX_TYPE || ' INDEX ' || I.INDEX_NAME || ' ON ' || T.TABLE_NAME || ' (' || C.COLUMN_NAME || ')' else '' end as INDEX_SCRIPT into
    #TEMP3 from
    SYS.SYSTABLE as T,
    SYS.SYSCOLUMN as C,
    SYS.SYSINDEX as I,
    SYS.SYSIXCOL as IC where
    T.TABLE_ID = C.TABLE_ID and
    C.TABLE_ID = I.TABLE_ID and
    I.TABLE_ID = IC.TABLE_ID and
    I.INDEX_ID = IC.INDEX_ID and
    C.COLUMN_ID = IC.COLUMN_ID and
    T.SERVER_TYPE = 'IQ' and
    T.TABLE_TYPE in( 'BASE','GBL TEMP') and
    T.TABLE_NAME = I_���̺��� and
    --AND    T.TABLE_NAME = 'OT_IQF_���_���ʺ�ȯ_CURRENT'
    I.INDEX_TYPE <> 'SA' order by
    C.COLUMN_ID asc;
  select A.TABLE_NAME,
    A.COLUMN_NAME,
    --,MAX(CASE WHEN A.TYPE = 'FP'  THEN A.INDEX_NAME   ELSE '' END) FP_INDEX
    MAX(case when A.TYPE = 'LF' then A.INDEX_NAME
    --
    --
    --if  exists ( select 1 from sysobjects 
    --             where name ='sp_tablescript'
    --             and type = 'P')
    --begin
    --  DROP procedure sp_tablescript
    --end 
    --GO
    --
    --create PROCEDURE sp_tablescript 
    --(
    --  IN I_���̺��� VARCHAR(100)
    --)
    --BEGIN
    --
    --
    --    SELECT  TRIM(A.TABLE_NAME)                                      AS ���̺���
    --           ,TRIM(UPPER(B.COLUMN_NAME))                              AS Į����
    --           ,TRIM(B.REMARKS)                                         AS Į���ѱ۸�
    --           ,CASE WHEN C.DOMAIN_NAME = 'integer'
    --                 THEN 'INT'
    --                 ELSE UPPER(C.DOMAIN_NAME)||'('||B.WIDTH||CASE WHEN B.SCALE = 0 THEN ''
    --                                                               ELSE ','||B.SCALE END||')'
    --            END                                                     AS Į���Ӽ�
    --           ,CASE WHEN B.NULLS = 'N' THEN 'NOT NULL' ELSE 'NULL' END AS NULL_YN
    --           ,CASE WHEN B.PKEY = 'Y' THEN 'PK' ELSE '' END            AS PK
    --    FROM   SYS.SYSTABLE    AS A,
    --           SYS.SYSCOLUMN   AS B,
    --           SYS.SYSDOMAIN   AS C,
    --           SYS.SYSIQCOLUMN AS D
    --    WHERE  B.TABLE_ID = A.TABLE_ID
    --      AND  C.DOMAIN_ID = B.DOMAIN_ID
    --      AND  B.TABLE_ID  = D.TABLE_ID
    --      AND  B.COLUMN_ID = D.COLUMN_ID
    --      AND  A.TABLE_NAME = I_���̺���
    --      --AND  A.TABLE_NAME = 'EIIM_LN_CONT_BASE'
    --    ;
    --
    --
    --END
    --
    else '' end) as LF_INDEX,MAX(case when A.TYPE = 'HG' then A.INDEX_NAME
    else '' end) as HG_INDEX,MAX(case when A.TYPE = 'HNG' then A.INDEX_NAME
    else '' end) as HNG_INDEX,MAX(case when A.TYPE = 'LF' then A.INDEX_SCRIPT
    else '' end) as LF_INDEX_SCRIPT,MAX(case when A.TYPE = 'HG' then A.INDEX_SCRIPT
    else '' end) as HG_INDEX_SCRIPT,MAX(case when A.TYPE = 'HNG' then A.INDEX_SCRIPT
    else '' end) as HNG_INDEX_SCRIPT into #TEMP4 from
    #TEMP3 as A where
    (A.TYPE in( 'LF','HNG') or(A.TYPE = 'HG' and A.INDEX_NAME not like 'ASIQ_IDX_%'))
    group by A.TABLE_NAME,A.COLUMN_NAME,A.COLUMN_ID order by
    A.COLUMN_ID asc;
  select A.COLUMN_ID as NUM,
    TRIM(A.TABLESCRIPT) as TABLESCRIPT,
    TRIM(A.COLUMN_NAME) as COLUMN_NAME,
    TRIM(A.SCALE_NAME) as SCALE,
    A.CARDINALITY as ����,
    ISNULL(TRIM(B.LF_INDEX),'') as LF_INDEX,
    ISNULL(TRIM(B.HG_INDEX),'') as HG_INDEX,
    ISNULL(TRIM(B.HNG_INDEX),'') as HNG_INDEX,
    ISNULL(TRIM(B.LF_INDEX_SCRIPT),'') as LF_INDEX_SCRIPT,
    ISNULL(TRIM(B.HG_INDEX_SCRIPT),'') as HG_INDEX_SCRIPT,
    ISNULL(TRIM(B.HNG_INDEX_SCRIPT),'') as HNG_INDEX_SCRIPT from
    #TEMP1 as A,
    #TEMP4 as B where
    A.COLUMN_NAME *= B.COLUMN_NAME order by
    A.COLUMN_ID asc
end
GO

GRANT EXECUTE ON sp_tablescript TO web_iq 
GO
