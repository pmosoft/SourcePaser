if  exists ( select 1 from sysobjects 
             where name ='SF_AUDIT_getFillData'
             and type = 'P')
begin
  DROP procedure SF_AUDIT_getFillData
end 
GO

create function ett_iq.SF_AUDIT_getFillData(in p_data varchar(20),in p_addChar char(1),in p_LorR char(1),in p_length integer)
returns varchar(40)
begin
  declare v_i integer;
  declare v_diffLength integer;
  declare v_temp varchar(20);
  declare v_resulte varchar(40);
  set v_i=0;
  if length(p_data) >= p_length then
    return p_data
  end if;
  set v_diffLength=p_length-length(p_data);
  while v_i < v_diffLength loop
    set v_temp=v_temp+p_addChar;
    set v_i=v_i+1
  end loop;
  if p_LorR = 'L' then
    set v_resulte=v_temp+p_data
  else
    set v_resulte=p_data+v_temp
  end if;
  return v_resulte
end
GO

GRANT EXECUTE ON SF_AUDIT_getFillData TO web_iq 
GO
