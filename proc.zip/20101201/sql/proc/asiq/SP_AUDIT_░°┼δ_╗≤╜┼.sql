if  exists ( select 1 from sysobjects 
             where name ='SP_AUDIT_����_���'
             and type = 'P')
begin
  DROP procedure SP_AUDIT_����_���
end 
GO

create procedure ett_iq.SP_AUDIT_����_���(@PROC_GUBUN char(2),@DOC_CODE char(1),@DECIDE_GUBUN_CODE char(1),@TITLE char(100),@UPMU_GUBUN_CODE char(3),@BRNCH_NO char(4),@DECIDE_URL varchar(1000),@BRNCH_DECIDE_URL varchar(1000),@OPINION varchar(1024),@PRE_DECIDE_NO integer,@UPMU_TABLE_NAME char(100),@PKWHERE char(400),@FIRST_DECIDE_EMPNO char(7),@TRGT_BRNCH_NO char(4))
as
if @PROC_GUBUN = '10'
  begin
    execute SP_AUDIT_����_����� @PROC_GUBUN,
    @DOC_CODE,
    @DECIDE_GUBUN_CODE,
    @TITLE,
    @UPMU_GUBUN_CODE,
    @BRNCH_NO,
    @DECIDE_URL,
    @BRNCH_DECIDE_URL,
    @OPINION,
    @PRE_DECIDE_NO,
    @UPMU_TABLE_NAME,
    @PKWHERE,
    @FIRST_DECIDE_EMPNO,
    @TRGT_BRNCH_NO
  end
else
  if @PROC_GUBUN = '11'
    begin
      execute SP_AUDIT_����_����ҳ���� @PROC_GUBUN,
      @DOC_CODE,
      @DECIDE_GUBUN_CODE,
      @TITLE,
      @UPMU_GUBUN_CODE,
      @BRNCH_NO,
      @DECIDE_URL,
      @BRNCH_DECIDE_URL,
      @OPINION,
      @PRE_DECIDE_NO,
      @UPMU_TABLE_NAME,
      @PKWHERE,
      @FIRST_DECIDE_EMPNO,
      @TRGT_BRNCH_NO
    end
  else
    if @PROC_GUBUN = '20'
      begin
        execute SP_AUDIT_����_�ܻ�� @PROC_GUBUN,
        @DOC_CODE,
        @DECIDE_GUBUN_CODE,
        @TITLE,
        @UPMU_GUBUN_CODE,
        @BRNCH_NO,
        @DECIDE_URL,
        @BRNCH_DECIDE_URL,
        @OPINION,
        @PRE_DECIDE_NO,
        @UPMU_TABLE_NAME,
        @PKWHERE,
        @FIRST_DECIDE_EMPNO,
        @TRGT_BRNCH_NO
      end
    else
      if @PROC_GUBUN = '21'
        begin
          execute SP_AUDIT_����_�ܹݷ��ܻ�� @PROC_GUBUN,
          @DOC_CODE,
          @DECIDE_GUBUN_CODE,
          @TITLE,
          @UPMU_GUBUN_CODE,
          @BRNCH_NO,
          @DECIDE_URL,
          @BRNCH_DECIDE_URL,
          @OPINION,
          @PRE_DECIDE_NO,
          @UPMU_TABLE_NAME,
          @PKWHERE,
          @FIRST_DECIDE_EMPNO,
          @TRGT_BRNCH_NO
        end
return
GO

GRANT EXECUTE ON SP_AUDIT_����_��� TO web_iq 
GO
