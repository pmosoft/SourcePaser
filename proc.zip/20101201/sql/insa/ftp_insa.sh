#! /bin/sh
. /ais_ett/.aiscfg

DATE=`date +%Y%m%d`
BASE_NAME1=INSPECTION_DUTY
BASE_NAME2=INSPECTION_ATTEND
BASE_NAME3=INSPECTION_BR
BASE_NAME4=INSPECTION_DISCIP
BASE_NAME5=INSPECTION_MASTER
LOG_FILE=${cmmn_ase_log}/${BASE_CUT}_${DATE}.log

${bin_dir}/cmm_chk_iqconnect.sh  #-- ASIQ Connection ���� üũ Loop

## EAI ��ġ ����_������
echo ""
echo ""                                                                                    >> $LOG_FILE
echo "[������] ==> [FTP Start  -q  ${BASE_NAME1} , Date:" `date '+%Y-%m-%d %T'` "]"
echo "[������] ==> [FTP Start  -q  ${BASE_NAME1} , Date:" `date '+%Y-%m-%d %T'` "]"   >> $LOG_FILE

/aisftp/Recv/EMG/EMG/eaiBatch.sh -i HRM_AIS_IBS00005 -m f2fGet -f INSPECTION_DUTY.TXT -t INSPECTION_DUTY.TXT

## EAI ��ġ ����_����
echo ""
echo ""                                                                                    >> $LOG_FILE
echo "[��������] ==> [FTP Start  -q  ${BASE_NAME2} , Date:" `date '+%Y-%m-%d %T'` "]"
echo "[��������] ==> [FTP Start  -q  ${BASE_NAME2} , Date:" `date '+%Y-%m-%d %T'` "]"   >> $LOG_FILE

/aisftp/Recv/EMG/EMG/eaiBatch.sh -i HRM_AIS_IBS00005 -m f2fGet -f INSPECTION_ATTEND.TXT -t INSPECTION_ATTEND.TXT

## EAI ��ġ ����_�߷�
echo ""
echo ""                                                                                    >> $LOG_FILE
echo "[�߷�����] ==> [FTP Start  -q  ${BASE_NAME3} , Date:" `date '+%Y-%m-%d %T'` "]"
echo "[�߷�����] ==> [FTP Start  -q  ${BASE_NAME3} , Date:" `date '+%Y-%m-%d %T'` "]"   >> $LOG_FILE

/aisftp/Recv/EMG/EMG/eaiBatch.sh -i HRM_AIS_IBS00005 -m f2fGet -f INSPECTION_BR_N.TXT -t INSPECTION_BR.TXT

## EAI ��ġ ����_¡��
echo ""
echo ""                                                                                    >> $LOG_FILE
echo "[¡�����] ==> [FTP Start  -q  ${BASE_NAME4} , Date:" `date '+%Y-%m-%d %T'` "]"
echo "[¡�����] ==> [FTP Start  -q  ${BASE_NAME4} , Date:" `date '+%Y-%m-%d %T'` "]"   >> $LOG_FILE

/aisftp/Recv/EMG/EMG/eaiBatch.sh -i HRM_AIS_IBS00005 -m f2fGet -f INSPECTION_DISCIP.TXT -t INSPECTION_DISCIP.TXT

## EAI ��ġ ����_�λ�2
echo ""
echo ""                                                                                    >> $LOG_FILE
echo "[�λ�2] ==> [FTP Start  -q  ${BASE_NAME5} , Date:" `date '+%Y-%m-%d %T'` "]"
echo "[�λ�2] ==> [FTP Start  -q  ${BASE_NAME5} , Date:" `date '+%Y-%m-%d %T'` "]"   >> $LOG_FILE

/aisftp/Recv/EMG/EMG/eaiBatch.sh -i HRM_AIS_IBS00005 -m f2fGet -f INSPECTION_MASTER_N.TXT -t INSPECTION_MASTER.TXT

echo ""
echo ""                                                                                    >> $LOG_FILE
echo "[�λ� ����] ==> [FTP End  : Date:" `date '+%Y-%m-%d %T'` "]"
echo "[�λ� ����] ==> [FTP End  : Date:" `date '+%Y-%m-%d %T'` "]"   >> $LOG_FILE
