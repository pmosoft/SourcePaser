------------------------------------------------------------------------------------
--                                    ����1
------------------------------------------------------------------------------------
create or replace package osp_4364110q02_pkg as
    type    v_����_arr    is table of    varchar2(50)    index by binary_integer;
procedure osp_4364110q02_sel01
(
    i_�α��ξ��̵�                     in  varchar2,   -- �α���������ȣ
    i_����                             in  varchar2,
    o_����_arr                         out v_����_arr
);
end osp_4364110q02_pkg;
/
show errors;

create or replace package body osp_4364110q02_pkg
as
procedure osp_4364110q02_sel01
(
    i_�α��ξ��̵�                     in  varchar2,   -- �α���������ȣ
    i_����                             in  varchar2,
    o_����_arr                         out v_����_arr
)
is
begin

    select  ename
    bulk collect into    o_����_arr
    from    emp
    where   rownum < 5
    ;

    return;

exception
    when others then
        return;
end osp_4364110q02_sel01;
end osp_4364110q02_pkg;
/
show errors;

----------------
-- excute
----------------
set serverout on
set timing on

declare
  o_����_arr osp_4364110q02_pkg.v_����_arr;
begin
  osp_4364110q02_pkg.osp_4364110q02_sel01('1','p',o_����_arr);
    For i in 1..2 LOOP
        dbms_output.put_line(o_����_arr(i));
    End loop;
end;
/
show errors;

------------------------------------------------------------------------------------
--                                    ����2
------------------------------------------------------------------------------------
CREATE OR REPLACE PACKAGE pkg AS
  TYPE indexByTab IS TABLE OF VARCHAR2(20)
       INDEX BY BINARY_INTEGER;
END;

CREATE OR REPLACE PROCEDURE proc_out
          (p1 OUT pkg.indexByTab) IS
BEGIN
  p1(1) := 'string1';
  p1(2) := 'string2';
  p1(3) := 'string3';
END;

----------------
-- excute
----------------
set serverout on
set timing on

declare
  indexByTab pkg.indexByTab;
begin
    proc_out(indexByTab);
    For i in 1..2 LOOP
        dbms_output.put_line(indexByTab(i));
    End loop;
end;
/
SHOW ERRORS;