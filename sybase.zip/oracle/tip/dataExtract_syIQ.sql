<%@ page contentType="text/html; charset=EUC-KR" %>
<%@ page import="javax.naming.*" %>
<%@ page import="javax.sql.*" %>
<%@ page import="java.sql.*" %>
<%@ page import="java.io.*" %>
<%@ page import="java.util.*" %>

<%

//
// 90% �ϼ����� table script�� �����ϹǷ� ���۾� ������ �ʿ��Ѵ�.
//

Context ctx = null;
DataSource ds = null;
Connection con = null;
Statement stmt = null;
ResultSet rs = null;

String sSql = null;

try {

    String ���̺��� = request.getParameter("tableName");

    ctx = new InitialContext();
    ds = (DataSource) ctx.lookup("jdbc/asiqnffc");
    con = ds.getConnection();
    stmt = con.createStatement();

    String ���Թ��� = "insert into " + "tb_bmat�޴����� (";
    sSql = "\n select column_id,column_name                                                                  "+
           "\n from   SYS.SYSCOLUMN                                                                          "+
           "\n where  table_id = (select table_id from SYS.SYSTABLE where table_name = 'tb_bmat�޴�����')    "+
           "\n order by column_id                                                                            ";
    System.out.println(sSql);

    rs = stmt.executeQuery(sSql);

    while ( rs.next() )
    {
        ���Թ��� = ���Թ��� + rs.getString("column_name") + ",";
    }

    out.println("���Թ���="+���Թ���);

} catch ( Exception e ) {
    e.printStackTrace();
} finally {
    if ( stmt != null ) try { stmt.close(); } catch(Exception e) {}
    if ( con != null ) try { con.close(); } catch(Exception e) {}
}

%>



   