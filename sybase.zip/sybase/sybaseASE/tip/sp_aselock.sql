if  exists ( select 1 from sysobjects 
             where name ='sp_aselock'
             and type = 'P')
begin
  DROP procedure sp_aselock
end 
GO

create procedure sp_aselock
as
begin
    select a.spid
          ,a.locktype
          ,a.table_name
          ,b.cmd
          ,b.status
          ,b.loggedindatetime
          ,b.ipaddr
          ,b.hostname
          ,b.physical_io
          ,b.program_name
          ,b.blocked
          ,b.time_blocked
          ,b.tran_name
          ,b.cpu
          ,b.memusage
          ,a.dbname
    from (select distinct a.spid,locktype = v1.name,table_name = d.name,dbname = db_name(a.dbid)
          from master..syslocks a,master..spt_values v1,master..spt_values v2,sysobjects d
          where a.type = v1.number and (a.context+2049) = v2.number and a.id = d.id
          and v1.type = 'L' and v2.type = 'L2'
          and db_name(a.dbid) in ('DBHAISASE','DBHAISASE1','DBDSND1')
          and a.id not in (1,303,438)
          and d.type <> 'S') a,
          master.dbo.sysprocesses b
    where a.spid *= b.spid
    order by a.spid, a.table_name, a.locktype
end
GO

sp_procxmode sp_aselock, ANYMODE 
GO
GRANT EXEC ON sp_aselock TO PUBLIC 
GO
