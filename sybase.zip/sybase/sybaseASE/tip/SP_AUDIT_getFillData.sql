if  exists ( select 1 from sysobjects 
             where name ='SP_AUDIT_getFillData'
             and type = 'P')
begin
  DROP procedure SP_AUDIT_getFillData
end 
GO


--drop procedure  SP_AUDIT_getFillData
create procedure  SP_AUDIT_getFillData (
 @p_data  CHAR   (20)
,@p_addChar CHAR(1) 
,@p_LorR CHAR(1)
,@p_length int
,@p_outputValue char(20)  output
)

as
BEGIN
	declare @v_i      int            -- loop  �� ī��Ʈ ��  
	declare @v_len	   int 
	declare @v_diffLength  int            -- �ѱ���- ��         
	declare @v_temp        CHAR(20)    -- ����
	declare @v_resulte     CHAR(40)    -- �����
  
	select @v_i      =  0 
		
	select @v_len	=	datalength(ltrim(rtrim(@p_data))) 
        if  @v_len >=  @p_length  
	BEGIN 
		select @p_outputValue =	@p_data 
	END 

	select @v_diffLength = @p_length - datalength(ltrim(rtrim(@p_data)))

	while @v_i < @v_diffLength 
	begin
		select @v_temp = @v_temp + @p_addChar 
		select @v_i = @v_i + 1    
	end

	if @p_LorR = 'L' 
		BEGIN
			select @v_resulte = @v_temp +  @p_data 
		END
	else 
		BEGIN
			select @v_resulte = @p_data +  @v_temp 
		END
	select @p_outputValue =	@v_resulte
  
	RETURN 
END

GO

sp_procxmode SP_AUDIT_getFillData, ANYMODE 
GO
GRANT EXEC ON SP_AUDIT_getFillData TO PUBLIC 
GO
