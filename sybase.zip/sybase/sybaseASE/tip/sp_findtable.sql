if  exists ( select 1 from sysobjects 
             where name ='sp_findtable'
             and type = 'P')
begin
  DROP procedure sp_findtable
end 
GO

create procedure sp_findtable
(
  @���̺��� VARCHAR(100)
)
as
begin

select  a.name                                     as ���̺���
         ,'SELECT TOP 1 *  FROM '||a.name          as ����1
       ,b.rowcnt                                   as rowcnt
       --,cast(b.datarowsize as int)                 as rowsize
       ,d.datarowsize                              as rowsize
       ,cast(b.rowcnt*b.datarowsize/1024 as int)   as �뷮_k
       ,b.forwrowcnt                               as ����
       ,b.delrowcnt                                as ����
       ,convert(char(10),a.crdate,102)||' '||convert(char(8),a.crdate,108)
                                                   as ���ʻ����Ͻ�
       ,convert(char(10),c.moddate,102)||' '||convert(char(8),c.moddate,108)
                                                   as ���������Ͻ�
       ,a.id                                       as id
FROM   sysobjects a,
       systabstats b,
      (select  a.id
              ,max(a.moddate) as moddate
       from   sysstatistics a
       group by a.id) c,
      (select  a.id
              ,sum(a.length) as datarowsize
       from   syscolumns a
       group by a.id) d
where  a.id  = b.id
and    a.id *= c.id
and    a.id *= d.id
and    a.name like '%'||@���̺���||'%'
and    a.type = 'U'
and    b.indid = 0
order by a.name desc

end
GO

sp_procxmode sp_findtable, ANYMODE 
GO
GRANT EXEC ON sp_findtable TO PUBLIC 
GO
