if  exists ( select 1 from sysobjects 
             where name ='sp_bom'
             and type = 'P')
begin
  DROP procedure sp_bom
end 
GO

create proc sp_bom ( @mcode char(1) )
as
  declare @id numeric(5,0),@maxid numeric(5,0)

  create table #temp1(id numeric(5,0) identity, mcode char(1))
  select @id = 1
  insert #temp1(mcode)
  select child from orgtable where parent = @mcode

  while (1=1)
  begin
    insert #temp1(mcode)
    select a.child from orgtable a, #temp1 b
    where b.id = @id and b.mcode = a.parent

    if @@rowcount = 0
      select @maxid = max(id) from #temp1

    if @maxid = @id
    begin
      /* Adaptive Server has expanded all '*' elements in the following statement */ select #temp1.id, #temp1.mcode from #temp1
      return
    end
    select @id = @id + 1
  end
return
GO

sp_procxmode sp_bom, ANYMODE 
GO
GRANT EXEC ON sp_bom TO PUBLIC 
GO
