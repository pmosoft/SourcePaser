if  exists ( select 1 from sysobjects 
             where name ='sp_findfield'
             and type = 'P')
begin
  DROP procedure sp_findfield
end 
GO

create procedure sp_findfield
(
  @�÷��� VARCHAR(100)
)
as
/*
sp_findfield ������
*/
begin

    select  rtrim(a.name)  as table_name
           ,rtrim(b.name) as column_name
    from   sysobjects a,
           syscolumns b
    where  a.id = b.id
    and    a.type = 'U'
    and    b.name like '%'||@�÷���||'%'
    order by a.name

end
GO

sp_procxmode sp_findfield, ANYMODE 
GO
GRANT EXEC ON sp_findfield TO PUBLIC 
GO
