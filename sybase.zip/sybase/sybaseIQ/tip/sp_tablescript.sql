if  exists ( select 1 from sysobjects 
             where name ='sp_tablescript'
             and type = 'P')
begin
  DROP procedure sp_tablescript
end 
GO

create PROCEDURE sp_tablescript 
(
  IN I_���̺��� VARCHAR(100)
)
BEGIN


    CREATE TABLE #TEMP1
    (
         COLUMN_ID           INT          NULL,
         TABLESCRIPT         VARCHAR(300) NULL,
         COLUMN_NAME         CHAR(50)     NULL,
         SCALE_NAME          CHAR(20)     NULL,
         CARDINALITY         INT          NULL,
    );

    INSERT INTO #TEMP1 SELECT 0  AS COLUMN_ID, 'CREATE TABLE '||I_���̺���||' (','','',NULL;

    CREATE TABLE #TABLESCRIPT
    (
        COLUMN_ID           INT     ,
        COLUMN_NAME         CHAR(50),
        SCALE_NAME          CHAR(20),
        NULL_YN             CHAR(8) ,
        APPROX_UNIQUE_COUNT INT     ,
        CARDINALITY         INT     ,
        MAX_COL             INT
    );

    INSERT INTO #TABLESCRIPT
    SELECT  B.COLUMN_ID                                             AS COLUMN_ID
           ,UPPER(B.COLUMN_NAME)                                    AS COLUMN_NAME
           ,CASE WHEN C.DOMAIN_NAME = 'integer'   THEN 'INT'
                 WHEN C.DOMAIN_NAME = 'timestamp' THEN 'TIMESTAMP'
                 ELSE UPPER(C.DOMAIN_NAME)||'('||B.WIDTH||CASE WHEN B.SCALE = 0 THEN ''
                                                               ELSE ','||B.SCALE END||')'
            END                                                     AS SCALE_NAME
           ,CASE WHEN B.NULLS = 'N' THEN 'NOT NULL' ELSE 'NULL' END AS NULL_YN
           ,D.APPROX_UNIQUE_COUNT                                   AS APPROX_UNIQUE_COUNT
           ,D.CARDINALITY                                           AS CARDINALITY
           ,0                                                       AS MAX_COL
    FROM   SYS.SYSTABLE    AS A,
           SYS.SYSCOLUMN   AS B,
           SYS.SYSDOMAIN   AS C,
           SYS.SYSIQCOLUMN AS D
    WHERE  B.TABLE_ID = A.TABLE_ID
      AND  C.DOMAIN_ID = B.DOMAIN_ID
      AND  B.TABLE_ID  = D.TABLE_ID
      AND  B.COLUMN_ID = D.COLUMN_ID
      AND  A.TABLE_NAME = I_���̺���
      --AND  A.TABLE_NAME = 'OT_IQF_���_���ʺ�ȯ_CURRENT'
    ;

    UPDATE #TABLESCRIPT
    SET A.MAX_COL = B.MAX_COL
    FROM #TABLESCRIPT A,(SELECT MAX(COLUMN_ID) MAX_COL FROM #TABLESCRIPT) B
    ;

    INSERT INTO #TEMP1
    SELECT  COLUMN_ID
           ,COLUMN_NAME||SCALE_NAME||TRIM(NULL_YN)
           -- ||CASE WHEN APPROX_UNIQUE_COUNT=0 THEN ''
           --        ELSE ' IQ UNIQUE('||APPROX_UNIQUE_COUNT||')'
           --   END
            ||CASE WHEN COLUMN_ID=MAX_COL THEN ',' ELSE ',' END AS TABLESCRIPT
           ,COLUMN_NAME
           ,SCALE_NAME
           ,CARDINALITY
    FROM   #TABLESCRIPT
    ORDER BY COLUMN_ID
    ;

    SELECT NUMBER(*) CNT,B.COLUMN_NAME
    INTO   #TEMP2
    FROM   SYS.SYSTABLE  A,
           SYS.SYSCOLUMN B
    WHERE  A.TABLE_ID = B.TABLE_ID
      AND  A.TABLE_NAME = I_���̺���
      AND  B.PKEY = 'Y'
    ORDER BY B.COLUMN_ID;

    INSERT INTO #TEMP1
    SELECT (SELECT MAX(COLUMN_ID)+1 FROM #TEMP1) AS COLUMN_ID
     ,'CONSTRAINT '||I_���̺���||'_PK PRIMARY KEY('||
      MAX(CASE WHEN CNT =  1 THEN TRIM(COLUMN_NAME)||(CASE WHEN B.MAX_CNT <>  1 THEN ',' ELSE ')' END) ELSE NULL END)
    ||MAX(CASE WHEN CNT =  2 THEN TRIM(COLUMN_NAME)||(CASE WHEN B.MAX_CNT <>  2 THEN ',' ELSE ')' END) ELSE NULL END)
    ||MAX(CASE WHEN CNT =  3 THEN TRIM(COLUMN_NAME)||(CASE WHEN B.MAX_CNT <>  3 THEN ',' ELSE ')' END) ELSE NULL END)
    ||MAX(CASE WHEN CNT =  4 THEN TRIM(COLUMN_NAME)||(CASE WHEN B.MAX_CNT <>  4 THEN ',' ELSE ')' END) ELSE NULL END)
    ||MAX(CASE WHEN CNT =  5 THEN TRIM(COLUMN_NAME)||(CASE WHEN B.MAX_CNT <>  5 THEN ',' ELSE ')' END) ELSE NULL END)
    ||MAX(CASE WHEN CNT =  6 THEN TRIM(COLUMN_NAME)||(CASE WHEN B.MAX_CNT <>  6 THEN ',' ELSE ')' END) ELSE NULL END)
    ||MAX(CASE WHEN CNT =  7 THEN TRIM(COLUMN_NAME)||(CASE WHEN B.MAX_CNT <>  7 THEN ',' ELSE ')' END) ELSE NULL END)
    ||MAX(CASE WHEN CNT =  8 THEN TRIM(COLUMN_NAME)||(CASE WHEN B.MAX_CNT <>  8 THEN ',' ELSE ')' END) ELSE NULL END)
    ||MAX(CASE WHEN CNT =  9 THEN TRIM(COLUMN_NAME)||(CASE WHEN B.MAX_CNT <>  9 THEN ',' ELSE ')' END) ELSE NULL END)
    ||MAX(CASE WHEN CNT = 10 THEN TRIM(COLUMN_NAME)||(CASE WHEN B.MAX_CNT <> 10 THEN ',' ELSE ')' END) ELSE NULL END)
    ||MAX(CASE WHEN CNT = 11 THEN TRIM(COLUMN_NAME)||(CASE WHEN B.MAX_CNT <> 11 THEN ',' ELSE ')' END) ELSE NULL END)
    ||MAX(CASE WHEN CNT = 12 THEN TRIM(COLUMN_NAME)||(CASE WHEN B.MAX_CNT <> 12 THEN ',' ELSE ')' END) ELSE NULL END)
    ||MAX(CASE WHEN CNT = 13 THEN TRIM(COLUMN_NAME)||(CASE WHEN B.MAX_CNT <> 13 THEN ',' ELSE ')' END) ELSE NULL END)
    ||MAX(CASE WHEN CNT = 14 THEN TRIM(COLUMN_NAME)||(CASE WHEN B.MAX_CNT <> 14 THEN ',' ELSE ')' END) ELSE NULL END)
    ||MAX(CASE WHEN CNT = 15 THEN TRIM(COLUMN_NAME)||(CASE WHEN B.MAX_CNT <> 15 THEN ',' ELSE ')' END) ELSE NULL END)
    ||MAX(CASE WHEN CNT = 16 THEN TRIM(COLUMN_NAME)||(CASE WHEN B.MAX_CNT <> 16 THEN ',' ELSE ')' END) ELSE NULL END)
    ||MAX(CASE WHEN CNT = 17 THEN TRIM(COLUMN_NAME)||(CASE WHEN B.MAX_CNT <> 17 THEN ',' ELSE ')' END) ELSE NULL END)
    ||MAX(CASE WHEN CNT = 18 THEN TRIM(COLUMN_NAME)||(CASE WHEN B.MAX_CNT <> 18 THEN ',' ELSE ')' END) ELSE NULL END)
    ||MAX(CASE WHEN CNT = 19 THEN TRIM(COLUMN_NAME)||(CASE WHEN B.MAX_CNT <> 19 THEN ',' ELSE ')' END) ELSE NULL END)
    ||MAX(CASE WHEN CNT = 20 THEN TRIM(COLUMN_NAME)||(CASE WHEN B.MAX_CNT <> 20 THEN ',' ELSE ')' END) ELSE NULL END)
    AS TABLESCRIPT
    ,'','',NULL
    FROM #TEMP2 A,
          (SELECT MAX(CNT) MAX_CNT FROM #TEMP2) B
    ;

    INSERT INTO #TEMP1
    SELECT (SELECT MAX(COLUMN_ID)+1 FROM #TEMP1) AS COLUMN_ID
     ,')' AS TABLESCRIPT
    ,'','',NULL
    ;

    INSERT INTO #TEMP1
    SELECT (SELECT MAX(COLUMN_ID)+1 FROM #TEMP1) AS COLUMN_ID
     ,'GRANT SELECT ON '||I_���̺���||' TO web_iq' AS TABLESCRIPT
    ,'','',NULL
    ;


    SELECT  TRIM(T.TABLE_NAME)   AS TABLE_NAME
           ,TRIM(C.COLUMN_NAME) AS COLUMN_NAME
           ,C.COLUMN_ID         AS COLUMN_ID
           ,TRIM(I.INDEX_TYPE)  AS TYPE
           ,TRIM(I.INDEX_NAME)  AS INDEX_NAME
           ,"UNIQUE"
           ,CASE WHEN I.INDEX_TYPE <> 'FP'
                 THEN 'CREATE '||I.INDEX_TYPE||' INDEX '||I.INDEX_NAME||' ON '||T.TABLE_NAME||' ('||C.COLUMN_NAME||')'
                 ELSE ''
            END                 AS INDEX_SCRIPT
    INTO   #TEMP3
    FROM   SYS.SYSTABLE T,
           SYS.SYSCOLUMN C,
           SYS.SYSINDEX I,
           SYS.SYSIXCOL IC
    WHERE  T.TABLE_ID   = C.TABLE_ID
    AND    C.TABLE_ID   = I.TABLE_ID
    AND    I.TABLE_ID   = IC.TABLE_ID
    AND    I.INDEX_ID   = IC.INDEX_ID
    AND    C.COLUMN_ID  = IC.COLUMN_ID
    AND    T.SERVER_TYPE = 'IQ'
    AND    T.TABLE_TYPE IN( 'BASE','GBL TEMP')
    AND    T.TABLE_NAME = I_���̺���
    --AND    T.TABLE_NAME = 'OT_IQF_���_���ʺ�ȯ_CURRENT'
    AND    I.INDEX_TYPE <> 'SA'
    ORDER BY C.COLUMN_ID
    ;

    SELECT  A.TABLE_NAME
           ,A.COLUMN_NAME
           --,MAX(CASE WHEN A.TYPE = 'FP'  THEN A.INDEX_NAME   ELSE '' END) FP_INDEX
           ,MAX(CASE WHEN A.TYPE = 'LF'  THEN A.INDEX_NAME   ELSE '' END) AS LF_INDEX
           ,MAX(CASE WHEN A.TYPE = 'HG'  THEN A.INDEX_NAME   ELSE '' END) AS HG_INDEX
           ,MAX(CASE WHEN A.TYPE = 'HNG' THEN A.INDEX_NAME   ELSE '' END) AS HNG_INDEX
           ,MAX(CASE WHEN A.TYPE = 'LF'  THEN A.INDEX_SCRIPT ELSE '' END) AS LF_INDEX_SCRIPT
           ,MAX(CASE WHEN A.TYPE = 'HG'  THEN A.INDEX_SCRIPT ELSE '' END) AS HG_INDEX_SCRIPT
           ,MAX(CASE WHEN A.TYPE = 'HNG' THEN A.INDEX_SCRIPT ELSE '' END) AS HNG_INDEX_SCRIPT
    INTO   #TEMP4
    FROM   #TEMP3 A
    WHERE ( A.TYPE IN ('LF','HNG') OR (A.TYPE =  'HG' AND A.INDEX_NAME NOT LIKE 'ASIQ_IDX_%') )
    GROUP BY A.TABLE_NAME,A.COLUMN_NAME,A.COLUMN_ID
    ORDER BY A.COLUMN_ID
    ;

    SELECT  A.COLUMN_ID                         AS NUM
           ,TRIM(A.TABLESCRIPT     )            AS TABLESCRIPT
           ,TRIM(A.COLUMN_NAME     )            AS COLUMN_NAME
           ,TRIM(A.SCALE_NAME      )            AS SCALE
           ,A.CARDINALITY                       AS ����
           ,ISNULL(TRIM(B.LF_INDEX        ),'') AS LF_INDEX
           ,ISNULL(TRIM(B.HG_INDEX        ),'') AS HG_INDEX
           ,ISNULL(TRIM(B.HNG_INDEX       ),'') AS HNG_INDEX
           ,ISNULL(TRIM(B.LF_INDEX_SCRIPT ),'') AS LF_INDEX_SCRIPT
           ,ISNULL(TRIM(B.HG_INDEX_SCRIPT ),'') AS HG_INDEX_SCRIPT
           ,ISNULL(TRIM(B.HNG_INDEX_SCRIPT),'') AS HNG_INDEX_SCRIPT
    FROM   #TEMP1 A,
           #TEMP4 B
    WHERE  A.COLUMN_NAME *= B.COLUMN_NAME
    ORDER BY A.COLUMN_ID
    ;


--
--
--if  exists ( select 1 from sysobjects
--             where name ='sp_tablescript'
--             and type = 'P')
--begin
--  DROP procedure sp_tablescript
--end
--GO
--
--create PROCEDURE sp_tablescript
--(
--  IN I_���̺��� VARCHAR(100)
--)
--BEGIN
--
--
--    SELECT  TRIM(A.TABLE_NAME)                                      AS ���̺���
--           ,TRIM(UPPER(B.COLUMN_NAME))                              AS Į����
--           ,TRIM(B.REMARKS)                                         AS Į���ѱ۸�
--           ,CASE WHEN C.DOMAIN_NAME = 'integer'
--                 THEN 'INT'
--                 ELSE UPPER(C.DOMAIN_NAME)||'('||B.WIDTH||CASE WHEN B.SCALE = 0 THEN ''
--                                                               ELSE ','||B.SCALE END||')'
--            END                                                     AS Į���Ӽ�
--           ,CASE WHEN B.NULLS = 'N' THEN 'NOT NULL' ELSE 'NULL' END AS NULL_YN
--           ,CASE WHEN B.PKEY = 'Y' THEN 'PK' ELSE '' END            AS PK
--    FROM   SYS.SYSTABLE    AS A,
--           SYS.SYSCOLUMN   AS B,
--           SYS.SYSDOMAIN   AS C,
--           SYS.SYSIQCOLUMN AS D
--    WHERE  B.TABLE_ID = A.TABLE_ID
--      AND  C.DOMAIN_ID = B.DOMAIN_ID
--      AND  B.TABLE_ID  = D.TABLE_ID
--      AND  B.COLUMN_ID = D.COLUMN_ID
--      AND  A.TABLE_NAME = I_���̺���
--      --AND  A.TABLE_NAME = 'EIIM_LN_CONT_BASE'
--    ;
--
--
--END
--


END
GO

GRANT EXECUTE ON sp_tablescript TO web_iq 
GO
