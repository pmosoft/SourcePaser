if  exists ( select 1 from sysobjects 
             where name ='sp_extscript2'
             and type = 'P')
begin
  DROP procedure sp_extscript2
end 
GO

create PROCEDURE sp_extscript2 
(
  IN I_���̺��� VARCHAR(100)
)
BEGIN

    create table #temp1 ( ext_text varchar(300) );

    insert into #temp1 select '--sp_extscript '||I_���̺��� as column_name;
    insert into #temp1 select '--bcp '||I_���̺���||' in  ''/ais_ett/temp/ext_'||I_���̺���||'_'||DATEFORMAT(NOW(),'yyyymmdd')||'.dat'' -c -r ''#|@@\n'' -t ''#|'' -b10000 -m10 -Uett_ase -Pais111 -SDBPAIS1' as column_name;
    insert into #temp1 select '--bcp '||I_���̺���||' out ''/ais_ett/temp/ext_'||I_���̺���||'_'||DATEFORMAT(NOW(),'yyyymmdd')||'.dat'' -c -r ''#|@@\n'' -t ''#|'' -Uett_ase -Pais111 -SDBPAIS1' as column_name;
    insert into #temp1 select '--sp_extscript2  '||I_���̺��� as column_name;
    insert into #temp1 select '--bcp '||I_���̺���||' in  ''/ais_ett/temp/ext_'||I_���̺���||'_'||DATEFORMAT(NOW(),'yyyymmdd')||'.dat'' -c -r ''|\n'' -t ''|'' -b10000 -m10 -Uett_ase -Pais111 -SDBPAIS1' as column_name;
    insert into #temp1 select '--bcp '||I_���̺���||' out ''/ais_ett/temp/ext_'||I_���̺���||'_'||DATEFORMAT(NOW(),'yyyymmdd')||'.dat'' -c -r ''|\n'' -t ''|'' -Uett_ase -Pais111 -SDBPAIS1' as column_name;
    insert into #temp1 select '' as column_name;
    insert into #temp1 select 'set temporary option Temp_Extract_Name1 = ''/ais_ett/temp/ext_'||I_���̺���||'_'||CONVERT(CHAR(8),GETDATE(),112)||'.dat'';';
    insert into #temp1 select 'set temporary option Temp_Extract_Column_Delimiter = ''|'';';
    insert into #temp1 select 'set temporary option Temp_Extract_Row_Delimiter = 0x0a;';
    insert into #temp1 select 'set temporary option Temp_Extract_NULL_As_Zero = ''on'';';
    insert into #temp1 select ' ';

    insert into #temp1 select 'SELECT ';

    insert into #temp1
    select case when c.domain_name     in ('integer','numeric','bit','timestamp') and b.column_id  = 1 then b.column_name
                when c.domain_name     in ('integer','numeric','bit','timestamp') and b.column_id <> 1 then ','||b.column_name
                when c.domain_name not in ('integer','numeric','bit','timestamp') and b.column_id  = 1 then 'trim('||b.column_name||')'
                when c.domain_name not in ('integer','numeric','bit','timestamp') and b.column_id <> 1 then ',trim('||b.column_name||')'
           end
    from   SYS.SYSTABLE as a,
           SYS.SYSCOLUMN as b,
           SYS.SYSDOMAIN as c
    where  b.table_id = a.table_id
      and  c.domain_id = b.domain_id
      and  a.table_name = I_���̺���
    order by b.column_id
    ;

    insert into #temp1 select 'FROM '||I_���̺���;
    insert into #temp1 select ';';

    insert into #temp1 select 'set temporary option Temp_Extract_Name1 = '''';';

    select * from #temp1;

END
GO

GRANT EXECUTE ON sp_extscript2 TO web_iq 
GO
