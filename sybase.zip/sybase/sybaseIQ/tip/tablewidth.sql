if  exists ( select 1 from sysobjects 
             where name ='tablewidth'
             and type = 'P')
begin
  DROP procedure tablewidth
end 
GO

create function tablewidth(in tablename char(257))
returns integer
begin
  declare tablew integer;
  declare tname char(128);
  declare towner char(128);
  declare loc integer;
  declare townerid integer;
  declare tableid integer;
  set loc=locate(tablename,'.');
  if(loc > 0) then
    set towner=substr(tablename,1,loc-1);
    set tname=substr(tablename,loc+1)
  else
    set towner=connection_property('Userid');
    set tname=tablename
  end if;
  set townerid=(select user_id from SYS.SYSUSERPERM where
      user_name = towner);
  set tableid=(select table_id from SYS.SYSTABLE where
      table_name = tname and
      creator = townerid);
  set tablew=(select sum(width) from SYS.SYSCOLUMN where
      table_id = tableid);
  return tablew
end
GO

GRANT EXECUTE ON tablewidth TO web_iq 
GO
