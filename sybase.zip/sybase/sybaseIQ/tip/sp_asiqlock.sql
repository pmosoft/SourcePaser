if  exists ( select 1 from sysobjects 
             where name ='sp_asiqlock'
             and type = 'P')
begin
  DROP procedure sp_asiqlock
end 
GO

create procedure sp_asiqlock()
begin

  create table #iq_connTable
  (
      Number                unsigned bigint        null,
      IQconnID              unsigned bigint        null,
      numIQCursors          unsigned integer       null,
      IQthreads             unsigned integer       null,
      TxnID                 unsigned bigint        null,
      ConnOrCurCreateTime   datetime               null,
      CmdLine               varchar(4096)          null,
      CurrOrConn            char(4096)             null,
      IQGovernPriority      char(14)               null
  )
  ;

  create table #t_iq_txn_table
  (
    TxnID unsigned bigint null,
    CmtID unsigned bigint null,
    VersionID unsigned bigint null,
    State char(12) null,
    TxnCreateTime char(26) null,
    ConnHandle unsigned bigint null,
    IQConnID unsigned bigint null,
    Dbremote bit not null,
    CursorCount unsigned bigint null,
    SpCount unsigned bigint null,
    SpNumber unsigned bigint null,
    MainTableKBCreated unsigned bigint null,
    MainTableKBDropped unsigned bigint null,
    TempTableKBCreated unsigned bigint null,
    TempTableKBDropped unsigned bigint null,
    TempWorkSpaceKB unsigned bigint null,
  )
  ;

  execute immediate with quotes on 'iq utilities main into #iq_connTable command statistics 80000';
  execute immediate with quotes on 'iq utilities main into #t_iq_txn_table command statistics 10000';

  select  a.IQconnID                                                                  as IQconnID
         ,a.Number                                                                    as ConnHandle
         ,a.TxnID                                                                     as TxnID
         ,substr(cast(a.ConnOrCurCreateTime as char(19)),12,8)                        as ����ð�
         ,substr(cast(connection_property('LastReqTime',a.Number) as char(19)),12,8)  as ��û�ð�
         ,substr(dateformat(now(),'yyyy-mm-dd hh:nn:ss'),12,8)                        as ����ð�
         ,datediff(second,��û�ð�,����ð�)                                          as �ҿ�ð�_��
         ,a.IQthreads                                                                 as IQthreads
         ,isnull(cast(b.TempWorkSpaceKB*16/2 as unsigned bigint),0)                   as Temp_KB
         ,a.CmdLine                                                                   as CmdLine
         ,case when connection_property('NodeAddress',a.Number) = ''
               then '111.16.4.83'
               else connection_property('NodeAddress',a.Number)
          end                                                                         as NodeAddress
         --,cast(b.MainTableKBCreated*16/2 as unsigned bigint) as MainTableKBCreated
         --,cast(b.MainTableKBDropped*16/2 as unsigned bigint) as MainTableKBDropped
         --,cast(b.TempTableKBCreated*16/2 as unsigned bigint) as TempTableKBCreated
         --,cast(b.TempTableKBDropped*16/2 as unsigned bigint) as TempTableKBDropped
  from   #iq_connTable a,
         #t_iq_txn_table b
  where  a.TxnID *= b.TxnID
  and    a.CmdLine not in ('NO COMMAND','sp_asiqlock')
  and    a.IQthreads > 0
  and    connection_property('LastReqTime',a.Number) is not null
  order by �ҿ�ð�_�� desc,a.IQthreads desc
  ;

end
GO

GRANT EXECUTE ON sp_asiqlock TO web_iq 
GO
