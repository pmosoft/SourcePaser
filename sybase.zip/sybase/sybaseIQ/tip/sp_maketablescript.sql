if  exists ( select 1 from sysobjects 
             where name ='sp_maketablescript'
             and type = 'P')
begin
  DROP procedure sp_maketablescript
end 
GO

create procedure sp_maketablescript()
/*

-- sp_maketablescript

-- ������ �������� /bct/temp/syscolumn.dat ����� chmod 777 /bct/temp/syscolumn.dat�� �����Ѵ�

select a.table_id,a.column_id,a.pkey,a.domain_id,a.width,a.scale,a.nulls,a.column_name||'|'
from   sys.syscolumn a

OT_IQF_����ũ_�����׸�


*/

begin

    select a.table_id,trim(a.table_name) as table_name,a.server_type,a.table_type
    into   #systable
    from   sys.systable a
    --where  a.table_name in ('TB_IQF_����_��������������ܾ�����')
    where  a.table_name like 'TB%'
    or     a.table_name like 'OT%'
    or     a.table_name like 'TM%'
    ;

    ----------------------------------------------
    -- drop table
    ----------------------------------------------
    create table #dropscript
    (
        dropscript         varchar(300) null
    );

    insert into #dropscript
    select 'if  exists (select 1 from systable where table_name='''||table_name||''') drop table '||table_name as dropscript
    from #systable
    ;

    ----------------------------------------------
    -- create table
    ----------------------------------------------
    create table #tablescript1
    (
        table_name          varchar(200) null,
        column_id           int          null,
        tablescript         varchar(300) null,
    );

    create table #tablescript
    (
        table_name          varchar(200) null,
        column_id           int          null,
        column_name         char(100)    null,
        scale_name          char(20)     null,
        null_yn             char(8)      null,
        max_col             int          null
    );

    create table #syscolumn
    (
        table_id            int          null,
        column_id           int          null,
        pkey                char(1)      null,
        domain_id           int          null,
        width               int          null,
        scale               int          null,
        nulls               char(1)      null,
        column_name         char(100)    null,
    );

    load table #syscolumn (
     table_id
    ,column_id
    ,pkey
    ,domain_id
    ,width
    ,scale
    ,nulls
    ,column_name
    ) from '/bct/temp/syscolumn.dat'
    quotes  off
    escapes off
    format  ascii
    delimited by '|'
    row     delimited by 0x0a
    ;

    select a.domain_id,trim(a.domain_name) as domain_name
    into   #sysdomain
    from   sys.sysdomain a
    where  a.domain_id in (select distinct domain_id from #syscolumn)
    ;

    insert into #tablescript
    select  a.table_name                                            as table_name
           ,0                                                       as column_id
           ,'CREATE TABLE '||a.table_name||' ('                     as column_name
           ,''                                                      as scale_name
           ,''                                                      as null_yn
           ,0                                                       as max_col
    from   #systable a
    ;

    insert into #tablescript
    select  a.table_name                                            as table_name
           ,b.column_id                                             as column_id
           ,upper(b.column_name)                                    as column_name
           ,case when c.domain_name = 'integer'   then 'INT'
                 when c.domain_name = 'timestamp' then 'TIMESTAMP'
                 when c.domain_name = 'bit'       then 'BIT'
                 when c.domain_name = 'tinyint'   then 'TINYINT'
                 when c.domain_name = 'smallint'  then 'SMALLINT'
                 when c.domain_name = 'bigint'    then 'BIGINT'
                 else upper(c.domain_name)||'('||b.width||case when b.scale = 0 then ''
                                                               else ','||b.scale end||')'
            end                                                     as scale_name
           ,case when b.nulls = 'N' then 'NOT NULL' else 'NULL' end as null_yn
           ,0                                                       as max_col
    from   #systable    a,
           #syscolumn   b,
           #sysdomain   c
    where  a.table_id  = b.table_id
      and  b.domain_id = c.domain_id
    ;

    update #tablescript
    set    a.max_col = b.max_col
    from   #tablescript a,
          (select  a.table_name
                  ,max(a.column_id) as max_col
           from   #tablescript a
           group by a.table_name) b
    where  a.table_name = b.table_name
    ;

    insert into #tablescript1
    select  table_name
           ,column_id
           ,case when column_id = 0 then column_name
                 when column_id > 0 then column_name||scale_name||trim(null_yn)||','
            end as tablescript
    from   #tablescript
    order by table_name,column_id
    ;

    select number(*) rnum,b.table_id,b.column_id,a.table_name,b.column_name
    into   #tablescript2
    from   #systable  a,
           #syscolumn b
    where  a.table_id = b.table_id
      and  b.pkey = 'Y'
    order by a.table_name,b.column_id;
    ;

    select  number(*) rnum
           ,a.table_name
           ,b.num
    into   #tablescript2_1
    from   (select a.table_name
                  ,count(*)      as max_cnt
            from   #tablescript2 a
            group by a.table_name) a,
           (select  1 num union select  2 num union select  3 num union select  4 num union select  5 num union
            select  6 num union select  7 num union select  8 num union select  9 num union select 10 num union
            select 11 num union select 12 num union select 13 num union select 14 num union select 15 num union
            select 16 num union select 17 num union select 18 num union select 19 num union select 20 num
           ) b
    where   b.num <= a.max_cnt
    group by a.table_name,b.num
    order by a.table_name,b.num
    ;

    select  a.table_name,a.column_name,b.num
    into    #tablescript2_2
    from    #tablescript2 a,
            #tablescript2_1 b
    where   a.rnum = b.rnum
    ;

    insert into #tablescript1
    select
     a.table_name
    ,(select max(column_id)+1 from #tablescript1 where table_name = a.table_name) as column_id
    ,'PRIMARY KEY('||
      max(case when a.num =  1 then trim(a.column_name)||(case when b.max_cnt <>  1 then ',' else ')' end) else null end)
    ||max(case when a.num =  2 then trim(a.column_name)||(case when b.max_cnt <>  2 then ',' else ')' end) else null end)
    ||max(case when a.num =  3 then trim(a.column_name)||(case when b.max_cnt <>  3 then ',' else ')' end) else null end)
    ||max(case when a.num =  4 then trim(a.column_name)||(case when b.max_cnt <>  4 then ',' else ')' end) else null end)
    ||max(case when a.num =  5 then trim(a.column_name)||(case when b.max_cnt <>  5 then ',' else ')' end) else null end)
    ||max(case when a.num =  6 then trim(a.column_name)||(case when b.max_cnt <>  6 then ',' else ')' end) else null end)
    ||max(case when a.num =  7 then trim(a.column_name)||(case when b.max_cnt <>  7 then ',' else ')' end) else null end)
    ||max(case when a.num =  8 then trim(a.column_name)||(case when b.max_cnt <>  8 then ',' else ')' end) else null end)
    ||max(case when a.num =  9 then trim(a.column_name)||(case when b.max_cnt <>  9 then ',' else ')' end) else null end)
    ||max(case when a.num = 10 then trim(a.column_name)||(case when b.max_cnt <> 10 then ',' else ')' end) else null end)
    ||max(case when a.num = 11 then trim(a.column_name)||(case when b.max_cnt <> 11 then ',' else ')' end) else null end)
    ||max(case when a.num = 12 then trim(a.column_name)||(case when b.max_cnt <> 12 then ',' else ')' end) else null end)
    ||max(case when a.num = 13 then trim(a.column_name)||(case when b.max_cnt <> 13 then ',' else ')' end) else null end)
    ||max(case when a.num = 14 then trim(a.column_name)||(case when b.max_cnt <> 14 then ',' else ')' end) else null end)
    ||max(case when a.num = 15 then trim(a.column_name)||(case when b.max_cnt <> 15 then ',' else ')' end) else null end)
    ||max(case when a.num = 16 then trim(a.column_name)||(case when b.max_cnt <> 16 then ',' else ')' end) else null end)
    ||max(case when a.num = 17 then trim(a.column_name)||(case when b.max_cnt <> 17 then ',' else ')' end) else null end)
    ||max(case when a.num = 18 then trim(a.column_name)||(case when b.max_cnt <> 18 then ',' else ')' end) else null end)
    ||max(case when a.num = 19 then trim(a.column_name)||(case when b.max_cnt <> 19 then ',' else ')' end) else null end)
    ||max(case when a.num = 20 then trim(a.column_name)||(case when b.max_cnt <> 20 then ',' else ')' end) else null end)
    as tablescript
    from    #tablescript2_2 a,
           (select a.table_name,max(a.num) max_cnt
            from #tablescript2_2 a
            group by a.table_name
            ) b
    where   a.table_name = b.table_name
    group by a.table_name
    ;

    insert into #tablescript1
    select  a.table_name
           ,max(a.column_id)+1 as column_id
           ,');' as tablescript
    from   #tablescript1 a
    group by a.table_name
    ;


    ----------------------------------------------
    -- create index
    ----------------------------------------------
    --
    create table #indexscript
    (
        indexscript         varchar(300) null
    );


    insert into #indexscript
    select  case when i.index_type <> 'FP'
                 then 'CREATE '||i.index_type||' INDEX '||i.index_name||' ON '||t.table_name||' ('||trim(c.column_name)||')'
                 else ''
            end                 as indexscript
    from   #systable t,
           #syscolumn c,
           sys.sysindex i,
           sys.sysixcol ic
    where  t.table_id   = c.table_id
    and    c.table_id   = i.table_id
    and    i.table_id   = ic.table_id
    and    i.index_id   = ic.index_id
    and    c.column_id  = ic.column_id
    and    t.server_type = 'IQ'
    and    t.table_type in( 'BASE','GBL TEMP')
    --and    t.table_name = 'OT_IQF_���_���ʺ�ȯ_CURRENT'
    and    i.index_type in ('LF','HG','HNG','LF','HG','HNG')
    and i.index_name not like 'ASIQ_IDX_%'
    order by c.column_id
    ;

    ----------------------------------------------
    -- grant
    ----------------------------------------------
    create table #grantscript
    (
        grantscript         varchar(300) null
    );

    insert into #grantscript
    select 'grant select on '||table_name||' to web_iq;' as grantscript
    from #systable
    ;

    ----------------------------------------------
    -- output
    ----------------------------------------------
    select a.dropscript
    into   #allscript
    from   #dropscript a
    ;
    insert into #allscript
    select a.tablescript
    from   #tablescript1 a
    order by a.table_name,a.column_id
    ;
    insert into #allscript
    select indexscript from #indexscript
    ;
    insert into #allscript
    select grantscript from #grantscript
    ;
    select * from #allscript
    ;


end
GO

GRANT EXECUTE ON sp_maketablescript TO web_iq 
GO
