if  exists ( select 1 from sysobjects 
             where name ='sp_findtable'
             and type = 'P')
begin
  DROP procedure sp_findtable
end 
GO

create procedure ett_iq.sp_findtable(in I_���̺��� varchar(100))
begin
  select trim(table_name),'SELECT TOP 1 *  FROM ' || 
    table_name as COL1,'SELECT COUNT(*) FROM ' || 
    table_name as COL2 from
    systable where table_name like '%' || I_���̺��� || '%' order by
    table_name asc
/*
if  exists ( select 1 from sysobjects 
where name ='sp_findtable'
and type = 'P')
begin
DROP procedure sp_findtable
end 
GO

create PROCEDURE sp_findtable 
(
IN I_���̺��� VARCHAR(100)
)
BEGIN

select  trim(table_name) 
,trim(remarks)
,'SELECT TOP 1 *  FROM '||table_name AS COL1
,'SELECT COUNT(*) FROM '||table_name AS COL2
from   systable where table_name like '%'||I_���̺���||'%'
and    remarks <> ''
order by table_name;

END


*/
end
GO

GRANT EXECUTE ON sp_findtable TO web_iq 
GO
