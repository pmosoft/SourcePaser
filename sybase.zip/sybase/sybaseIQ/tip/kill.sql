
drop connection ConnHandle