if  exists ( select 1 from sysobjects 
             where name ='SP_IQ_��뷮����'
             and type = 'P')
begin
  DROP procedure SP_IQ_��뷮����
end 
GO

create procedure ett_iq.SP_IQ_��뷮����()
begin
  ------------------------------------------
  -- �ۼ����� 20090318 BY JSG
  ------------------------------------------
  declare MT unsigned bigint;
  declare MU unsigned bigint;
  declare TT unsigned bigint;
  declare TU unsigned bigint;
  call SP_IQSPACEUSED(MT,MU,TT,TU);
  select cast(MT/(1024*1024) as unsigned bigint) as MAIN_�Ҵ�GB,
    cast(MU/(1024*1024) as unsigned bigint) as MAIN_���GB,
    cast(MU*100/MT as numeric(5,2)) as MAIN_�����,
    cast(TT/(1024*1024) as unsigned bigint) as TEMP_�Ҵ�GB,
    cast(TU/(1024*1024) as unsigned bigint) as TEMP_���GB,
    cast(TU*100/TT as numeric(5,2)) as TEMP_�����,
    (select VALUE from SP_IQSTATUS() where NAME = ' OTHER VERSIONS:') as "OTHER VERSIONS",
    (select VALUE from SP_IQSTATUS() where NAME = ' ACTIVE TXN VERSIONS:') as "ACTIVE VERSIONS"
end
GO

GRANT EXECUTE ON SP_IQ_��뷮���� TO web_iq 
GO
