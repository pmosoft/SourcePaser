BEGIN

    SELECT NUMBER(*) RNUM,C1,C2
    INTO   #TEMP1
    FROM  (SELECT 'AB' C1, 432 C2 UNION
           SELECT 'AB' C1, 853 C2 UNION
           SELECT 'AB' C1, 123 C2 UNION
           SELECT 'CD' C1, 765 C2 UNION
           SELECT 'CD' C1, 265 C2 UNION
           SELECT 'CD' C1, 244 C2 UNION
           SELECT 'CD' C1, 543 C2 ) A
    ORDER BY C1,C2
    ;

    SELECT  NUMBER(*) RNUM
           ,A.C1
           ,B.��ȣ
    INTO   #TEMP2
    FROM   (SELECT C1,COUNT(*) CNT
            FROM   #TEMP1
            GROUP BY C1) A,
            OT_IQF_���_���� B
    WHERE   B.��ȣ <= A.CNT
    GROUP BY A.C1,B.��ȣ
    ORDER BY A.C1,B.��ȣ
    ;

    SELECT  A.C1,A.C2,B.��ȣ
    INTO    #TEMP3
    FROM    #TEMP1 A,
            #TEMP2 B
    WHERE  A.RNUM = B.RNUM
    ;

    SELECT  C1
           ,MAX(CASE WHEN ��ȣ = 1 THEN C2 ELSE NULL END) C21
           ,MAX(CASE WHEN ��ȣ = 2 THEN C2 ELSE NULL END) C22
           ,MAX(CASE WHEN ��ȣ = 3 THEN C2 ELSE NULL END) C23
           ,MAX(CASE WHEN ��ȣ = 4 THEN C2 ELSE NULL END) C24
           ,MAX(CASE WHEN ��ȣ = 5 THEN C2 ELSE NULL END) C25
           ,MAX(CASE WHEN ��ȣ = 6 THEN C2 ELSE NULL END) C26
    FROM   #TEMP3
    GROUP BY C1
    ;

END
