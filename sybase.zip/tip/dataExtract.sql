begin

    ------------------------------------------------------------------------------
    set temporary option temp_extract_name1 ='/ettdev/srcdata/imsi1.dat';
    set temporary option temp_extract_column_delimiter = '#';
    set temporary option temp_extract_null_as_zero = 'on';
    ------------------------------------------------------------------------------

    ------------------------------------------------------------------------------
    set temporary option temp_extract_null_as_zero = 'off';
    set temporary option temp_extract_name1 = '';
    ------------------------------------------------------------------------------

    select 'create table '||'tb_bmat�޴����� (';

    select
             '    '||b.column_name
           ||'    '||c.domain_name||'('||b.width||case when b.scale = 0 then '' else '.'||b.scale end||')'
           ||'    '||case when b.nulls = 'N' then 'not null,' else 'null,' end
    from   SYS.SYSTABLE as a,
           SYS.SYSCOLUMN as b,
           SYS.SYSDOMAIN as c
    where  b.table_id = a.table_id
      and  c.domain_id = b.domain_id
      and  a.table_name like 'tb_bmat�޴�����'
    order by b.column_id;

    select '   CONSTRAINT '||'tb_bmat�޴�����'||'_PK'||'PRIMARY KEY('||b.column_name||')'
    from   SYS.SYSTABLE  a,
           SYS.SYSCOLUMN  b
    where  b.table_id = a.table_id
      and  a.table_name = 'tb_bmat�޴�����'
      and  b.pkey = 'Y';

    select ');';

end


CREATE TABLE CTDB.CT_USER.TCT_ADDVALUE (
	COMPID                          VARCHAR(50)                      NOT NULL  ,
	COMMID                          VARCHAR(50)                      NOT NULL  ,
	USERID                          VARCHAR(50)                      NOT NULL  ,
	ITEMSEQ                         NUMERIC(2,0)                     NOT NULL  ,
	ITEMVALUE                       VARCHAR(2000)                    NULL  ,
		CONSTRAINT ICT_ADDVALUE_PK PRIMARY KEY CLUSTERED ( COMPID, COMMID, USERID, ITEMSEQ )  on 'default'
)
