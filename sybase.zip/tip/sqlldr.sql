-------------------------------------------------------------------------------------
bad,dat ��� ��θ� ���������� ��� ����

sqlldr scott/tiger control=igam_ctr_temp.ctl bad=igam_ctr_temp.bad

sqlldr igam/tuxigam@DBODS1.WORLD control=AFEX_COM_CDAPL.ctl bad=AFEX_COM_CDAPL.bad

-------------------------------------------------------------------------------------


Load DATA
INFILE 'd:\d\Documents\����\Data2.dat '
APPEND
INTO TABLE IF_TBL_BAT_DATA
FIELDS TERMINATED BY "|" OPTIONALLY ENCLOSED BY '"'
(
 OCR_DT  CHAR
,FILE_ID CHAR
,SEQNO   DECIMAL EXTERNAL
,FIRM_NO CHAR
,DATA    CHAR(3000)
)


LOAD DATA
INFILE 'c:/igam_ctr_temp_01.dat'
APPEND
INTO TABLE igam_ctr_temp
FIELDS TERMINATED BY "|" OPTIONALLY ENCLOSED BY '$'
TRAILING NULLCOLS
(
        TRSC_DT             CHAR               "rtrim(:TRSC_DT)"
,       LOG_BR_NO           CHAR               "rtrim(:LOG_BR_NO)"
,       LOG_NO              DECIMAL EXTERNAL
,       BIZ_DV_CD           CHAR               "rtrim(:BIZ_DV_CD)"
,       ACNM_NO             CHAR               "rtrim(:ACNM_NO)"
,       SEQ_NO              CHAR               "rtrim(:SEQ_NO)"
,       TOTL_NCNT           CHAR               "rtrim(:TOTL_NCNT)"
,       CUST_NM             CHAR               "rtrim(:CUST_NM)"
,       ACNM_NO_DV_CD       CHAR               "rtrim(:ACNM_NO_DV_CD)"
,       CUST_ADR_ZIP_NO     CHAR               "rtrim(:CUST_ADR_ZIP_NO)"
,       CUST_ADR            CHAR               "rtrim(:CUST_ADR)"
,       CUST_TEL_NO         CHAR               "rtrim(:CUST_TEL_NO)"
,       FRNR_ACNM_NO        CHAR               "rtrim(:FRNR_ACNM_NO)"
,       CNTY_CD_NM          CHAR               "rtrim(:CNTY_CD_NM)"
,       CNTY_CD             CHAR               "rtrim(:CNTY_CD)"
,       REPR_NM             CHAR               "rtrim(:REPR_NM)"
,       REPR_ACNM_NO_DV_CD  CHAR               "rtrim(:REPR_ACNM_NO_DV_CD)"
,       REPR_ACNM_NO        CHAR               "rtrim(:REPR_ACNM_NO)"
,       CO_ESBLH_DT         CHAR               "rtrim(:CO_ESBLH_DT)"
,       TPBZ_CD             CHAR               "rtrim(:TPBZ_CD)"
,       CO_ZIP_NO           CHAR               "rtrim(:CO_ZIP_NO)"
,       CO_ADDR             CHAR               "rtrim(:CO_ADDR)"
,       CO_TEL_NO           CHAR               "rtrim(:CO_TEL_NO)"
,       TRSC_ORGN_DTM       CHAR               "rtrim(:TRSC_ORGN_DTM)"
,       TRSC_BR_NM          CHAR               "rtrim(:TRSC_BR_NM)"
,       TRSC_BR_ZIP_NO      CHAR               "rtrim(:TRSC_BR_ZIP_NO)"
,       CTR_TRSC_METH_CD    CHAR               "rtrim(:CTR_TRSC_METH_CD)"
,       CTR_TRSC_MEAN_CD    CHAR               "rtrim(:CTR_TRSC_MEAN_CD)"
,       TRSC_AMT            DECIMAL EXTERNAL
,       CTR_TRSC_KIND_CD    CHAR               "rtrim(:CTR_TRSC_KIND_CD)"
,       ACCT_NO             CHAR               "rtrim(:ACCT_NO)"
,       ACCT_OPEN_BR_NM     CHAR               "rtrim(:ACCT_OPEN_BR_NM)"
,       ACCT_OPEN_BR_ZIP_NO CHAR               "rtrim(:ACCT_OPEN_BR_ZIP_NO)"
,       ACCT_OPEN_DT        CHAR               "rtrim(:ACCT_OPEN_DT)"
,       SECR_KIND_CD        CHAR               "rtrim(:SECR_KIND_CD)"
,       FST_SECR_NO         CHAR               "rtrim(:FST_SECR_NO)"
,       LST_SECR_NO         CHAR               "rtrim(:LST_SECR_NO)"
,       PRSN_BNK_NM         CHAR               "rtrim(:PRSN_BNK_NM)"
,       PRSN_BNK_CD         CHAR               "rtrim(:PRSN_BNK_CD)"
,       PRSN_BR_NM          CHAR               "rtrim(:PRSN_BR_NM)"
,       PRSN_BNK_ZIP_NO     CHAR               "rtrim(:PRSN_BNK_ZIP_NO)"
,       RCVG_ACCT_NO        CHAR               "rtrim(:RCVG_ACCT_NO)"
,       RCVG_BNK_NM         CHAR               "rtrim(:RCVG_BNK_NM)"
,       RCVG_BNK_CD         CHAR               "rtrim(:RCVG_BNK_CD)"
,       RMTE_NM             CHAR               "rtrim(:RMTE_NM)"
,       RPTG_TGT_YN         CHAR               "rtrim(:RPTG_TGT_YN)"
,       ATIT_CD             CHAR               "rtrim(:ATIT_CD)"
,       BLNG_TEAM_CD        CHAR               "rtrim(:BLNG_TEAM_CD)"
,       EXCN_YN             CHAR               "rtrim(:EXCN_YN)"
,       EXCN_RSN            CHAR               "rtrim(:EXCN_RSN)"
,       CORC_DT             CHAR               "rtrim(:CORC_DT)"
,       CORC_EMP_NO         CHAR               "rtrim(:CORC_EMP_NO)"
,       OPTR_EMP_NO         CHAR               "rtrim(:OPTR_EMP_NO)"
,       TRSC_BR_CD          CHAR               "rtrim(:TRSC_BR_CD)"
,       CNFM_DV_CD          CHAR               "rtrim(:CNFM_DV_CD)"
,       CNFM_EMP_NO         CHAR               "rtrim(:CNFM_EMP_NO)"
,       CNFM_DT             CHAR               "rtrim(:CNFM_DT)"
,       DAECH_EXCN          CHAR               "rtrim(:DAECH_EXCN)"
)
