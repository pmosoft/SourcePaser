select * from dbcgbible.cont4_member_period  order by mp_last_date desc
go
select * from radius.radcheck
