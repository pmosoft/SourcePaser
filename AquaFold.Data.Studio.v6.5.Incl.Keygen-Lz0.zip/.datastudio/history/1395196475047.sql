select * from dbcgbible.cont4_member_period
go
select * from radius.radcheck

