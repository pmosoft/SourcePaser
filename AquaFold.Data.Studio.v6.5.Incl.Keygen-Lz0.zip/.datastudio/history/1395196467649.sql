
delete from radius.radcheck
where  username not in
      (
       select mb_id
       from   dbcgbible.cont4_member_period
       )
;