package test.jdbc.mybatisLogback.oracle;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class Main {

    public static void main(String[] args) {

    	
		String configLocation = "classpath:springMybatisLogbackOracle.xml"; // src/main/resources/springMybatisLogbackOracle.xml
		AbstractApplicationContext ctx = new GenericXmlApplicationContext(configLocation);
		TestJdbcMybatisLogbackOracle TestJdbcMybatisLogbackOracle = ctx.getBean("TestJdbcMybatisLogbackOracle",TestJdbcMybatisLogbackOracle.class);
		
		/* select */		
		TestJdbcMybatisLogbackOracle.selectEmp();

		ctx.close();
    }
}
