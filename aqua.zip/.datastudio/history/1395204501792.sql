select * from dbcgbible.cont4_member_period  order by mp_last_date,mb_id desc
go
select * from radius.radcheck order by mb_id