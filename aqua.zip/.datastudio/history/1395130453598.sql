select 
 username
,acctstarttime
,date_format(acctstarttime,'%Y.%m.%d') 
,date_format(acctstarttime,'%h:%i:%S') 
,now()
,TIMESTAMPDIFF(hour,acctstarttime,now())||'�ð�'
,case when TIMESTAMPDIFF(second,acctstarttime,now()) < 60 then TIMESTAMPDIFF(hour,acctstarttime,now())||'��'
when TIMESTAMPDIFF(minute,acctstarttime,now()) < 60 then TIMESTAMPDIFF(minute,acctstarttime,now())||'��'
when TIMESTAMPDIFF(hour,acctstarttime,now()) < 24 then TIMESTAMPDIFF(hour,acctstarttime,now())||'�ð�'
when TIMESTAMPDIFF(day,acctstarttime,now()) >= 1 then TIMESTAMPDIFF(day,acctstarttime,now())||'��'
end ���ӽð�
from   radius.radacct
