/*---------------------------
  etc
---------------------------*/
select * from dbcgbible.cont4_member_period