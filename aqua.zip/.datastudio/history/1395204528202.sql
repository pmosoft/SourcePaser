select * from dbcgbible.cont4_member_period  order by mp_last_date desc,mb_id
go
select * from radius.radcheck order by username
